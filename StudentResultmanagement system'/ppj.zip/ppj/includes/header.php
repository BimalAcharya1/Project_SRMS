<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SRMS - <?php echo $page_title ?? 'Dashboard'; ?></title>
    <link rel="stylesheet" href="<?php echo $base_url ?? ''; ?>assets/css/style.css">
</head>
<body>