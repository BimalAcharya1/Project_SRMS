<?php
class Validation {
    
    // Validate name (only letters and spaces)
    public static function validateName($name, $field = 'Name') {
        $errors = [];
        if (empty($name)) {
            $errors[] = "$field is required";
        } elseif (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
            $errors[] = "$field should contain only letters and spaces";
        } elseif (strlen($name) < 2) {
            $errors[] = "$field must be at least 2 characters long";
        } elseif (strlen($name) > 100) {
            $errors[] = "$field must be less than 100 characters";
        }
        return $errors;
    }

    // Validate username (letters, numbers, underscore, min 3, max 50)
    public static function validateUsername($username) {
        $errors = [];
        if (empty($username)) {
            $errors[] = "Username is required";
        } elseif (!preg_match("/^[a-zA-Z0-9_]{3,50}$/", $username)) {
            $errors[] = "Username must be 3-50 characters and can contain letters, numbers, and underscore only";
        }
        return $errors;
    }

    // Validate email
    public static function validateEmail($email) {
        $errors = [];
        if (empty($email)) {
            $errors[] = "Email is required";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        } elseif (strlen($email) > 150) {
            $errors[] = "Email must be less than 150 characters";
        }
        return $errors;
    }

    // Validate phone number (Nepal: starts with 97 or 98, exactly 10 digits)
    public static function validatePhone($phone) {
        $errors = [];
        if (empty($phone)) {
            $errors[] = "Phone number is required";
        } elseif (!preg_match("/^(97|98)\d{8}$/", $phone)) {
            $errors[] = "Phone number must start with 97 or 98 and contain exactly 10 digits";
        }
        return $errors;
    }

    // Validate password strength
    public static function validatePassword($password, $confirm_password = null) {
        $errors = [];
        if (empty($password)) {
            $errors[] = "Password is required";
        } else {
            if (strlen($password) < 8) {
                $errors[] = "Password must be at least 8 characters long";
            }
            if (!preg_match("/[A-Z]/", $password)) {
                $errors[] = "Password must contain at least one uppercase letter";
            }
            if (!preg_match("/[a-z]/", $password)) {
                $errors[] = "Password must contain at least one lowercase letter";
            }
            if (!preg_match("/[0-9]/", $password)) {
                $errors[] = "Password must contain at least one number";
            }
            if (!preg_match("/[!@#$%^&*()\-_=+{};:,<.>]/", $password)) {
                $errors[] = "Password must contain at least one special character";
            }
        }
        
        if ($confirm_password !== null && $password !== $confirm_password) {
            $errors[] = "Passwords do not match";
        }
        
        return $errors;
    }

    // Validate roll number
    public static function validateRollNumber($roll_number) {
        $errors = [];
        if (empty($roll_number)) {
            $errors[] = "Roll number is required";
        } elseif (!preg_match("/^[a-zA-Z0-9\-]+$/", $roll_number)) {
            $errors[] = "Roll number can contain letters, numbers, and hyphens only";
        } elseif (strlen($roll_number) > 20) {
            $errors[] = "Roll number must be less than 20 characters";
        }
        return $errors;
    }

    // Validate date of birth
    public static function validateDOB($dob) {
        $errors = [];
        if (empty($dob)) {
            $errors[] = "Date of birth is required";
        } else {
            $date = DateTime::createFromFormat('Y-m-d', $dob);
            if (!$date || $date->format('Y-m-d') !== $dob) {
                $errors[] = "Invalid date format";
            } else {
                $min_date = new DateTime('-100 years');
                $max_date = new DateTime('-15 years');
                if ($date < $min_date) {
                    $errors[] = "Date of birth cannot be more than 100 years ago";
                }
                if ($date > $max_date) {
                    $errors[] = "Student must be at least 15 years old";
                }
            }
        }
        return $errors;
    }

    // Validate semester number
    public static function validateSemester($semester, $max_semester = 8) {
        $errors = [];
        if (empty($semester)) {
            $errors[] = "Semester is required";
        } elseif (!is_numeric($semester) || $semester < 1 || $semester > $max_semester) {
            $errors[] = "Semester must be between 1 and $max_semester";
        }
        return $errors;
    }

    // Validate marks
    public static function validateMarks($marks, $max_marks = 100) {
        $errors = [];
        if ($marks !== '' && (!is_numeric($marks) || $marks < 0 || $marks > $max_marks)) {
            $errors[] = "Marks must be between 0 and $max_marks";
        }
        return $errors;
    }

    // Validate year
    public static function validateYear($year, $min = 2000, $max = 2100) {
        $errors = [];
        if (empty($year)) {
            $errors[] = "Year is required";
        } elseif (!is_numeric($year) || $year < $min || $year > $max) {
            $errors[] = "Year must be between $min and $max";
        }
        return $errors;
    }

    // Validate required field
    public static function validateRequired($value, $field) {
        $errors = [];
        if (empty($value)) {
            $errors[] = "$field is required";
        }
        return $errors;
    }

    // Validate numeric field
    public static function validateNumeric($value, $field, $min = null, $max = null) {
        $errors = [];
        if (!is_numeric($value)) {
            $errors[] = "$field must be a number";
        } else {
            if ($min !== null && $value < $min) {
                $errors[] = "$field must be at least $min";
            }
            if ($max !== null && $value > $max) {
                $errors[] = "$field must be at most $max";
            }
        }
        return $errors;
    }

    // Sanitize input
    public static function sanitize($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
}
?>