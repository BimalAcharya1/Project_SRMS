<?php
session_start();

function checkAdminLogin() {
    if (!isset($_SESSION['admin_id'])) {
        header("Location: ../login.php?type=admin&error=Please login first");
        exit();
    }
}

function checkTeacherLogin() {
    if (!isset($_SESSION['teacher_id'])) {
        header("Location: ../login.php?type=teacher&error=Please login first");
        exit();
    }
}

function checkStudentLogin() {
    if (!isset($_SESSION['student_id'])) {
        header("Location: ../login.php?type=student&error=Please login first");
        exit();
    }
}
?>