<?php
// get_result.php
require_once 'config/database.php';

header('Content-Type: application/json');

$database = new Database();
$conn = $database->getConnection();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
    exit;
}

// Get POST data
$exam_id = $_POST['exam_id'] ?? '';
$dept_id = $_POST['dept_id'] ?? '';
$course_id = $_POST['course_id'] ?? '';
$semester = $_POST['semester'] ?? '';
$section = $_POST['section'] ?? '';
$roll_number = $_POST['roll_number'] ?? '';
$dob = $_POST['dob'] ?? '';

// Validate required fields
if (!$exam_id || !$dept_id || !$course_id || !$semester || !$roll_number || !$dob) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
    exit;
}

try {
    // Get student information with validation
    $student_query = "SELECT s.*, c.course_name, d.dept_id as student_dept_id, d.dept_name 
                     FROM student s
                     LEFT JOIN course c ON s.course_id = c.course_id
                     LEFT JOIN department d ON c.dept_id = d.dept_id
                     WHERE s.roll_number = ? AND s.dob = ?";
    
    $stmt = $conn->prepare($student_query);
    $stmt->bind_param("ss", $roll_number, $dob);
    $stmt->execute();
    $student_result = $stmt->get_result();
    
    if ($student_result->num_rows === 0) {
        echo json_encode(['status' => 'error', 'message' => 'Student not found with provided credentials']);
        exit;
    }
    
    $student = $student_result->fetch_assoc();
    
    // Verify department and course match
    if ($student['student_dept_id'] != $dept_id || $student['course_id'] != $course_id) {
        echo json_encode(['status' => 'error', 'message' => 'Student does not belong to selected department/course']);
        exit;
    }
    
    // Verify section if provided
    if (!empty($section) && $student['section'] != $section) {
        echo json_encode(['status' => 'error', 'message' => 'Student section does not match']);
        exit;
    }
    
    // Get exam details
    $exam_query = "SELECT exam_name, exam_type FROM exam WHERE exam_id = ? AND is_active = 1";
    $stmt = $conn->prepare($exam_query);
    $stmt->bind_param("i", $exam_id);
    $stmt->execute();
    $exam_result = $stmt->get_result();
    $exam = $exam_result->fetch_assoc();
    
    if (!$exam) {
        echo json_encode(['status' => 'error', 'message' => 'Exam not found or inactive']);
        exit;
    }
    
    // Get subjects for this course and semester with exam subject details
    $subjects_query = "SELECT s.*, 
                       COALESCE(es.theory_full_marks, 60) as theory_max,
                       COALESCE(es.theory_pass_marks, 24) as theory_pass,
                       COALESCE(es.practical_full_marks, 40) as practical_max,
                       COALESCE(es.practical_pass_marks, 18) as practical_pass,
                       es.exam_date
                       FROM subject s
                       LEFT JOIN exam_subject es ON s.subject_id = es.subject_id AND es.exam_id = ?
                       WHERE s.course_id = ? AND s.semester_number = ?
                       ORDER BY s.subject_code";
    
    $stmt = $conn->prepare($subjects_query);
    $stmt->bind_param("iii", $exam_id, $course_id, $semester);
    $stmt->execute();
    $subjects_result = $stmt->get_result();
    
    if ($subjects_result->num_rows === 0) {
        echo json_encode(['status' => 'error', 'message' => 'No subjects found for this course and semester']);
        exit;
    }
    
    // Get results for this student and exam
    $results_query = "SELECT r.*, s.subject_name, s.subject_code 
                     FROM result r
                     JOIN subject s ON r.subject_id = s.subject_id
                     WHERE r.student_id = ? AND r.exam_id = ?";
    
    $stmt = $conn->prepare($results_query);
    $stmt->bind_param("ii", $student['student_id'], $exam_id);
    $stmt->execute();
    $results_data = $stmt->get_result();
    
    $results_by_subject = [];
    while ($row = $results_data->fetch_assoc()) {
        $results_by_subject[$row['subject_id']] = $row;
    }
    
    // Prepare results array
    $results = [];
    $total_marks = 0;
    $total_max_marks = 0;
    $failed_subjects = 0;
    $has_failed = false;
    
    while ($subject = $subjects_result->fetch_assoc()) {
        $subject_id = $subject['subject_id'];
        $theory_marks = 0;
        $practical_marks = 0;
        $theory_pass = false;
        $practical_pass = true; // Default to true if no practical
        $marks_obtained = 0;
        $grade = 'F';
        $remarks = '';
        
        if (isset($results_by_subject[$subject_id])) {
            $theory_marks = floatval($results_by_subject[$subject_id]['theory_marks'] ?? 0);
            $practical_marks = floatval($results_by_subject[$subject_id]['practical_marks'] ?? 0);
            $remarks = $results_by_subject[$subject_id]['remarks'] ?? '';
            
            // Check if theory passed (if theory exists)
            if ($subject['theory_max'] > 0) {
                $theory_pass = ($theory_marks >= $subject['theory_pass']);
            } else {
                $theory_pass = true;
            }
            
            // Check if practical passed (if practical exists)
            if ($subject['practical_max'] > 0) {
                $practical_pass = ($practical_marks >= $subject['practical_pass']);
            }
            
            // Calculate total marks only if both parts passed
            if ($theory_pass && $practical_pass) {
                $marks_obtained = $theory_marks + $practical_marks;
                $max_marks = $subject['theory_max'] + $subject['practical_max'];
                $grade = calculateGrade($marks_obtained, $max_marks);
            } else {
                $marks_obtained = $theory_marks + $practical_marks; // Still show obtained marks but mark as fail
                $grade = 'F';
                $failed_subjects++;
                $has_failed = true;
            }
        } else {
            // No result found - mark as absent/fail
            $remarks = 'Absent';
            $failed_subjects++;
            $has_failed = true;
            $grade = 'F';
        }
        
        $max_marks = $subject['theory_max'] + $subject['practical_max'];
        
        // Only add to total if student passed this subject
        if ($theory_pass && $practical_pass) {
            $total_marks += $marks_obtained;
            $total_max_marks += $max_marks;
        } else {
            // Still add to total max marks for display but not to obtained
            $total_max_marks += $max_marks;
        }
        
        $results[] = [
            'subject_id' => $subject_id,
            'subject_code' => $subject['subject_code'],
            'subject_name' => $subject['subject_name'],
            'theory_marks' => $theory_marks,
            'practical_marks' => $practical_marks,
            'theory_pass_marks' => $subject['theory_pass'],
            'practical_pass_marks' => $subject['practical_pass'],
            'marks_obtained' => $marks_obtained,
            'max_marks' => $max_marks,
            'grade' => $grade,
            'remarks' => $remarks,
            'theory_pass' => $theory_pass,
            'practical_pass' => $practical_pass
        ];
    }
    
    // Calculate summary - only if no failed subjects
    $status = $has_failed ? 'FAIL' : 'PASS';
    
    if ($has_failed) {
        // If failed, don't show percentage or overall grade
        $percentage = 0;
        $overall_grade = 'F';
    } else {
        $percentage = $total_max_marks > 0 ? round(($total_marks / $total_max_marks) * 100, 2) : 0;
        $overall_grade = calculateOverallGrade($percentage);
    }
    
    // Get batch info
    $batch_info = ['batch_name' => null, 'batch_year' => null];
    if (!empty($student['batch_id'])) {
        $batch_query = "SELECT batch_name, start_year, end_year FROM batch WHERE batch_id = ?";
        $stmt = $conn->prepare($batch_query);
        $stmt->bind_param("i", $student['batch_id']);
        $stmt->execute();
        $batch_result = $stmt->get_result();
        if ($batch_result->num_rows > 0) {
            $batch = $batch_result->fetch_assoc();
            $batch_info['batch_name'] = $batch['batch_name'];
            $batch_info['batch_year'] = $batch['start_year'] . '-' . $batch['end_year'];
        }
    }
    
    // Prepare response
    $response = [
        'status' => 'success',
        'data' => [
            'student' => [
                'first_name' => $student['first_name'],
                'middle_name' => $student['middle_name'],
                'last_name' => $student['last_name'],
                'roll_number' => $student['roll_number'],
                'dept_name' => $student['dept_name'],
                'section' => $student['section'],
                'dob' => $student['dob']
            ],
            'results' => $results,
            'summary' => [
                'total_marks' => $total_marks,
                'max_marks' => $total_max_marks,
                'percentage' => $percentage,
                'overall_grade' => $overall_grade,
                'status' => $status
            ],
            'exam_name' => $exam['exam_name'],
            'exam_type' => $exam['exam_type'],
            'course_name' => $student['course_name'],
            'semester' => $semester,
            'batch_name' => $batch_info['batch_name'],
            'batch_year' => $batch_info['batch_year']
        ]
    ];
    
    echo json_encode($response);
    
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}

function calculateGrade($marks, $max_marks) {
    if ($max_marks == 0) return 'F';
    
    $percentage = ($marks / $max_marks) * 100;
    
    if ($percentage >= 90) return 'A+';
    if ($percentage >= 80) return 'A';
    if ($percentage >= 70) return 'B+';
    if ($percentage >= 60) return 'B';
    if ($percentage >= 50) return 'C+';
    if ($percentage >= 40) return 'C';
    if ($percentage >= 35) return 'D';
    return 'F';
}

function calculateOverallGrade($percentage) {
    if ($percentage >= 90) return 'A+';
    if ($percentage >= 80) return 'A';
    if ($percentage >= 70) return 'B+';
    if ($percentage >= 60) return 'B';
    if ($percentage >= 50) return 'C+';
    if ($percentage >= 40) return 'C';
    if ($percentage >= 35) return 'D';
    return 'F';
}
?>