<?php 
$servername = "localhost";
$username = "root";
$password = "";      

$conn = new mysqli($servername, $username, $password);

// CHECK CONNECTION
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// CREATE DATABASE
$sql = "CREATE DATABASE IF NOT EXISTS srmsdb";
$conn->query($sql);

// USE DATABASE
$conn->select_db("srmsdb");

// ================= CREATE TABLES =================

// ADMIN TABLE
$sql = "CREATE TABLE IF NOT EXISTS admin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255),
    image VARCHAR(255),
    college_school VARCHAR(150),
    address VARCHAR(255)
)";
$conn->query($sql);

// CONTACT TABLE
$sql = "CREATE TABLE IF NOT EXISTS contact (
    contact_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150),
    email VARCHAR(150),
    suggestion TEXT,
    admin_reply TEXT,
    reply_date DATETIME,
    contact_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);

// DEPARTMENT TABLE
$sql = "CREATE TABLE IF NOT EXISTS department (
    dept_id INT AUTO_INCREMENT PRIMARY KEY,
    dept_name VARCHAR(150) NOT NULL UNIQUE,
    dept_code VARCHAR(10)
)";
$conn->query($sql);

// COURSE TABLE
$sql = "CREATE TABLE IF NOT EXISTS course (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(150) NOT NULL,
    dept_id INT,
    total_semesters INT DEFAULT 8,
    duration_years INT DEFAULT 4,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id) ON DELETE CASCADE
)";
$conn->query($sql);

// SUBJECT TABLE
$sql = "CREATE TABLE IF NOT EXISTS subject (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_name VARCHAR(150) NOT NULL,
    subject_code VARCHAR(20) NOT NULL,
    credit_hours INT,
    semester_number INT,
    course_id INT,
    subject_type ENUM('Compulsory','Optional','Elective') DEFAULT 'Compulsory',
    FOREIGN KEY (course_id) REFERENCES course(course_id) ON DELETE CASCADE
)";
$conn->query($sql);

// STUDENT TABLE
$sql = "CREATE TABLE IF NOT EXISTS student (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    roll_number VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    dob DATE,
    gender ENUM('Male','Female','Other'),
    phone VARCHAR(20),
    email VARCHAR(150),
    address VARCHAR(255),
    course_id INT,
    current_semester INT,
    section VARCHAR(10),
    FOREIGN KEY (course_id) REFERENCES course(course_id) ON DELETE CASCADE
)";
$conn->query($sql);

// STUDENT SUBJECTS TABLE
$sql = "CREATE TABLE IF NOT EXISTS student_subjects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    subject_type ENUM('compulsory','optional','elective') NOT NULL,
    semester INT NOT NULL,
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subject(subject_id) ON DELETE CASCADE,
    UNIQUE KEY unique_student_subject (student_id, subject_id)
)";
$conn->query($sql);

// EXAM TABLE
$sql = "CREATE TABLE IF NOT EXISTS exam (
    exam_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_name VARCHAR(100),
    exam_type ENUM('Midterm','PreBoard','Board','Internal'),
    exam_date DATE,
    is_active BOOLEAN DEFAULT 1
)";
$conn->query($sql);

// EXAM SUBJECT TABLE
$sql = "CREATE TABLE IF NOT EXISTS exam_subject (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT,
    subject_id INT,
    exam_date DATE NOT NULL,
    theory_full_marks INT NOT NULL,
    theory_pass_marks INT NOT NULL,
    practical_full_marks INT,
    practical_pass_marks INT,
    FOREIGN KEY (exam_id) REFERENCES exam(exam_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subject(subject_id) ON DELETE CASCADE
)";
$conn->query($sql);

// RESULT TABLE
$sql = "CREATE TABLE IF NOT EXISTS result (
    result_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    subject_id INT,
    exam_id INT,
    theory_marks DECIMAL(5,2),
    practical_marks DECIMAL(5,2),
    total_marks DECIMAL(5,2) GENERATED ALWAYS AS (COALESCE(theory_marks,0) + COALESCE(practical_marks,0)) STORED,
    grade VARCHAR(5),
    remarks VARCHAR(100),
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subject(subject_id) ON DELETE CASCADE,
    FOREIGN KEY (exam_id) REFERENCES exam(exam_id) ON DELETE CASCADE,
    UNIQUE KEY student_id (student_id, subject_id, exam_id)
)";
$conn->query($sql);

// TEACHER TABLE
$sql = "CREATE TABLE IF NOT EXISTS teacher (
    teacher_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id) ON DELETE CASCADE
)";
$conn->query($sql);

// TEACHER ALLOCATION TABLE
$sql = "CREATE TABLE IF NOT EXISTS teacher_allocation (
    allocation_id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT,
    subject_id INT,
    section VARCHAR(10),
    FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subject(subject_id) ON DELETE CASCADE,
    UNIQUE KEY unique_teacher_subject_section_session (teacher_id, subject_id, section, session_id),
    KEY idx_section (section)
)";
$conn->query($sql);

$conn->close();
?>