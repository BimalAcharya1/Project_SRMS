<?php
// validate_ajax.php
header('Content-Type: application/json');

$field = $_POST['field'] ?? '';
$value = trim($_POST['value'] ?? '');

$response = ['status' => 'success', 'message' => ''];

if ($field === 'cName') {
    if (strlen($value) < 3) {
        $response = ['status' => 'error', 'message' => 'Name must be at least 3 characters'];
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $value)) {
        $response = ['status' => 'error', 'message' => 'Name can only contain letters and spaces'];
    }
} elseif ($field === 'cEmail') {
    if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
        $response = ['status' => 'error', 'message' => 'Please enter a valid email address'];
    }
}

echo json_encode($response);