$(document).ready(function() {
    // Real-time validation for forms
    $('input[type="text"], input[type="email"], input[type="password"], input[type="tel"], input[type="date"], select').on('blur keyup', function() {
        validateField($(this));
    });

    // Form submission validation
    $('form').on('submit', function(e) {
        e.preventDefault();
        var form = $(this);
        var isValid = true;
        
        // Validate all fields
        form.find('input, select, textarea').each(function() {
            if (!validateField($(this))) {
                isValid = false;
            }
        });

        if (isValid) {
            // Submit form via AJAX
            submitForm(form);
        }
    });

    // Phone number validation
    $(document).on('input', 'input[type="tel"]', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
    });

    // Name field validation (only letters and spaces)
    $(document).on('input', '.name-field', function() {
        this.value = this.value.replace(/[^a-zA-Z\s]/g, '');
    });

    // Username validation (letters, numbers, underscore)
    $(document).on('input', '.username-field', function() {
        this.value = this.value.replace(/[^a-zA-Z0-9_]/g, '');
    });

    // Check username availability
    $(document).on('blur', '.username-field', function() {
        var username = $(this).val();
        var field = $(this);
        
        if (username.length >= 3) {
            $.ajax({
                url: 'api/check_username.php',
                type: 'POST',
                data: {username: username},
                dataType: 'json',
                success: function(response) {
                    if (!response.available) {
                        showFieldError(field, 'Username is already taken');
                    }
                }
            });
        }
    });

    // Check email availability
    $(document).on('blur', 'input[type="email"]', function() {
        var email = $(this).val();
        var field = $(this);
        
        if (email.length > 0) {
            $.ajax({
                url: 'api/check_email.php',
                type: 'POST',
                data: {email: email},
                dataType: 'json',
                success: function(response) {
                    if (!response.available) {
                        showFieldError(field, 'Email is already registered');
                    }
                }
            });
        }
    });

    // Check roll number availability
    $(document).on('blur', 'input[name="roll_number"]', function() {
        var roll_number = $(this).val();
        var field = $(this);
        
        if (roll_number.length > 0) {
            $.ajax({
                url: 'api/check_roll_number.php',
                type: 'POST',
                data: {roll_number: roll_number},
                dataType: 'json',
                success: function(response) {
                    if (!response.available) {
                        showFieldError(field, 'Roll number already exists');
                    }
                }
            });
        }
    });

    // Dynamic course-subject loading
    $('#course_id, #dept_id').on('change', function() {
        loadDependentData();
    });

    // Password strength meter
    $('input[type="password"]').on('keyup', function() {
        var password = $(this).val();
        var strength = checkPasswordStrength(password);
        showPasswordStrength($(this), strength);
        
        // Confirm password validation
        var confirmField = $('input[name="confirm_password"]');
        if (confirmField.length > 0) {
            validateConfirmPassword(confirmField);
        }
    });

    // Confirm password validation
    $('input[name="confirm_password"]').on('keyup', function() {
        validateConfirmPassword($(this));
    });

    // Marks validation
    $('.marks-input').on('input', function() {
        var marks = $(this).val();
        var maxMarks = $(this).data('max') || 100;
        
        if (marks > maxMarks) {
            $(this).val(maxMarks);
            showFieldError($(this), 'Marks cannot exceed ' + maxMarks);
        } else if (marks < 0) {
            $(this).val(0);
            showFieldError($(this), 'Marks cannot be negative');
        }
    });
});

function validateField(field) {
    var value = field.val();
    var fieldName = field.attr('name');
    var fieldType = field.attr('type');
    var errors = [];
    
    // Required field validation
    if (field.prop('required') && !value) {
        errors.push('This field is required');
    }
    
    if (value) {
        // Type-specific validation
        switch(fieldType) {
            case 'email':
                if (!isValidEmail(value)) {
                    errors.push('Invalid email format');
                }
                break;
                
            case 'tel':
                if (!isValidPhone(value)) {
                    errors.push('Phone must start with 97 or 98 and be 10 digits');
                }
                break;
                
            case 'password':
                var passwordErrors = validatePasswordStrength(value);
                errors = errors.concat(passwordErrors);
                break;
        }
        
        // Field name specific validation
        if (fieldName) {
            if (fieldName.includes('name') || fieldName.includes('Name')) {
                if (!isValidName(value)) {
                    errors.push('Name should contain only letters and spaces');
                }
            }
            
            if (fieldName.includes('username')) {
                if (!isValidUsername(value)) {
                    errors.push('Username must be 3-50 characters (letters, numbers, underscore)');
                }
            }
            
            if (fieldName.includes('roll_number')) {
                if (!isValidRollNumber(value)) {
                    errors.push('Invalid roll number format');
                }
            }
            
            if (fieldName.includes('semester')) {
                if (!isValidSemester(value)) {
                    errors.push('Semester must be between 1 and 8');
                }
            }
            
            if (fieldName.includes('year')) {
                if (!isValidYear(value)) {
                    errors.push('Year must be between 2000 and 2100');
                }
            }
        }
    }
    
    // Show/hide error message
    if (errors.length > 0) {
        showFieldError(field, errors.join('<br>'));
        return false;
    } else {
        clearFieldError(field);
        return true;
    }
}

function validateConfirmPassword(field) {
    var password = $('input[name="password"]').val();
    var confirmPassword = field.val();
    
    if (password !== confirmPassword) {
        showFieldError(field, 'Passwords do not match');
        return false;
    } else {
        clearFieldError(field);
        return true;
    }
}

function validatePasswordStrength(password) {
    var errors = [];
    
    if (password.length < 8) {
        errors.push('Password must be at least 8 characters');
    }
    if (!/[A-Z]/.test(password)) {
        errors.push('Need at least one uppercase letter');
    }
    if (!/[a-z]/.test(password)) {
        errors.push('Need at least one lowercase letter');
    }
    if (!/[0-9]/.test(password)) {
        errors.push('Need at least one number');
    }
    if (!/[!@#$%^&*()\-_=+{};:,<.>]/.test(password)) {
        errors.push('Need at least one special character');
    }
    
    return errors;
}

function checkPasswordStrength(password) {
    var strength = 0;
    
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[!@#$%^&*()\-_=+{};:,<.>]/.test(password)) strength++;
    
    if (strength <= 2) return 'weak';
    if (strength <= 4) return 'medium';
    return 'strong';
}

function showPasswordStrength(field, strength) {
    var meter = field.closest('.form-group').find('.password-strength');
    if (meter.length === 0) {
        meter = $('<div class="password-strength"></div>');
        field.closest('.form-group').append(meter);
    }
    
    meter.removeClass('weak medium strong').addClass(strength);
    meter.text('Password strength: ' + strength.charAt(0).toUpperCase() + strength.slice(1));
}

function showFieldError(field, message) {
    var formGroup = field.closest('.form-group');
    formGroup.addClass('has-error');
    
    var errorDiv = formGroup.find('.error-message');
    if (errorDiv.length === 0) {
        errorDiv = $('<div class="error-message"></div>');
        formGroup.append(errorDiv);
    }
    
    errorDiv.html(message);
    field.css('border-color', '#dc3545');
}

function clearFieldError(field) {
    var formGroup = field.closest('.form-group');
    formGroup.removeClass('has-error');
    formGroup.find('.error-message').remove();
    field.css('border-color', '#ddd');
}

function submitForm(form) {
    var formData = form.serialize();
    var submitBtn = form.find('button[type="submit"]');
    var originalText = submitBtn.text();
    
    submitBtn.prop('disabled', true).text('Processing...');
    
    $.ajax({
        url: form.attr('action'),
        type: 'POST',
        data: formData,
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                showToast('success', response.message);
                if (response.redirect) {
                    setTimeout(function() {
                        window.location.href = response.redirect;
                    }, 2000);
                } else {
                    form[0].reset();
                }
            } else {
                showToast('error', response.message);
                if (response.errors) {
                    $.each(response.errors, function(field, messages) {
                        var input = form.find('[name="' + field + '"]');
                        showFieldError(input, messages.join('<br>'));
                    });
                }
            }
        },
        error: function(xhr, status, error) {
            showToast('error', 'An error occurred: ' + error);
        },
        complete: function() {
            submitBtn.prop('disabled', false).text(originalText);
        }
    });
}

function loadDependentData() {
    var deptId = $('#dept_id').val();
    var courseId = $('#course_id').val();
    
    if (deptId) {
        $.ajax({
            url: 'api/get_courses.php',
            type: 'POST',
            data: {dept_id: deptId},
            success: function(data) {
                $('#course_id').html(data);
            }
        });
    }
    
    if (courseId) {
        $.ajax({
            url: 'api/get_subjects.php',
            type: 'POST',
            data: {course_id: courseId},
            success: function(data) {
                $('#subject_id').html(data);
            }
        });
        
        $.ajax({
            url: 'api/get_semesters.php',
            type: 'POST',
            data: {course_id: courseId},
            dataType: 'json',
            success: function(data) {
                var select = $('#semester_id');
                select.empty();
                select.append('<option value="">Select Semester</option>');
                for (var i = 1; i <= data.total_semesters; i++) {
                    select.append('<option value="' + i + '">Semester ' + i + '</option>');
                }
            }
        });
    }
}

function showToast(type, message) {
    var toast = $('<div class="toast toast-' + type + '">' + message + '</div>');
    $('body').append(toast);
    
    setTimeout(function() {
        toast.fadeOut(function() {
            $(this).remove();
        });
    }, 3000);
}

// Validation helper functions
function isValidEmail(email) {
    var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function isValidPhone(phone) {
    var re = /^(97|98)\d{8}$/;
    return re.test(phone);
}

function isValidName(name) {
    var re = /^[a-zA-Z\s]+$/;
    return re.test(name) && name.length >= 2;
}

function isValidUsername(username) {
    var re = /^[a-zA-Z0-9_]{3,50}$/;
    return re.test(username);
}

function isValidRollNumber(roll) {
    var re = /^[a-zA-Z0-9\-]+$/;
    return re.test(roll) && roll.length <= 20;
}

function isValidSemester(semester) {
    return semester >= 1 && semester <= 8;
}

function isValidYear(year) {
    return year >= 2000 && year <= 2100;
}