$(document).ready(function() {
    // Toggle mobile menu
    $('.menu-toggle').click(function() {
        $('.navbar-menu').toggleClass('active');
    });

    // Modal functionality
    $('.close, .modal').click(function(e) {
        if (e.target == this) {
            $(this).hide();
        }
    });

    // Form validation
    $('form').submit(function(e) {
        var valid = true;
        $(this).find('input[required], select[required]').each(function() {
            if (!$(this).val()) {
                $(this).css('border-color', '#dc3545');
                valid = false;
            } else {
                $(this).css('border-color', '#ddd');
            }
        });
        return valid;
    });

    // Dynamic course-subject loading
    $('#course_id').change(function() {
        var courseId = $(this).val();
        if (courseId) {
            $.ajax({
                url: 'api/get_subjects.php',
                type: 'POST',
                data: {course_id: courseId},
                success: function(data) {
                    $('#subject_id').html(data);
                }
            });
        }
    });

    // Dynamic semester-subject loading for marks entry
    $('#batch_id, #semester').change(function() {
        var batchId = $('#batch_id').val();
        var semester = $('#semester').val();
        var examId = $('#exam_id').val();
        
        if (batchId && semester && examId) {
            loadStudentsForMarks(batchId, semester, examId);
        }
    });

    // Marks entry form
    $('#marks_entry_form').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        
        $.ajax({
            url: 'api/save_marks.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('success', response.message);
                } else {
                    showAlert('error', response.message);
                }
            },
            error: function() {
                showAlert('error', 'An error occurred while saving marks');
            }
        });
    });

    // Student result search
    $('#search_result').click(function() {
        var rollNumber = $('#roll_number').val();
        var dob = $('#dob').val();
        
        if (rollNumber && dob) {
            $.ajax({
                url: 'api/get_result.php',
                type: 'POST',
                data: {
                    roll_number: rollNumber,
                    dob: dob
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        displayResult(response.data);
                    } else {
                        showAlert('error', response.message);
                    }
                }
            });
        } else {
            showAlert('error', 'Please fill all fields');
        }
    });

    // Delete confirmation
    $('.delete-btn').click(function(e) {
        if (!confirm('Are you sure you want to delete this item?')) {
            e.preventDefault();
        }
    });
});

function showAlert(type, message) {
    var alertClass = type === 'success' ? 'alert-success' : 'alert-error';
    var alert = '<div class="alert ' + alertClass + '">' + message + '</div>';
    $('.content').prepend(alert);
    setTimeout(function() {
        $('.alert').fadeOut();
    }, 3000);
}

function loadStudentsForMarks(batchId, semester, examId) {
    $.ajax({
        url: 'api/get_students.php',
        type: 'POST',
        data: {
            batch_id: batchId,
            semester: semester
        },
        dataType: 'json',
        success: function(students) {
            var html = '<table class="table"><tr><th>Roll No</th><th>Name</th><th>Marks</th></tr>';
            $.each(students, function(i, student) {
                html += '<tr>';
                html += '<td>' + student.roll_number + '</td>';
                html += '<td>' + student.first_name + ' ' + student.last_name + '</td>';
                html += '<td><input type="number" name="marks[' + student.student_id + ']" class="marks-input" step="0.01" min="0" max="100"></td>';
                html += '</tr>';
            });
            html += '</table>';
            html += '<button type="submit" class="btn">Save Marks</button>';
            $('#marks_table').html(html);
        }
    });
}

function displayResult(data) {
    var html = '<div class="result-card">';
    html += '<h2>Student Result</h2>';
    html += '<div class="student-info">';
    html += '<p><strong>Name:</strong> ' + data.student_name + '</p>';
    html += '<p><strong>Roll Number:</strong> ' + data.roll_number + '</p>';
    html += '<p><strong>Course:</strong> ' + data.course_name + '</p>';
    html += '<p><strong>Semester:</strong> ' + data.semester + '</p>';
    html += '</div>';
    
    html += '<table class="marks-table">';
    html += '<tr><th>Subject</th><th>Marks Obtained</th><th>Grade</th></tr>';
    
    var total = 0;
    $.each(data.marks, function(i, mark) {
        html += '<tr>';
        html += '<td>' + mark.subject_name + '</td>';
        html += '<td>' + mark.marks_obtained + '</td>';
        html += '<td class="grade-' + mark.grade + '">' + mark.grade + '</td>';
        html += '</tr>';
        total += parseFloat(mark.marks_obtained);
    });
    
    html += '</table>';
    html += '<div class="total-marks">Total Marks: ' + total + '</div>';
    html += '</div>';
    
    $('#result_display').html(html);
}