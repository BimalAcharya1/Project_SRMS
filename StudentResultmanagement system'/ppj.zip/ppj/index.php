<?php 
// Include database connection
require_once 'config/database.php';
$database = new Database();
$conn = $database->getConnection();

// Fetch exams for dropdown
$exams = $conn->query("SELECT exam_id, exam_name FROM exam WHERE is_active = 1 ORDER BY exam_date DESC");

// Fetch departments for dropdown
$departments = $conn->query("SELECT dept_id, dept_name FROM department ORDER BY dept_name");

// Fetch courses for dropdown (initially all, will be filtered by JavaScript)
$courses = $conn->query("SELECT c.course_id, c.course_name, d.dept_id, d.dept_name 
                        FROM course c 
                        LEFT JOIN department d ON c.dept_id = d.dept_id 
                        ORDER BY d.dept_name, c.course_name");

// Fetch sections for dropdown
$sections = $conn->query("SELECT DISTINCT section FROM student WHERE section IS NOT NULL AND section != '' ORDER BY section");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" type="image/png" href="icons/SRMS.png">
    <link rel="stylesheet" href="CSS/index.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Result Management System - SRMS</title>
    <style>
        /* Additional Styles for Result Display */
        .result-container {
            max-width: 1000px;
            margin: 30px auto;
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            animation: slideUp 0.5s ease-out;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .result-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #667eea;
        }
        
        .result-header h2 {
            color: #333;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .result-header p {
            color: #666;
            font-size: 16px;
        }
        
        .student-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
        }
        
        .info-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .info-icon {
            width: 35px;
            height: 35px;
            background: #667eea;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: bold;
        }
        
        .info-item strong {
            color: #333;
            margin-right: 5px;
            min-width: 70px;
        }
        
        .info-item span {
            color: #666;
        }
        
        .marksheet-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
            border: 1px solid #e0e0e0;
        }
        
        .marksheet-table th {
            background: #667eea;
            color: white;
            padding: 12px;
            font-weight: 600;
            font-size: 14px;
        }
        
        .marksheet-table td {
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
            text-align: center;
        }
        
        .marksheet-table tr:hover {
            background: #f8f9fa;
        }
        
        .marksheet-table tfoot td {
            background: #e8eaf6;
            font-weight: bold;
            padding: 12px;
        }
        
        .grade-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .grade-a-plus { background: #28a745; color: white; }
        .grade-a { background: #5cb85c; color: white; }
        .grade-b-plus { background: #5bc0de; color: white; }
        .grade-b { background: #f0ad4e; color: white; }
        .grade-c-plus { background: #d9534f; color: white; }
        .grade-c { background: #d9534f; color: white; }
        .grade-d { background: #d9534f; color: white; }
        .grade-f { background: #dc3545; color: white; }
        
        .summary-section {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 10px;
            margin-top: 25px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            border: 1px solid #e0e0e0;
        }
        
        .summary-item {
            text-align: center;
        }
        
        .summary-label {
            color: #666;
            font-size: 14px;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .summary-value {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        
        .summary-value.total-marks {
            color: #667eea;
        }
        
        .summary-value.percentage {
            color: #28a745;
        }
        
        .summary-value.grade {
            color: #dc3545;
        }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
            position: relative;
            z-index: 1000;
        }
        
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer !important;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            pointer-events: auto !important;
            opacity: 1 !important;
            position: relative;
            z-index: 1001;
        }
        
        .btn-print {
            background: #6c757d;
            color: white;
        }
        
        .btn-print:hover {
            background: #5a6268;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(108, 117, 125, 0.3);
        }
        
        .btn-back {
            background: #667eea;
            color: white;
        }
        
        .btn-back:hover {
            background: #5a67d8;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .loading {
            text-align: center;
            padding: 40px;
        }
        
        .loading-spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
            border-left: 4px solid #dc3545;
        }
        
        .validation-msg {
            font-size: 12px;
            margin-left: 10px;
            display: block;
        }
        .msg-error { color: #ff4444; }
        .msg-success { color: #00C851; }
        
        .filter-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .center-box {
            max-width: 500px;
            margin: 20px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        
        .center-box select, .center-box input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .center-box label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: 500;
        }
        
        .center-box button {
            width: 100%;
            padding: 12px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .center-box button:hover {
            background: #5a67d8;
        }
        
        .failed-subject {
            background-color: #ffebee;
        }
        
        .theory-fail, .practical-fail {
            color: #dc3545;
            font-weight: bold;
        }
        
        /* Print Styles - A4 Format */
        @media print {
            @page {
                size: A4;
                margin: 1.5cm;
            }
            
            body {
                background: white;
                padding: 0;
                margin: 0;
            }
            
            .top-buttons, 
            .info-btn, 
            .contact-btn, 
            #contactForm, 
            .action-buttons, 
            .btn, 
            .center-box,
            #loading,
            .blur-bg {
                display: none !important;
            }
            
            .result-container {
                max-width: 100%;
                margin: 0;
                padding: 0.5cm;
                box-shadow: none;
                border-radius: 0;
                animation: none;
                background: white;
            }
            
            .result-header {
                margin-bottom: 0.7cm;
                padding-bottom: 0.3cm;
                border-bottom: 2px solid #000;
            }
            
            .result-header h2 {
                font-size: 24px;
                color: #000;
                margin: 0 0 5px 0;
            }
            
            .result-header p {
                color: #333;
                font-size: 14px;
                margin: 2px 0;
            }
            
            .student-info {
                background: #f5f5f5;
                padding: 0.4cm;
                margin-bottom: 0.7cm;
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 0.3cm;
                border: 1px solid #ddd;
                border-radius: 0;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .info-item {
                break-inside: avoid;
            }
            
            .info-icon {
                display: none;
            }
            
            .info-item strong {
                color: #000;
                min-width: 60px;
                font-size: 11px;
            }
            
            .info-item span {
                color: #000;
                font-size: 11px;
            }
            
            .marksheet-table {
                border: 1px solid #000;
                margin-bottom: 0.7cm;
                border-collapse: collapse;
                width: 100%;
                font-size: 11px;
            }
            
            .marksheet-table th {
                background: #e0e0e0 !important;
                color: #000 !important;
                padding: 8px 5px;
                font-weight: bold;
                border: 1px solid #000;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .marksheet-table td {
                padding: 6px 5px;
                border: 1px solid #000;
                color: #000;
            }
            
            .marksheet-table tfoot td {
                background: #f0f0f0 !important;
                border: 1px solid #000;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .grade-badge {
                padding: 3px 8px;
                border-radius: 0;
                font-weight: bold;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .grade-a-plus { background: #28a745 !important; color: white !important; }
            .grade-a { background: #5cb85c !important; color: white !important; }
            .grade-b-plus { background: #5bc0de !important; color: white !important; }
            .grade-b { background: #f0ad4e !important; color: white !important; }
            .grade-c-plus { background: #d9534f !important; color: white !important; }
            .grade-c { background: #d9534f !important; color: white !important; }
            .grade-d { background: #d9534f !important; color: white !important; }
            .grade-f { background: #dc3545 !important; color: white !important; }
            
            .summary-section {
                background: #f5f5f5;
                padding: 0.4cm;
                margin-top: 0.7cm;
                border: 1px solid #000;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .summary-item {
                text-align: center;
            }
            
            .summary-label {
                color: #000;
                font-size: 12px;
                font-weight: bold;
            }
            
            .summary-value {
                font-size: 16px;
                color: #000 !important;
            }
            
            .failed-subject {
                background-color: #ffebee !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .theory-fail, .practical-fail {
                color: #dc3545 !important;
                font-weight: bold;
            }
            
            /* Page break handling */
            .result-container {
                page-break-after: avoid;
                page-break-inside: avoid;
            }
            
            .marksheet-table {
                page-break-inside: auto;
            }
            
            tr {
                page-break-inside: avoid;
                page-break-after: auto;
            }
            
            thead {
                display: table-header-group;
            }
            
            tfoot {
                display: table-footer-group;
            }
        }
    </style>
</head>
<body>
<div class="blur-bg"></div>

    <!-- TOP BUTTONS -->
    <div class="top-buttons">
        <a href="Teacher/teacherlog/teacher_login.php"><button><img src="icons/Teacher.png" width="20"> Teacher</button></a>
        <a href="admin/adminlog/admin.php"><button><img src="icons/Admin.png" width="20"> Admin</button></a>
    </div>

    <!-- SEARCH BOX -->
    <div class="center-box" id="searchBox">
        <h2 class="header">Search Result</h2>

        <label>Exam Name <span style="color: red;">*</span></label>
        <select id="examName">
            <option value="">Select Exam</option>
            <?php while($exam = $exams->fetch_assoc()): ?>
            <option value="<?php echo $exam['exam_id']; ?>"><?php echo $exam['exam_name']; ?></option>
            <?php endwhile; ?>
        </select>

        <div class="filter-row">
            <div>
                <label>Department <span style="color: red;">*</span></label>
                <select id="deptName" onchange="loadCoursesByDepartment()">
                    <option value="">Select Department</option>
                    <?php while($dept = $departments->fetch_assoc()): ?>
                    <option value="<?php echo $dept['dept_id']; ?>"><?php echo $dept['dept_name']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div>
                <label>Course <span style="color: red;">*</span></label>
                <select id="courseName" disabled>
                    <option value="">Select Department First</option>
                </select>
            </div>
        </div>

        <div class="filter-row">
            <div>
                <label>Year / Semester <span style="color: red;">*</span></label>
                <select id="yearSemester">
                    <option value="">Select Semester</option>
                    <?php for($i = 1; $i <= 8; $i++): ?>
                    <option value="<?php echo $i; ?>">Semester <?php echo $i; ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div>
                <label>Section</label>
                <select id="section">
                    <option value="">All Sections</option>
                    <?php while($section = $sections->fetch_assoc()): ?>
                    <option value="<?php echo $section['section']; ?>">Section <?php echo $section['section']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
        </div>

        <label>Roll Number <span style="color: red;">*</span></label>
        <input type="text" id="rollNumber" placeholder="Enter Roll Number (e.g., CSE2023001)" style="width: 100%;">

        <label>Date of Birth <span style="color: red;">*</span></label>
        <input type="date" id="dob" style="width: 100%;">
        <p id="dobError" class="error"></p>

        <button onclick="searchResult()">Search Result</button>
    </div>
    
    <!-- Result Container (initially hidden) -->
    <div id="resultContainer" style="display: none;"></div>
    
    <!-- Loading Spinner (initially hidden) -->
    <div id="loading" class="loading" style="display: none;">
        <div class="loading-spinner"></div>
        <p>Fetching your result...</p>
    </div>

    <!-- INFO BUTTON -->
    <button class="info-btn" onclick="showInfo()">
        <img src="icons/Info.png">
    </button>

    <!-- CONTACT BUTTON LEFT -->
    <button class="contact-btn" onclick="toggleContact()">
        <img src="icons/contact.png">
    </button>

    <!-- CONTACT POPUP -->
    <div id="contactForm">
        <h3>Contact Us</h3>
        <div class="input-group">
            <img src="icons/Users.png">
            <input type="text" id="cName" placeholder="Your Name" onkeyup="liveValidate('cName')">
        </div>
        <span id="msg_cName" class="validation-msg"></span>
        
        <div class="input-group">
            <img src="icons/Email.png">
            <input type="email" id="cEmail" placeholder="Email Address" onkeyup="liveValidate('cEmail')">
        </div>
        <span id="msg_cEmail" class="validation-msg"></span>
        
        <textarea id="cMsg" rows="3" placeholder="Suggestion..."></textarea>
        <button onclick="sendMsg()">Send</button>
    </div>
    
    <script>
    // Store courses data for filtering
    var allCourses = [];
    
    <?php 
    $courses->data_seek(0);
    while($course = $courses->fetch_assoc()): 
    ?>
    allCourses.push({
        id: <?php echo $course['course_id']; ?>,
        name: '<?php echo addslashes($course['course_name']); ?>',
        dept_id: <?php echo $course['dept_id'] ?? 'null'; ?>
    });
    <?php endwhile; ?>

    function loadCoursesByDepartment() {
        var deptId = document.getElementById('deptName').value;
        var courseSelect = document.getElementById('courseName');
        
        // Clear and disable course select
        courseSelect.innerHTML = '<option value="">Select Course</option>';
        
        if (deptId) {
            // Filter courses by department
            var filteredCourses = allCourses.filter(function(course) {
                return course.dept_id == deptId;
            });
            
            if (filteredCourses.length > 0) {
                filteredCourses.forEach(function(course) {
                    var option = document.createElement('option');
                    option.value = course.id;
                    option.text = course.name;
                    courseSelect.appendChild(option);
                });
                courseSelect.disabled = false;
            } else {
                courseSelect.innerHTML = '<option value="">No courses in this department</option>';
                courseSelect.disabled = true;
            }
        } else {
            courseSelect.innerHTML = '<option value="">Select Department First</option>';
            courseSelect.disabled = true;
        }
    }

    function liveValidate(fieldId) {
        let value = document.getElementById(fieldId).value;
        let msgSpan = document.getElementById("msg_" + fieldId);

        if (value.length === 0) {
            msgSpan.innerHTML = "";
            return;
        }

        let formData = new FormData();
        formData.append('field', fieldId);
        formData.append('value', value);

        fetch('validate_ajax.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'error') {
                msgSpan.innerHTML =  + data.message;
                msgSpan.className = "validation-msg msg-error";
            } else {
                msgSpan.innerHTML = "Looks good!";
                msgSpan.className = "validation-msg msg-success";
            }
        })
        .catch(error => console.error('Error:', error));
    }

    function showInfo() {
        alert(
            "Student Result System Info\n\n" +
            "• Select Exam Name\n" +
            "• Select Department\n" +
            "• Select Course\n" +
            "• Select Year/Semester\n" +
            "• Select Section (optional)\n" +
            "• Enter Roll Number\n" +
            "• Enter Date of Birth\n\n" +
            "Make sure details match exactly!"
        );
    }

    function toggleContact() {
        let box = document.getElementById("contactForm");
        box.style.display = (box.style.display === "block") ? "none" : "block";
    }

    // FEEDBACK MESSAGE
    function sendMsg() {
        let name  = document.getElementById("cName").value.trim();
        let email = document.getElementById("cEmail").value.trim();
        let msg   = document.getElementById("cMsg").value.trim();

        if (name === "" || email === "" || msg === "") {
            alert("Please fill all fields!");
            return;
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert("Please enter a valid email address!");
            return;
        }

        let xhr = new XMLHttpRequest();
        xhr.open("POST", "Database/save_contact.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.onload = function () {
            if (this.responseText === "success") {
                alert("Thank you for your message!");
                document.getElementById("cName").value = "";
                document.getElementById("cEmail").value = "";
                document.getElementById("cMsg").value = "";
                document.getElementById("contactForm").style.display = "none";
            } else {
                alert("Something went wrong. Try again!");
            }
        };

        xhr.send(
            "name=" + encodeURIComponent(name) +
            "&email=" + encodeURIComponent(email) +
            "&message=" + encodeURIComponent(msg)
        );
    }

    // Search Result Function
    function searchResult() {
        const examId = document.getElementById('examName').value;
        const deptId = document.getElementById('deptName').value;
        const courseId = document.getElementById('courseName').value;
        const semester = document.getElementById('yearSemester').value;
        const section = document.getElementById('section').value;
        const rollNumber = document.getElementById('rollNumber').value.trim();
        const dob = document.getElementById('dob').value;

        // Validation
        if (!examId) {
            alert('Please select an exam');
            return;
        }
        if (!deptId) {
            alert('Please select a department');
            return;
        }
        if (!courseId) {
            alert('Please select a course');
            return;
        }
        if (!semester) {
            alert('Please select a semester');
            return;
        }
        if (!rollNumber) {
            alert('Please enter roll number');
            return;
        }
        if (!dob) {
            alert('Please select date of birth');
            return;
        }

        // Show loading spinner
        document.getElementById('searchBox').style.display = 'none';
        document.getElementById('loading').style.display = 'block';
        document.getElementById('resultContainer').style.display = 'none';

        // Fetch result
        const formData = new FormData();
        formData.append('exam_id', examId);
        formData.append('dept_id', deptId);
        formData.append('course_id', courseId);
        formData.append('semester', semester);
        formData.append('section', section);
        formData.append('roll_number', rollNumber);
        formData.append('dob', dob);

        fetch('get_result.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            document.getElementById('loading').style.display = 'none';
            
            if (data.status === 'success') {
                displayResult(data.data);
            } else {
                document.getElementById('searchBox').style.display = 'block';
                alert(data.message || 'No result found for the given criteria');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('loading').style.display = 'none';
            document.getElementById('searchBox').style.display = 'block';
            alert('An error occurred. Please try again.');
        });
    }

    // Print function for A4 format
    function printMarksheet() {
        // Store original display values
        const searchBox = document.getElementById('searchBox');
        const resultContainer = document.getElementById('resultContainer');
        const loading = document.getElementById('loading');
        
        // Temporarily hide search box and show only result for printing
        const searchDisplay = searchBox.style.display;
        const resultDisplay = resultContainer.style.display;
        const loadingDisplay = loading.style.display;
        
        // Show only result container for printing
        searchBox.style.display = 'none';
        resultContainer.style.display = 'block';
        loading.style.display = 'none';
        
        // Trigger print
        window.print();
        
        // Restore original display after print dialog closes
        setTimeout(() => {
            searchBox.style.display = searchDisplay;
            resultContainer.style.display = resultDisplay;
            loading.style.display = loadingDisplay;
        }, 100);
    }

    // Display Result Function
    function displayResult(data) {
        const container = document.getElementById('resultContainer');
        const student = data.student;
        const results = data.results;
        const summary = data.summary;
        
        let html = `
            <div class="result-container" id="marksheet">
                <div class="result-header">
                    <h2>STUDENT RESULT MARKSHEET</h2>
                    <p style="margin-top: 10px; font-size: 14px; color: #667eea;">${data.exam_name} (${data.exam_type})</p>
                </div>
                
                <div class="student-info">
                    <div class="info-item">
                        <div class="info-icon">👤</div>
                        <div>
                            <strong>Name:</strong> 
                            <span>${student.first_name} ${student.middle_name ? student.middle_name + ' ' : ''}${student.last_name}</span>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">🆔</div>
                        <div>
                            <strong>Roll No:</strong> 
                            <span>${student.roll_number}</span>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">🏢</div>
                        <div>
                            <strong>Department:</strong> 
                            <span>${student.dept_name || 'N/A'}</span>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">🎓</div>
                        <div>
                            <strong>Course:</strong> 
                            <span>${data.course_name}</span>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">📚</div>
                        <div>
                            <strong>Semester:</strong> 
                            <span>${data.semester}</span>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">👥</div>
                        <div>
                            <strong>Section:</strong> 
                            <span>${student.section || 'N/A'}</span>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">📅</div>
                        <div>
                            <strong>Batch:</strong> 
                            <span>${data.batch_name || 'N/A'} ${data.batch_year ? '(' + data.batch_year + ')' : ''}</span>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">🎂</div>
                        <div>
                            <strong>DOB:</strong> 
                            <span>${student.dob}</span>
                        </div>
                    </div>
                </div>
                
                <table class="marksheet-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Subject Name</th>
                            <th>Theory<br><small>(Obt/Pass)</small></th>
                            <th>Practical<br><small>(Obt/Pass)</small></th>
                            <th>Total</th>
                            <th>Max</th>
                            <th>Grade</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        let hasFailed = false;
        
        if (results && results.length > 0) {
            results.forEach(result => {
                const gradeClass = result.grade.toLowerCase().replace('+', '-plus');
                const status = result.grade !== 'F' ? 'Pass' : 'Fail';
                const statusColor = result.grade !== 'F' ? '#28a745' : '#dc3545';
                const rowClass = result.grade === 'F' ? 'failed-subject' : '';
                
                if (result.grade === 'F') {
                    hasFailed = true;
                }
                
                // Check if theory or practical failed
                const theoryFailClass = (result.theory_marks < result.theory_pass_marks) ? 'theory-fail' : '';
                const practicalFailClass = (result.practical_marks < result.practical_pass_marks) ? 'practical-fail' : '';
                
                html += `
                    <tr class="${rowClass}">
                        <td><strong>${result.subject_code}</strong></td>
                        <td style="text-align: left;">${result.subject_name}</td>
                        <td class="${theoryFailClass}">
                            ${result.theory_marks > 0 ? result.theory_marks : '-'}
                            ${result.theory_pass_marks ? '<br><small>(' + result.theory_pass_marks + ')</small>' : ''}
                        </td>
                        <td class="${practicalFailClass}">
                            ${result.practical_marks > 0 ? result.practical_marks : '-'}
                            ${result.practical_pass_marks ? '<br><small>(' + result.practical_pass_marks + ')</small>' : ''}
                        </td>
                        <td><strong>${result.marks_obtained}</strong></td>
                        <td>${result.max_marks}</td>
                        <td><span class="grade-badge grade-${gradeClass}">${result.grade}</span></td>
                        <td style="color: ${statusColor}; font-weight: 600;">${status}</td>
                    </tr>
                `;
            });
        } else {
            html += `
                <tr>
                    <td colspan="8" style="text-align: center; color: #999; padding: 30px;">
                        No results found for this student
                    </td>
                </tr>
            `;
        }
        
        html += `
                    </tbody>
                    <tfoot style="background: #f2f2f2; font-weight: bold;">
                        <tr>
                            <td colspan="4" style="text-align: right;"><strong>Total:</strong></td>
                            <td><strong>${summary.total_marks}</strong></td>
                            <td><strong>${summary.max_marks}</strong></td>
                            <td colspan="2"></td>
                        </tr>
                    </tfoot>
                </table>
        `;
        
        // Only show summary if student passed all subjects
        if (!hasFailed && summary.status === 'PASS') {
            html += `
                <div class="summary-section">
                    <div class="summary-item">
                        <div class="summary-label">Total Marks</div>
                        <div class="summary-value total-marks">${summary.total_marks} / ${summary.max_marks}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Percentage</div>
                        <div class="summary-value percentage">${summary.percentage}%</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Overall Grade</div>
                        <div class="summary-value grade">${summary.overall_grade}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Result Status</div>
                        <div class="summary-value" style="color: #28a745;">PASS</div>
                    </div>
                </div>
            `;
        } else {
            html += `
                <div class="summary-section" style="background: #ffebee;">
                    <div class="summary-item" style="grid-column: span 4;">
                        <div class="summary-label">Result Status</div>
                        <div class="summary-value" style="color: #dc3545; font-size: 32px;">FAIL</div>
                        <p style="color: #666; margin-top: 10px;">Student has failed in one or more subjects</p>
                    </div>
                </div>
            `;
        }
        
        html += `
                <div style="margin-top: 30px; text-align: center; font-size: 12px; color: #999; border-top: 1px dashed #ddd; padding-top: 20px;">
                    <p>This is demonstrated program for Student Result Management System - SRMS.</p></br>
                    <p>Prepared By Bimal Acharya & Albert Bantawa.</p>
                    <p>Date: ${new Date().toLocaleDateString()}</p>
                </div>
            </div>
            
            <div class="action-buttons">
                <button class="btn btn-print" onclick="printMarksheet()">
                    <img src="icons/Print.png" style="height: 22px; vertical-align: middle; margin-right: 10px;">Print A4
                </button>
                <button class="btn btn-back" onclick="backToSearch()">
                    <img src="icons/Search.png" style="height: 22px; vertical-align: middle; margin-right: 10px;">New Search
                </button>
            </div>
        `;
        
        container.innerHTML = html;
        container.style.display = 'block';
        
        // Scroll to result
        container.scrollIntoView({ behavior: 'smooth' });
        
        // Ensure buttons are clickable
        setTimeout(() => {
            const printBtn = document.querySelector('.btn-print');
            const backBtn = document.querySelector('.btn-back');
            
            if (printBtn) {
                printBtn.style.pointerEvents = 'auto';
                printBtn.style.cursor = 'pointer';
                printBtn.onclick = function(e) {
                    e.preventDefault();
                    printMarksheet();
                    return false;
                };
            }
            
            if (backBtn) {
                backBtn.style.pointerEvents = 'auto';
                backBtn.style.cursor = 'pointer';
                backBtn.onclick = function(e) {
                    e.preventDefault();
                    backToSearch();
                    return false;
                };
            }
        }, 100);
    }
    
    function backToSearch() {
        document.getElementById('resultContainer').style.display = 'none';
        document.getElementById('searchBox').style.display = 'block';
        
        // Clear form
        document.getElementById('examName').value = '';
        document.getElementById('deptName').value = '';
        document.getElementById('courseName').innerHTML = '<option value="">Select Department First</option>';
        document.getElementById('courseName').disabled = true;
        document.getElementById('yearSemester').value = '';
        document.getElementById('section').value = '';
        document.getElementById('rollNumber').value = '';
        document.getElementById('dob').value = '';
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    // Add email validation on blur
    document.getElementById('cEmail').addEventListener('blur', function() {
        const email = this.value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const msgSpan = document.getElementById('msg_cEmail');
        
        if (email && !emailRegex.test(email)) {
            msgSpan.innerHTML = " Please enter a valid email address";
            msgSpan.className = "validation-msg msg-error";
        }
    });

    // Enter key press for search
    document.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && document.getElementById('searchBox').style.display !== 'none') {
            searchResult();
        }
    });
    </script>

</body>
</html>