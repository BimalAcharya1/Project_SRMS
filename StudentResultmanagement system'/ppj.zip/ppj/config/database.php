<?php
class Database {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "srmsdb"; // Changed to lowercase to match the database name
    public $conn;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);
        
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
        
        // Set charset to utf8mb4
        $this->conn->set_charset("utf8mb4");
        
        return $this->conn;
    }

    public function getConnection() {
        return $this->conn;
    }

    public function runQuery($sql) {
        $result = $this->conn->query($sql);
        return $result;
    }

    public function escapeString($string) {
        return $this->conn->real_escape_string($string);
    }
}
?>