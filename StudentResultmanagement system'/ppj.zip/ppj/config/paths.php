<?php
// config/paths.php
define('ADMIN_UPLOAD_PATH', 'uploads/admin/');
define('ADMIN_UPLOAD_URL', 'uploads/admin/');