<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Handle Add/Edit/Delete operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add') {
            $course_name = $database->escapeString($_POST['course_name']);
            $dept_id = $_POST['dept_id'];
            $total_semesters = $_POST['total_semesters'];
            $duration_years = $_POST['duration_years'];
            
            // Check if course name already exists in the same department
            $check_course = $conn->query("SELECT course_id FROM Course WHERE course_name = '$course_name' AND dept_id = $dept_id");
            if ($check_course->num_rows > 0) {
                $_SESSION['message'] = "Course name already exists in this department! Please use a different name.";
                $_SESSION['msg_type'] = "error";
                header("Location: courses.php");
                exit();
            }
            
            $sql = "INSERT INTO Course (course_name, dept_id, total_semesters, duration_years) 
                    VALUES ('$course_name', $dept_id, $total_semesters, $duration_years)";
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Course added successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
        }
        
        elseif ($action == 'edit') {
            $course_id = $_POST['course_id'];
            $course_name = $database->escapeString($_POST['course_name']);
            $dept_id = $_POST['dept_id'];
            $total_semesters = $_POST['total_semesters'];
            $duration_years = $_POST['duration_years'];
            
            // Check if course name already exists in the same department for another course
            $check_course = $conn->query("SELECT course_id FROM Course WHERE course_name = '$course_name' AND dept_id = $dept_id AND course_id != $course_id");
            if ($check_course->num_rows > 0) {
                $_SESSION['message'] = "Course name already exists in this department! Please use a different name.";
                $_SESSION['msg_type'] = "error";
                header("Location: courses.php");
                exit();
            }
            
            $sql = "UPDATE Course SET course_name='$course_name', dept_id=$dept_id, 
                    total_semesters=$total_semesters, duration_years=$duration_years 
                    WHERE course_id=$course_id";
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Course updated successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
        }
        
        elseif ($action == 'delete') {
    $course_id = $_POST['course_id'];
    
    // Optional: Show warning message about cascade delete
    $_SESSION['message'] = "Course deleted successfully! All associated subjects, teacher allocations, exam subjects, and results have been removed.";
    $_SESSION['msg_type'] = "success";
    
    // Simple delete - cascade will handle everything
    $sql = "DELETE FROM Course WHERE course_id=$course_id";
    
    if ($conn->query($sql)) {
        $_SESSION['message'] = "Course deleted successfully! All associated subjects, teacher allocations, exam subjects, and results have been removed.";
        $_SESSION['msg_type'] = "success";
    } else {
        $_SESSION['message'] = "Error: " . $conn->error;
        $_SESSION['msg_type'] = "error";
    }
}
        
        header("Location: courses.php");
        exit();
    }
}

// Handle AJAX validation requests
if (isset($_GET['ajax']) && $_GET['ajax'] == 'validate') {
    $field = $_GET['field'];
    $value = $database->escapeString($_GET['value']);
    $dept_id = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;
    $current_id = isset($_GET['current_id']) ? intval($_GET['current_id']) : 0;
    
    $response = ['valid' => true, 'message' => ''];
    
    if ($field == 'course_name') {
        if ($dept_id > 0) {
            $query = "SELECT course_id FROM Course WHERE course_name = '$value' AND dept_id = $dept_id";
            if ($current_id > 0) {
                $query .= " AND course_id != $current_id";
            }
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                $response['valid'] = false;
                $response['message'] = 'Course name already exists in this department';
            }
        } else {
            $response['valid'] = false;
            $response['message'] = 'Please select a department first';
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Handle department filter
$dept_filter = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;

// Get all courses with department names and filter
$course_query = "
    SELECT c.*, d.dept_name 
    FROM Course c
    LEFT JOIN Department d ON c.dept_id = d.dept_id
";

if ($dept_filter > 0) {
    $course_query .= " WHERE c.dept_id = $dept_filter";
}

$course_query .= " ORDER BY d.dept_name, c.course_name";
$courses = $conn->query($course_query);

// Get departments for filter dropdown
$departments = $conn->query("SELECT * FROM Department ORDER BY dept_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Manage Courses - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Additional styles for validation */
        .validation-message {
            font-size: 12px;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .validation-success {
            color: #28a745;
        }
        .validation-error {
            color: #dc3545;
        }
        .validation-spinner {
            display: inline-block;
            width: 12px;
            height: 12px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 5px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .input-error {
            border-color: #dc3545 !important;
        }
        .input-success {
            border-color: #28a745 !important;
        }
        .form-group {
            position: relative;
            margin-bottom: 15px;
        }
        .required-field::after {
            content: " *";
            color: red;
        }
        .badge-info {
            background-color: #17a2b8;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 11px;
            margin-left: 5px;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                   <a href="adminDashboard.php">
            <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
            </a>
               <a href="departments.php">
            <img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5>
            </a>
                <a href="courses.php" class="active">
            <img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5>
            </a>
                  <a href="subjects.php">
            <img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5>
        </a>

          <a href="teachers.php">
            <img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5>
        </a>

         <a href="students.php">
            <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5>
        </a>
         

        <a href="allocations.php">
            <img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5>
        </a>
        <a href="exams.php">
            <img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5>
        </a>
        <a href="results.php">
            <img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5>
        </a>

        <a href="feedbacks.php">
            <img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5>
        </a>
        <a href="settings.php">
            <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5>
        </a>
        <a href="../logout.php">
            <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5>
        </a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2> <img src="../icons/Course.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Manage Courses</h2>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <!-- Department Filter Dropdown -->
                        <select id="dept_filter" onchange="filterByDepartment()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 200px;">
                            <option value="0">All Departments</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                                $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $dept['dept_name']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        
                        <!-- Clear Filters Button -->
                        <?php if($dept_filter > 0): ?>
                        <button class="btn btn-secondary" onclick="clearFilters()">Clear Filters</button>
                        <?php endif; ?>
                        
                        <button class="btn" onclick="$('#addModal').show()">Add New Course <img src="../icons/Add.png" style="height: 27px; vertical-align: middle; margin-right: 10px;"></button>
                    </div>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Course Name</th>
                            <th>Department</th>
                            <th>Total Semesters</th>
                            <th>Duration (Years)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($courses->num_rows > 0): ?>
                            <?php while($row = $courses->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['course_id']; ?></td>
                                <td><?php echo $row['course_name']; ?></td>
                                <td>
                                    <?php if($row['dept_id']): ?>
                                        <a href="?dept_id=<?php echo $row['dept_id']; ?>" style="text-decoration: none; color: inherit;">
                                            <?php echo $row['dept_name'] ?? 'N/A'; ?>
                                        </a>
                                    <?php else: ?>
                                        <?php echo 'N/A'; ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $row['total_semesters']; ?></td>
                                <td><?php echo $row['duration_years']; ?></td>
                                <td>
                                    <button class="action-btn edit-btn" onclick="editCourse(<?php echo htmlspecialchars(json_encode($row)); ?>)" title="Edit"><img src="../icons/Edit.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></button>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this course? This will also delete all associated subjects and allocations.')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="course_id" value="<?php echo $row['course_id']; ?>">
                                        <button type="submit" class="action-btn delete-btn" title="Delete"><img src="../icons/Delete.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 20px;">
                                    No courses found
                                    <?php if($dept_filter > 0): ?>
                                        in this department. <a href="courses.php">View all courses</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Add New Course</h2>
            <form method="POST" id="addForm" onsubmit="return validateAddForm()">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label class="required-field">Department</label>
                    <select name="dept_id" id="add_dept_id" required onchange="validateCourseName('add')">
                        <option value="">--Select Department--</option>
                        <?php 
                        $departments->data_seek(0);
                        while($dept = $departments->fetch_assoc()): 
                            $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                        ?>
                        <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                            <?php echo $dept['dept_name']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="required-field">Course Name</label>
                    <input type="text" name="course_name" id="add_course_name" placeholder="e.g., Bachelor of Computer Applications" required onkeyup="validateCourseName('add')" onchange="validateCourseName('add')">
                    <div id="add_course_name_validation" class="validation-message"></div>
                </div>
                
                
                <div class="form-group">
                    <label class="required-field">Total Semesters</label>
                    <input type="number" name="total_semesters" id="add_total_semesters" min="1" max="12" value="8" required>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Duration (Years)</label>
                    <input type="number" name="duration_years" id="add_duration_years" min="1" max="6" value="4" required>
                </div>
                
                <button type="submit" class="btn" id="add_submit_btn">Add Course</button>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Edit Course</h2>
            <form method="POST" id="editForm" onsubmit="return validateEditForm()">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="course_id" id="edit_course_id">

                  <div class="form-group">
                    <label class="required-field">Department</label>
                    <select name="dept_id" id="edit_dept_id" required onchange="validateCourseName('edit')">
                        <option value="">--Select Department--</option>
                        <?php 
                        $departments->data_seek(0);
                        while($dept = $departments->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $dept['dept_id']; ?>"><?php echo $dept['dept_name']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Course Name</label>
                    <input type="text" name="course_name" id="edit_course_name" required onkeyup="validateCourseName('edit')" onchange="validateCourseName('edit')">
                    <div id="edit_course_name_validation" class="validation-message"></div>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Total Semesters</label>
                    <input type="number" name="total_semesters" id="edit_total_semesters" min="1" max="12" required>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Duration (Years)</label>
                    <input type="number" name="duration_years" id="edit_duration_years" min="1" max="6" required>
                </div>
                
                <button type="submit" class="btn" id="edit_submit_btn">Update Course</button>
            </form>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        let validationTimeouts = {};
        let validationState = {
            add: { course_name: false },
            edit: { course_name: false }
        };
        
        function validateCourseName(modal) {
            const courseName = document.getElementById(modal + '_course_name').value.trim();
            const deptId = document.getElementById(modal + '_dept_id').value;
            const currentId = modal === 'edit' ? document.getElementById('edit_course_id').value : 0;
            const validationDiv = document.getElementById(modal + '_course_name_validation');
            const inputField = document.getElementById(modal + '_course_name');
            const submitBtn = document.getElementById(modal + '_submit_btn');
            
            // Clear previous timeout
            if (validationTimeouts[modal + '_course_name']) {
                clearTimeout(validationTimeouts[modal + '_course_name']);
            }
            
            // Reset validation state
            validationState[modal].course_name = false;
            
            // Check if department is selected
            if (!deptId) {
                validationDiv.innerHTML = '<span class="validation-error"> Please select a department first</span>';
                inputField.classList.add('input-error');
                inputField.classList.remove('input-success');
                updateSubmitButton(modal);
                return;
            }
            
            // Check if course name is empty
            if (courseName.length === 0) {
                validationDiv.innerHTML = '';
                inputField.classList.remove('input-error', 'input-success');
                updateSubmitButton(modal);
                return;
            }
            
            // Show loading state
            validationDiv.innerHTML = '<span class="validation-spinner"></span> Checking availability...';
            inputField.classList.remove('input-error', 'input-success');
            
            // Set timeout to avoid too many requests
            validationTimeouts[modal + '_course_name'] = setTimeout(() => {
                fetch(`courses.php?ajax=validate&field=course_name&value=${encodeURIComponent(courseName)}&dept_id=${deptId}&current_id=${currentId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.valid) {
                            validationDiv.innerHTML = '<span class="validation-success">✓ Course name available</span>';
                            inputField.classList.add('input-success');
                            inputField.classList.remove('input-error');
                            validationState[modal].course_name = true;
                        } else {
                            validationDiv.innerHTML = `<span class="validation-error"> ${data.message}</span>`;
                            inputField.classList.add('input-error');
                            inputField.classList.remove('input-success');
                            validationState[modal].course_name = false;
                        }
                        updateSubmitButton(modal);
                    })
                    .catch(error => {
                        console.error('Validation error:', error);
                        validationDiv.innerHTML = '<span class="validation-error">⚠ Validation failed</span>';
                        validationState[modal].course_name = true; // Allow submission on error
                        updateSubmitButton(modal);
                    });
            }, 500);
        }
        
        function updateSubmitButton(modal) {
            const submitBtn = document.getElementById(modal + '_submit_btn');
            const state = validationState[modal];
            
            if (state.course_name) {
                submitBtn.disabled = false;
                submitBtn.style.opacity = '1';
                submitBtn.style.cursor = 'pointer';
            } else {
                submitBtn.disabled = true;
                submitBtn.style.opacity = '0.5';
                submitBtn.style.cursor = 'not-allowed';
            }
        }
        
        function validateAddForm() {
            const state = validationState.add;
            if (!state.course_name) {
                alert('Please fix validation errors before submitting.');
                return false;
            }
            return true;
        }
        
        function validateEditForm() {
            const state = validationState.edit;
            if (!state.course_name) {
                alert('Please fix validation errors before submitting.');
                return false;
            }
            return true;
        }
        
        function filterByDepartment() {
            var deptId = document.getElementById('dept_filter').value;
            var url = 'courses.php';
            if (deptId > 0) {
                url += '?dept_id=' + deptId;
            }
            window.location.href = url;
        }
        
        function clearFilters() {
            window.location.href = 'courses.php';
        }
        
        function editCourse(course) {
            $('#edit_course_id').val(course.course_id);
            $('#edit_course_name').val(course.course_name);
            $('#edit_dept_id').val(course.dept_id);
            $('#edit_total_semesters').val(course.total_semesters);
            $('#edit_duration_years').val(course.duration_years);
            
            // Reset validation state for edit modal
            validationState.edit = { course_name: true };
            
            // Clear validation messages
            document.getElementById('edit_course_name_validation').innerHTML = '';
            
            // Remove input classes
            document.getElementById('edit_course_name').classList.remove('input-error', 'input-success');
            
            // Enable submit button
            document.getElementById('edit_submit_btn').disabled = false;
            document.getElementById('edit_submit_btn').style.opacity = '1';
            
            $('#editModal').show();
        }
        
        // Pre-select department in add modal if filter is active
        $(document).ready(function() {
            var deptFilter = <?php echo $dept_filter; ?>;
            if (deptFilter > 0) {
                $('select[name="dept_id"]').val(deptFilter);
            }
        });
        
        // Reset validation when opening add modal
        $('#addModal').on('click', function() {
            setTimeout(() => {
                validationState.add = { course_name: false };
                document.getElementById('add_course_name_validation').innerHTML = '';
                document.getElementById('add_course_name').classList.remove('input-error', 'input-success');
                document.getElementById('add_submit_btn').disabled = true;
                document.getElementById('add_submit_btn').style.opacity = '0.5';
            }, 100);
        });
        
        // Initialize validation for add modal fields when they get focus
        document.getElementById('add_course_name').addEventListener('focus', function() {
            if (this.value.trim() !== '') {
                validateCourseName('add');
            }
        });
        
        document.getElementById('add_dept_id').addEventListener('change', function() {
            if (document.getElementById('add_course_name').value.trim() !== '') {
                validateCourseName('add');
            }
        });
        
        document.getElementById('edit_dept_id').addEventListener('change', function() {
            if (document.getElementById('edit_course_name').value.trim() !== '') {
                validateCourseName('edit');
            }
        });
    </script>
    
    <style>
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        @media (max-width: 768px) {
            .card-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .card-header > div {
                width: 100%;
            }
            #dept_filter {
                width: 100%;
            }
        }
    </style>
</body>
</html>