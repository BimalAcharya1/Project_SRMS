<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Handle Add/Edit/Delete operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add') {
            $exam_name = $database->escapeString($_POST['exam_name']);
            $exam_type = $_POST['exam_type'];
            $dept_id = $_POST['dept_id'];
            $course_id = $_POST['course_id'];
            $semester = $_POST['semester'];
            $section = $database->escapeString($_POST['section']);
            
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Check if exam with same name and type already exists
                $check_sql = "SELECT e.exam_id 
                              FROM exam e
                              JOIN exam_subject es ON e.exam_id = es.exam_id
                              JOIN subject s ON es.subject_id = s.subject_id
                              JOIN course c ON s.course_id = c.course_id
                              JOIN department d ON c.dept_id = d.dept_id
                              LEFT JOIN teacher_allocation ta ON s.subject_id = ta.subject_id
                              WHERE e.exam_name = '$exam_name' 
                              AND e.exam_type = '$exam_type'
                              AND d.dept_id = $dept_id
                              AND c.course_id = $course_id
                              AND s.semester_number = $semester
                              AND ta.section = '$section'
                              LIMIT 1";
                $check_result = $conn->query($check_sql);
                
                if ($check_result && $check_result->num_rows > 0) {
                    throw new Exception("An exam with this name and type already exists for this department, course, semester, and section!");
                }
                
                // Insert main exam record
                $sql = "INSERT INTO exam (exam_name, exam_type, exam_date) VALUES ('$exam_name', '$exam_type', CURDATE())";
                if (!$conn->query($sql)) {
                    throw new Exception("Error inserting exam: " . $conn->error);
                }
                $exam_id = $conn->insert_id;
                
                $subjects_added = 0;
                
                // Debug: Log what we're receiving
                error_log("POST data: " . print_r($_POST, true));
                
                // Process compulsory subjects (automatically included)
                if (isset($_POST['compulsory_subjects']) && is_array($_POST['compulsory_subjects'])) {
                    foreach ($_POST['compulsory_subjects'] as $subject_id) {
                        $subject_id = intval($subject_id);
                        
                        // Get marks for this subject
                        $theory_full = isset($_POST['theory_full_' . $subject_id]) ? intval($_POST['theory_full_' . $subject_id]) : 60;
                        $theory_pass = isset($_POST['theory_pass_' . $subject_id]) ? intval($_POST['theory_pass_' . $subject_id]) : 24;
                        $practical_full = isset($_POST['practical_full_' . $subject_id]) && !empty($_POST['practical_full_' . $subject_id]) ? intval($_POST['practical_full_' . $subject_id]) : 0;
                        $practical_pass = isset($_POST['practical_pass_' . $subject_id]) && !empty($_POST['practical_pass_' . $subject_id]) ? intval($_POST['practical_pass_' . $subject_id]) : 0;
                        $exam_date = isset($_POST['exam_date_' . $subject_id]) ? $_POST['exam_date_' . $subject_id] : date('Y-m-d');
                        
                        error_log("Processing compulsory subject: $subject_id, date: $exam_date");
                        
                        // Validate that exam date is not in the past
                        $today = date('Y-m-d');
                        if ($exam_date < $today) {
                            throw new Exception("Exam date for subject cannot be in the past!");
                        }
                        
                        // Validate total marks = 100
                        $total_marks = $theory_full + $practical_full;
                        if ($practical_full > 0) {
                            if ($total_marks != 100) {
                                throw new Exception("Total marks (Theory + Practical) must equal 100 for subject. Current total: " . $total_marks);
                            }
                        } else {
                            if ($theory_full != 100) {
                                throw new Exception("Theory marks must be 100 when no practical component. Current theory marks: " . $theory_full);
                            }
                        }
                        
                        // Validate pass marks are not greater than full marks
                        if ($theory_pass > $theory_full) {
                            throw new Exception("Theory pass marks cannot be greater than theory full marks!");
                        }
                        if ($practical_pass > $practical_full) {
                            throw new Exception("Practical pass marks cannot be greater than practical full marks!");
                        }
                        
                        $practical_full_sql = $practical_full > 0 ? $practical_full : 'NULL';
                        $practical_pass_sql = $practical_pass > 0 ? $practical_pass : 'NULL';
                        
                        $sql = "INSERT INTO exam_subject (exam_id, subject_id, exam_date, theory_full_marks, theory_pass_marks, practical_full_marks, practical_pass_marks) 
                                VALUES ($exam_id, $subject_id, '$exam_date', $theory_full, $theory_pass, $practical_full_sql, $practical_pass_sql)";
                        
                        if ($conn->query($sql)) {
                            $subjects_added++;
                            error_log("Added compulsory subject: $subject_id");
                        } else {
                            throw new Exception("Error inserting subject: " . $conn->error);
                        }
                    }
                }
                
                // Process optional/elective subjects (selected via checkboxes)
                if (isset($_POST['optional_subjects']) && is_array($_POST['optional_subjects'])) {
                    foreach ($_POST['optional_subjects'] as $subject_id) {
                        $subject_id = intval($subject_id);
                        
                        // Get marks for this subject
                        $theory_full = isset($_POST['theory_full_' . $subject_id]) ? intval($_POST['theory_full_' . $subject_id]) : 60;
                        $theory_pass = isset($_POST['theory_pass_' . $subject_id]) ? intval($_POST['theory_pass_' . $subject_id]) : 24;
                        $practical_full = isset($_POST['practical_full_' . $subject_id]) && !empty($_POST['practical_full_' . $subject_id]) ? intval($_POST['practical_full_' . $subject_id]) : 0;
                        $practical_pass = isset($_POST['practical_pass_' . $subject_id]) && !empty($_POST['practical_pass_' . $subject_id]) ? intval($_POST['practical_pass_' . $subject_id]) : 0;
                        $exam_date = isset($_POST['exam_date_' . $subject_id]) ? $_POST['exam_date_' . $subject_id] : date('Y-m-d');
                        
                        error_log("Processing optional subject: $subject_id, date: $exam_date");
                        
                        // Validate that exam date is not in the past
                        $today = date('Y-m-d');
                        if ($exam_date < $today) {
                            throw new Exception("Exam date for subject cannot be in the past!");
                        }
                        
                        // Validate total marks = 100
                        $total_marks = $theory_full + $practical_full;
                        if ($practical_full > 0) {
                            if ($total_marks != 100) {
                                throw new Exception("Total marks (Theory + Practical) must equal 100 for subject. Current total: " . $total_marks);
                            }
                        } else {
                            if ($theory_full != 100) {
                                throw new Exception("Theory marks must be 100 when no practical component. Current theory marks: " . $theory_full);
                            }
                        }
                        
                        // Validate pass marks are not greater than full marks
                        if ($theory_pass > $theory_full) {
                            throw new Exception("Theory pass marks cannot be greater than theory full marks!");
                        }
                        if ($practical_pass > $practical_full) {
                            throw new Exception("Practical pass marks cannot be greater than practical full marks!");
                        }
                        
                        $practical_full_sql = $practical_full > 0 ? $practical_full : 'NULL';
                        $practical_pass_sql = $practical_pass > 0 ? $practical_pass : 'NULL';
                        
                        $sql = "INSERT INTO exam_subject (exam_id, subject_id, exam_date, theory_full_marks, theory_pass_marks, practical_full_marks, practical_pass_marks) 
                                VALUES ($exam_id, $subject_id, '$exam_date', $theory_full, $theory_pass, $practical_full_sql, $practical_pass_sql)";
                        
                        if ($conn->query($sql)) {
                            $subjects_added++;
                            error_log("Added optional subject: $subject_id");
                        } else {
                            throw new Exception("Error inserting subject: " . $conn->error);
                        }
                    }
                }
                
                // Check if at least one subject was added
                if ($subjects_added == 0) {
                    throw new Exception("No subjects were added to the exam!");
                }
                
                $conn->commit();
                $_SESSION['message'] = "Exam scheduled successfully with " . $subjects_added . " subjects!";
                $_SESSION['msg_type'] = "success";
                
            } catch (Exception $e) {
                $conn->rollback();
                $_SESSION['message'] = "Error: " . $e->getMessage();
                $_SESSION['msg_type'] = "error";
                error_log("Exam creation error: " . $e->getMessage());
            }
            
            header("Location: exams.php");
            exit();
        } elseif ($action == 'delete') {
            $exam_id = $_POST['exam_id'];
            
            // Simple delete - cascade will handle exam_subjects and results
            $sql = "DELETE FROM exam WHERE exam_id=$exam_id";
            
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Exam deleted successfully! All associated subject schedules and results have been removed.";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
            
            header("Location: exams.php");
            exit();
        }
    }
}

// Handle AJAX request to get exam details
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_exam_details') {
    $exam_id = intval($_GET['exam_id']);
    
    // Get exam main details
    $exam_query = "SELECT e.* 
                   FROM exam e
                   WHERE e.exam_id = $exam_id";
    $exam_result = $conn->query($exam_query);
    $exam = $exam_result->fetch_assoc();
    
    // Get all subjects for this exam with their individual dates
    $subjects_query = "SELECT es.*, 
                              s.subject_name, 
                              s.subject_code, 
                              s.subject_type, 
                              s.semester_number,
                              c.course_name, 
                              d.dept_name
                       FROM exam_subject es
                       JOIN subject s ON es.subject_id = s.subject_id
                       LEFT JOIN course c ON s.course_id = c.course_id
                       LEFT JOIN department d ON c.dept_id = d.dept_id
                       WHERE es.exam_id = $exam_id
                       ORDER BY es.exam_date, s.subject_name";
    $subjects_result = $conn->query($subjects_query);
    
    $subjects = [];
    while ($row = $subjects_result->fetch_assoc()) {
        $subjects[] = $row;
    }
    
    // Get unique departments and courses for display
    $dept_query = "SELECT DISTINCT d.dept_id, d.dept_name 
                   FROM exam_subject es
                   JOIN subject s ON es.subject_id = s.subject_id
                   JOIN course c ON s.course_id = c.course_id
                   JOIN department d ON c.dept_id = d.dept_id
                   WHERE es.exam_id = $exam_id";
    $dept_result = $conn->query($dept_query);
    $departments = [];
    while ($row = $dept_result->fetch_assoc()) {
        $departments[] = $row;
    }
    
    $course_query = "SELECT DISTINCT c.course_id, c.course_name 
                     FROM exam_subject es
                     JOIN subject s ON es.subject_id = s.subject_id
                     JOIN course c ON s.course_id = c.course_id
                     WHERE es.exam_id = $exam_id";
    $course_result = $conn->query($course_query);
    $courses = [];
    while ($row = $course_result->fetch_assoc()) {
        $courses[] = $row;
    }
    
    $semester_query = "SELECT DISTINCT s.semester_number 
                       FROM exam_subject es
                       JOIN subject s ON es.subject_id = s.subject_id
                       WHERE es.exam_id = $exam_id
                       ORDER BY s.semester_number";
    $semester_result = $conn->query($semester_query);
    $semesters = [];
    while ($row = $semester_result->fetch_assoc()) {
        $semesters[] = $row['semester_number'];
    }
    
    $section_query = "SELECT DISTINCT ta.section 
                      FROM exam_subject es
                      JOIN subject s ON es.subject_id = s.subject_id
                      LEFT JOIN teacher_allocation ta ON s.subject_id = ta.subject_id
                      WHERE es.exam_id = $exam_id AND ta.section IS NOT NULL";
    $section_result = $conn->query($section_query);
    $sections = [];
    while ($row = $section_result->fetch_assoc()) {
        $sections[] = $row['section'];
    }
    
    echo json_encode([
        'exam' => $exam,
        'subjects' => $subjects,
        'departments' => $departments,
        'courses' => $courses,
        'semesters' => $semesters,
        'sections' => $sections,
        'total_subjects' => count($subjects)
    ]);
    exit();
}

// Handle AJAX request to check if date is valid
if (isset($_GET['ajax']) && $_GET['ajax'] == 'check_date') {
    $date = $_GET['date'];
    $today = date('Y-m-d');
    
    $response = ['valid' => true, 'message' => ''];
    
    if ($date < $today) {
        $response['valid'] = false;
        $response['message'] = 'Exam date cannot be in the past';
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Handle AJAX request to check if exam already exists
if (isset($_GET['ajax']) && $_GET['ajax'] == 'check_exam_exists') {
    $exam_name = $database->escapeString($_GET['exam_name']);
    $exam_type = $_GET['exam_type'];
    $dept_id = intval($_GET['dept_id']);
    $course_id = intval($_GET['course_id']);
    $semester = intval($_GET['semester']);
    $section = $database->escapeString($_GET['section']);
    
    $check_sql = "SELECT e.exam_id 
                  FROM exam e
                  JOIN exam_subject es ON e.exam_id = es.exam_id
                  JOIN subject s ON es.subject_id = s.subject_id
                  JOIN course c ON s.course_id = c.course_id
                  JOIN department d ON c.dept_id = d.dept_id
                  LEFT JOIN teacher_allocation ta ON s.subject_id = ta.subject_id
                  WHERE e.exam_name = '$exam_name' 
                  AND e.exam_type = '$exam_type'
                  AND d.dept_id = $dept_id
                  AND c.course_id = $course_id
                  AND s.semester_number = $semester
                  AND ta.section = '$section'
                  LIMIT 1";
    
    $result = $conn->query($check_sql);
    $exists = ($result && $result->num_rows > 0);
    
    echo json_encode(['exists' => $exists]);
    exit();
}

// Handle AJAX request to check if compulsory subjects exist
if (isset($_GET['ajax']) && $_GET['ajax'] == 'check_compulsory_subjects') {
    $course_id = intval($_GET['course_id']);
    $semester = intval($_GET['semester']);
    
    $check_sql = "SELECT COUNT(*) as count FROM subject 
                  WHERE course_id = $course_id 
                  AND semester_number = $semester 
                  AND subject_type = 'Compulsory'";
    
    $result = $conn->query($check_sql);
    $row = $result->fetch_assoc();
    $hasCompulsory = ($row['count'] > 0);
    
    echo json_encode(['hasCompulsory' => $hasCompulsory]);
    exit();
}

// Handle filters
$dept_filter = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;
$course_filter = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$semester_filter = isset($_GET['semester']) ? intval($_GET['semester']) : 0;
$section_filter = isset($_GET['section']) ? $database->escapeString($_GET['section']) : '';

// Get all exams with subject counts and dates
$exams_query = "
    SELECT e.*, 
           COUNT(DISTINCT es.id) as subject_count,
           MIN(es.exam_date) as first_exam_date,
           MAX(es.exam_date) as last_exam_date,
           GROUP_CONCAT(DISTINCT d.dept_name SEPARATOR ', ') as dept_names,
           GROUP_CONCAT(DISTINCT c.course_name SEPARATOR ', ') as course_names,
           GROUP_CONCAT(DISTINCT s.semester_number ORDER BY s.semester_number SEPARATOR ', ') as semesters,
           GROUP_CONCAT(DISTINCT ta.section SEPARATOR ', ') as sections,
           GROUP_CONCAT(DISTINCT es.exam_date ORDER BY es.exam_date SEPARATOR '|') as all_dates
    FROM exam e
    INNER JOIN exam_subject es ON e.exam_id = es.exam_id
    LEFT JOIN subject s ON es.subject_id = s.subject_id
    LEFT JOIN course c ON s.course_id = c.course_id
    LEFT JOIN department d ON c.dept_id = d.dept_id
    LEFT JOIN teacher_allocation ta ON s.subject_id = ta.subject_id
    WHERE 1=1
";

if ($dept_filter > 0) {
    $exams_query .= " AND d.dept_id = $dept_filter";
}

if ($course_filter > 0) {
    $exams_query .= " AND c.course_id = $course_filter";
}

if ($semester_filter > 0) {
    $exams_query .= " AND s.semester_number = $semester_filter";
}

if (!empty($section_filter)) {
    $exams_query .= " AND ta.section = '$section_filter'";
}

$exams_query .= " GROUP BY e.exam_id ORDER BY e.exam_id DESC";
$exams = $conn->query($exams_query);

// Get departments for filter dropdown
$departments = $conn->query("SELECT * FROM department ORDER BY dept_name");

// Get courses based on selected department
$course_filter_query = "SELECT c.*, d.dept_name FROM course c LEFT JOIN department d ON c.dept_id = d.dept_id";
if ($dept_filter > 0) {
    $course_filter_query .= " WHERE c.dept_id = $dept_filter";
}
$course_filter_query .= " ORDER BY c.course_name";
$filter_courses = $conn->query($course_filter_query);

// Get all courses for forms
$all_courses = $conn->query("SELECT c.*, d.dept_name FROM course c LEFT JOIN department d ON c.dept_id = d.dept_id ORDER BY d.dept_name, c.course_name");

// Get unique sections from allocations
$sections = $conn->query("SELECT DISTINCT section FROM teacher_allocation WHERE section IS NOT NULL AND section != '' ORDER BY section");

// Get all subjects for JavaScript
$all_subjects = $conn->query("SELECT s.*, c.course_id, c.course_name FROM subject s JOIN course c ON s.course_id = c.course_id ORDER BY s.semester_number, s.subject_name");

// Get today's date for JavaScript validation
$today = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Manage Exams - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .subject-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            background-color: #f9f9f9;
            transition: all 0.3s;
        }
        .subject-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-color: #667eea;
        }
        .subject-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e0e0e0;
        }
        .subject-header input[type="checkbox"] {
            margin-right: 10px;
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        .subject-header input[type="checkbox"]:disabled {
            cursor: not-allowed;
            opacity: 0.6;
        }
        .subject-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-top: 10px;
        }
        .marks-input {
            display: flex;
            flex-direction: column;
        }
        .marks-input label {
            font-size: 12px;
            color: #666;
            margin-bottom: 3px;
            font-weight: 500;
        }
        .marks-input input {
            padding: 8px 10px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
            transition: all 0.3s;
        }
        .marks-input input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .marks-input input.error {
            border-color: #dc3545;
            background-color: #fff8f8;
        }
        .marks-input input.success {
            border-color: #28a745;
            background-color: #f8fff8;
        }
        .compulsory-badge {
            background-color: #007bff;
            color: white;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        .optional-badge {
            background-color: #28a745;
            color: white;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        .elective-badge {
            background-color: #ffc107;
            color: black;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 600;
            border-radius: 4px;
        }
        .badge-primary {
            background-color: #007bff;
            color: white;
        }
        .badge-success {
            background-color: #28a745;
            color: white;
        }
        .badge-warning {
            background-color: #ffc107;
            color: black;
        }
        .badge-info {
            background-color: #17a2b8;
            color: white;
        }
        .badge-purple {
            background-color: #6f42c1;
            color: white;
        }
        .badge-secondary {
            background-color: #6c757d;
            color: white;
        }
        .exam-dates {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .exam-actions {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        .validation-message {
            font-size: 11px;
            margin-top: 3px;
            font-weight: 500;
        }
        .validation-message.error {
            color: #dc3545;
        }
        .validation-message.success {
            color: #28a745;
        }
        .date-hint {
            font-size: 11px;
            color: #666;
            margin-top: 3px;
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .form-group label {
            font-weight: 600;
            margin-bottom: 5px;
            display: block;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        /* Exam Details Modal Styles */
        .exam-info-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 4px solid #667eea;
        }
        
        .exam-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
        }
        
        .info-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 3px;
        }
        
        .info-value {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }
        
        .subjects-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .subjects-table th {
            background: #667eea;
            color: white;
            padding: 12px;
            text-align: left;
            font-size: 13px;
        }
        
        .subjects-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .subjects-table tr:hover {
            background: #f8f9fa;
        }
        
        .date-badge {
            display: inline-block;
            padding: 3px 8px;
            background: #e8f4fd;
            color: #007bff;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .marks-badge {
            display: inline-block;
            padding: 3px 8px;
            background: #d4edda;
            color: #28a745;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .practical-badge {
            display: inline-block;
            padding: 3px 8px;
            background: #fff3cd;
            color: #856404;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .date-range {
            display: flex;
            align-items: center;
            gap: 5px;
            flex-wrap: wrap;
        }
        
        .date-item {
            background: #e8f4fd;
            color: #007bff;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 11px;
        }
        
        .date-list {
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
            margin-top: 5px;
        }
        
        .exam-exists-warning {
            color: #dc3545;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }
        
        .no-compulsory-warning {
            color: #dc3545;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }
        
        .subject-count-badge {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            margin-left: 5px;
        }
        
        @media (max-width: 768px) {
            .card-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .card-header > div {
                width: 100%;
            }
            #dept_filter, #course_filter, #semester_filter, #section_filter {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                   <a href="adminDashboard.php">
            <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
            </a>
               <a href="departments.php">
            <img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5>
            </a>
                <a href="courses.php">
            <img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5>
            </a>
                  <a href="subjects.php">
            <img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5>
        </a>
           <a href="teachers.php">
            <img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5>
        </a>

         <a href="students.php">
            <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5>
        </a>

        <a href="allocations.php">
            <img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5>
        </a>
        <a href="exams.php" class="active">
            <img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5>
        </a>
        <a href="results.php">
            <img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5>
        </a>

        <a href="feedbacks.php">
            <img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5>
        </a>
        <a href="settings.php">
            <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5>
        </a>
        <a href="../logout.php">
            <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5>
        </a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2> <img src="../icons/exam.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Manage Exams</h2>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <!-- Department Filter Dropdown -->
                        <select id="dept_filter" onchange="filterByDepartment()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 200px;">
                            <option value="0">All Departments</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                                $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $dept['dept_name']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        
                        <!-- Course Filter Dropdown -->
                        <select id="course_filter" onchange="filterByCourse()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 250px;" <?php echo $dept_filter == 0 ? 'disabled' : ''; ?>>
                            <option value="0">All Courses</option>
                            <?php 
                            if($dept_filter > 0):
                                $filter_courses->data_seek(0);
                                while($course = $filter_courses->fetch_assoc()): 
                                    $selected = ($course_filter == $course['course_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $course['course_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $course['course_name']; ?>
                            </option>
                            <?php 
                                endwhile;
                            endif; 
                            ?>
                        </select>
                        
                        <!-- Semester Filter Dropdown -->
                        <select id="semester_filter" onchange="filterBySemester()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 150px;">
                            <option value="0">All Semesters</option>
                            <?php for($i = 1; $i <= 8; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo ($semester_filter == $i) ? 'selected' : ''; ?>>
                                    Semester <?php echo $i; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                        
                        <!-- Section Filter Dropdown -->
                        <select id="section_filter" onchange="filterBySection()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 150px;">
                            <option value="">All Sections</option>
                            <?php 
                            $sections->data_seek(0);
                            while($section = $sections->fetch_assoc()): 
                                $selected = ($section_filter == $section['section']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $section['section']; ?>" <?php echo $selected; ?>>
                                Section <?php echo $section['section']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        
                        <!-- Clear Filters Button -->
                        <?php if($dept_filter > 0 || $course_filter > 0 || $semester_filter > 0 || !empty($section_filter)): ?>
                        <button class="btn btn-secondary" onclick="clearFilters()">Clear Filters</button>
                        <?php endif; ?>
                        
                        <button class="btn" onclick="document.getElementById('addModal').style.display='block'">Schedule New Exam <img src="../icons/Add.png" style="height: 27px; vertical-align: middle; margin-right: 10px;"></button>
                    </div>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Exam Name</th>
                            <th>Type</th>
                            <th>Department(s)</th>
                            <th>Course(s)</th>
                            <th>Semester(s)</th>
                            <th>Section(s)</th>
                            <th>Subjects</th>
                            <th>Exam Dates</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($exams && $exams->num_rows > 0): ?>
                            <?php while($row = $exams->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['exam_id']; ?></td>
                                <td><strong><?php echo $row['exam_name']; ?></strong></td>
                                <td>
                                    <span class="badge badge-info"><?php echo $row['exam_type']; ?></span>
                                </td>
                                <td><?php echo $row['dept_names'] ?? 'N/A'; ?></td>
                                <td><?php echo $row['course_names'] ?? 'N/A'; ?></td>
                                <td>
                                    <?php 
                                    if ($row['semesters']) {
                                        $semester_array = explode(', ', $row['semesters']);
                                        if (count($semester_array) > 1) {
                                            echo 'Semesters: ' . implode(', ', $semester_array);
                                        } else {
                                            echo 'Sem ' . $row['semesters'];
                                        }
                                    } else {
                                        echo 'N/A';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                    if ($row['sections']) {
                                        $section_array = explode(', ', $row['sections']);
                                        foreach ($section_array as $sec) {
                                            echo '<span class="badge badge-purple" style="margin-right: 3px;">Sec ' . $sec . '</span>';
                                        }
                                    } else {
                                        echo 'N/A';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <span class="badge badge-primary"><?php echo $row['subject_count']; ?> Subjects</span>
                                </td>
                                <td>
                                    <?php if($row['first_exam_date'] && $row['last_exam_date']): ?>
                                        <div class="date-range">
                                            <span class="date-item"><?php echo date('d M', strtotime($row['first_exam_date'])); ?></span>
                                            <span>to</span>
                                            <span class="date-item"><?php echo date('d M', strtotime($row['last_exam_date'])); ?></span>
                                        </div>
                                        <?php 
                                        // Count unique dates
                                        $unique_dates = count(array_unique(explode('|', $row['all_dates'])));
                                        if($unique_dates > 1): 
                                        ?>
                                            <small style="color: #666;">(<?php echo $unique_dates; ?> different dates)</small>
                                            
                                            <!-- Show all dates on hover -->
                                            <div class="date-list" style="display: none;" id="dates-<?php echo $row['exam_id']; ?>">
                                                <?php 
                                                $dates = array_unique(explode('|', $row['all_dates']));
                                                sort($dates);
                                                foreach($dates as $date): 
                                                ?>
                                                    <span class="date-item"><?php echo date('d M', strtotime($date)); ?></span>
                                                <?php endforeach; ?>
                                            </div>
                                            <button class="btn-link" onclick="toggleDates(<?php echo $row['exam_id']; ?>)" style="font-size: 11px; padding: 2px 5px; margin-top: 3px;">Show all dates</button>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="action-btn view-btn" onclick="viewExamDetails(<?php echo $row['exam_id']; ?>)" title="View Details"><img src="../icons/detail.png" style="height: 22px; vertical-align: middle;"></button>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this exam? This will also delete all subject schedules and results.')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="exam_id" value="<?php echo $row['exam_id']; ?>">
                                        <button type="submit" class="action-btn delete-btn" title="Delete"><img src="../icons/Delete.png" style="height: 22px; vertical-align: middle;"></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="10" style="text-align: center; padding: 20px;">
                                    No exams found
                                    <?php if($dept_filter > 0 || $course_filter > 0 || $semester_filter > 0 || !empty($section_filter)): ?>
                                        with the selected filters. <a href="exams.php">View all exams</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content" style="max-width: 1000px; max-height: 85vh; overflow-y: auto;">
            <span class="close" onclick="document.getElementById('addModal').style.display='none'">&times;</span>
            <h2>Schedule New Exam</h2>
            <form method="POST" id="examForm" onsubmit="return validateExamForm()">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="dept_id" id="selected_dept_id">
                <input type="hidden" name="course_id" id="selected_course_id">
                <input type="hidden" name="semester" id="selected_semester">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    
                    <div class="form-group">
                        <label>Department <span style="color: red;">*</span></label>
                        <select id="exam_dept_filter" onchange="loadCoursesForExam(); checkExamExists()" required>
                            <option value="">Select Department First</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>"><?php echo $dept['dept_name']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Course <span style="color: red;">*</span></label>
                        <select id="exam_course_id" onchange="loadSemestersAndSubjects(); checkExamExists(); checkCompulsorySubjects()" required disabled>
                            <option value="">Select Department First</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Semester <span style="color: red;">*</span></label>
                        <select id="exam_semester" onchange="loadSubjects(); checkExamExists(); checkCompulsorySubjects()" required disabled>
                            <option value="">Select Course First</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Section <span style="color: red;">*</span></label>
                        <select name="section" id="exam_section" onchange="loadSubjects(); checkExamExists()" required disabled>
                            <option value="">Select Section</option>
                            <?php 
                            $sections->data_seek(0);
                            while($section = $sections->fetch_assoc()): 
                            ?>
                            <option value="<?php echo $section['section']; ?>">Section <?php echo $section['section']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Exam Name <span style="color: red;">*</span></label>
                        <input type="text" name="exam_name" id="exam_name" placeholder="e.g., Midterm Examination 2024" required onchange="checkExamExists()">
                    </div>
                    
                    <div class="form-group">
                        <label>Exam Type <span style="color: red;">*</span></label>
                        <select name="exam_type" id="exam_type" required onchange="checkExamExists()">
                            <option value="">Select Type</option>
                            <option value="Midterm">Midterm</option>
                            <option value="PreBoard">PreBoard</option>
                            <option value="Board">Board</option>
                            <option value="Internal">Internal</option>
                        </select>
                    </div>
                </div>
                
                <div id="exam-exists-warning" class="exam-exists-warning" style="color: #dc3545; margin-bottom: 15px; display: none;">
                    An exam with this name and type already exists for this department, course, semester, and section!
                </div>
                
                <div id="no-compulsory-warning" class="no-compulsory-warning" style="color: #dc3545; margin-bottom: 15px; display: none;">
                    No compulsory subjects found for this course and semester. Please add compulsory subjects first.
                </div>
                
                <div id="subjects-container" style="margin-top: 20px; display: none;">
                    <h3 style="margin-bottom: 15px;">Select Subjects and Set Exam Details</h3>
                    <div id="subjects-list"></div>
                </div>
                
                <div style="margin-top: 20px; text-align: right;">
                    <button type="submit" class="btn" id="submitBtn" disabled>Schedule Exam <img src="../icons/Add.png" style="height: 20px; vertical-align: middle; margin-left: 5px;"></button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- View Exam Details Modal -->
    <div id="viewModal" class="modal">
        <div class="modal-content" style="max-width: 900px; max-height: 80vh; overflow-y: auto;">
            <span class="close" onclick="document.getElementById('viewModal').style.display='none'">&times;</span>
            <h2>Exam Details</h2>
            <div id="exam-details-content" style="min-height: 200px;">
                <div class="loading">Loading exam details...</div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        // Store courses data
        var allCourses = [];
        var allSubjects = [];
        var today = '<?php echo $today; ?>';
        var examExists = false;
        var hasCompulsorySubjects = true;
        
        <?php 
        $all_courses->data_seek(0);
        while($course = $all_courses->fetch_assoc()): 
        ?>
        allCourses.push({
            id: <?php echo $course['course_id']; ?>,
            name: '<?php echo addslashes($course['course_name']); ?>',
            dept_id: <?php echo $course['dept_id'] ?? 'null'; ?>,
            total_semesters: <?php echo $course['total_semesters']; ?>
        });
        <?php endwhile; ?>
        
        <?php 
        $all_subjects->data_seek(0);
        while($subject = $all_subjects->fetch_assoc()): 
        ?>
        allSubjects.push({
            id: <?php echo $subject['subject_id']; ?>,
            name: '<?php echo addslashes($subject['subject_name']); ?>',
            code: '<?php echo $subject['subject_code']; ?>',
            course_id: <?php echo $subject['course_id']; ?>,
            semester: <?php echo $subject['semester_number']; ?>,
            type: '<?php echo $subject['subject_type']; ?>'
        });
        <?php endwhile; ?>
        
        function toggleDates(examId) {
            var datesDiv = document.getElementById('dates-' + examId);
            var button = event.target;
            
            if (datesDiv.style.display === 'none' || datesDiv.style.display === '') {
                datesDiv.style.display = 'flex';
                datesDiv.style.flexWrap = 'wrap';
                datesDiv.style.gap = '5px';
                datesDiv.style.marginTop = '5px';
                button.textContent = 'Hide dates';
            } else {
                datesDiv.style.display = 'none';
                button.textContent = 'Show all dates';
            }
        }
        
        function filterByDepartment() {
            var deptId = document.getElementById('dept_filter').value;
            var url = 'exams.php';
            var params = [];
            
            if (deptId > 0) {
                params.push('dept_id=' + deptId);
            }
            
            <?php if($course_filter > 0): ?>
            params.push('course_id=<?php echo $course_filter; ?>');
            <?php endif; ?>
            
            <?php if($semester_filter > 0): ?>
            params.push('semester=<?php echo $semester_filter; ?>');
            <?php endif; ?>
            
            <?php if(!empty($section_filter)): ?>
            params.push('section=<?php echo $section_filter; ?>');
            <?php endif; ?>
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }
        
        function filterByCourse() {
            var deptId = document.getElementById('dept_filter').value;
            var courseId = document.getElementById('course_filter').value;
            var url = 'exams.php';
            var params = [];
            
            if (deptId > 0) {
                params.push('dept_id=' + deptId);
            }
            if (courseId > 0) {
                params.push('course_id=' + courseId);
            }
            
            <?php if($semester_filter > 0): ?>
            params.push('semester=<?php echo $semester_filter; ?>');
            <?php endif; ?>
            
            <?php if(!empty($section_filter)): ?>
            params.push('section=<?php echo $section_filter; ?>');
            <?php endif; ?>
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }
        
        function filterBySemester() {
            var semester = document.getElementById('semester_filter').value;
            var url = 'exams.php';
            var params = [];
            
            <?php if($dept_filter > 0): ?>
            params.push('dept_id=<?php echo $dept_filter; ?>');
            <?php endif; ?>
            
            <?php if($course_filter > 0): ?>
            params.push('course_id=<?php echo $course_filter; ?>');
            <?php endif; ?>
            
            if (semester > 0) {
                params.push('semester=' + semester);
            }
            
            <?php if(!empty($section_filter)): ?>
            params.push('section=<?php echo $section_filter; ?>');
            <?php endif; ?>
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }
        
        function filterBySection() {
            var section = document.getElementById('section_filter').value;
            var url = 'exams.php';
            var params = [];
            
            <?php if($dept_filter > 0): ?>
            params.push('dept_id=<?php echo $dept_filter; ?>');
            <?php endif; ?>
            
            <?php if($course_filter > 0): ?>
            params.push('course_id=<?php echo $course_filter; ?>');
            <?php endif; ?>
            
            <?php if($semester_filter > 0): ?>
            params.push('semester=<?php echo $semester_filter; ?>');
            <?php endif; ?>
            
            if (section) {
                params.push('section=' + section);
            }
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }
        
        function clearFilters() {
            window.location.href = 'exams.php';
        }
        
        function loadCoursesForExam() {
            var deptId = document.getElementById('exam_dept_filter').value;
            var courseSelect = document.getElementById('exam_course_id');
            var semesterSelect = document.getElementById('exam_semester');
            var sectionSelect = document.getElementById('exam_section');
            var subjectsContainer = document.getElementById('subjects-container');
            
            // Set hidden department field
            document.getElementById('selected_dept_id').value = deptId;
            
            // Clear and disable dependent fields
            courseSelect.innerHTML = '<option value="">Select Course</option>';
            semesterSelect.innerHTML = '<option value="">Select Course First</option>';
            semesterSelect.disabled = true;
            sectionSelect.disabled = true;
            subjectsContainer.style.display = 'none';
            document.getElementById('submitBtn').disabled = true;
            
            if (deptId) {
                // Filter courses by department
                var filteredCourses = allCourses.filter(function(course) {
                    return course.dept_id == deptId;
                });
                
                if (filteredCourses.length > 0) {
                    filteredCourses.forEach(function(course) {
                        var option = document.createElement('option');
                        option.value = course.id;
                        option.text = course.name;
                        option.setAttribute('data-semesters', course.total_semesters);
                        courseSelect.appendChild(option);
                    });
                    courseSelect.disabled = false;
                } else {
                    courseSelect.innerHTML = '<option value="">No courses in this department</option>';
                    courseSelect.disabled = true;
                }
            }
        }
        
        function loadSemestersAndSubjects() {
            var courseSelect = document.getElementById('exam_course_id');
            var semesterSelect = document.getElementById('exam_semester');
            var sectionSelect = document.getElementById('exam_section');
            var subjectsContainer = document.getElementById('subjects-container');
            var courseId = courseSelect.value;
            var selectedOption = courseSelect.options[courseSelect.selectedIndex];
            
            // Set hidden course field
            document.getElementById('selected_course_id').value = courseId;
            
            // Clear semester options
            semesterSelect.innerHTML = '<option value="">Select Semester</option>';
            subjectsContainer.style.display = 'none';
            document.getElementById('submitBtn').disabled = true;
            
            if (courseId && selectedOption) {
                var totalSemesters = selectedOption.getAttribute('data-semesters');
                
                for (var i = 1; i <= totalSemesters; i++) {
                    var option = document.createElement('option');
                    option.value = i;
                    option.text = 'Semester ' + i;
                    semesterSelect.appendChild(option);
                }
                semesterSelect.disabled = false;
                sectionSelect.disabled = false;
            } else {
                semesterSelect.innerHTML = '<option value="">Select Course First</option>';
                semesterSelect.disabled = true;
                sectionSelect.disabled = true;
            }
        }
        
        function checkCompulsorySubjects() {
            var courseId = document.getElementById('exam_course_id').value;
            var semester = document.getElementById('exam_semester').value;
            var warningDiv = document.getElementById('no-compulsory-warning');
            
            if (courseId && semester) {
                fetch('exams.php?ajax=check_compulsory_subjects&course_id=' + courseId + '&semester=' + semester)
                    .then(response => response.json())
                    .then(data => {
                        hasCompulsorySubjects = data.hasCompulsory;
                        if (!hasCompulsorySubjects) {
                            warningDiv.style.display = 'block';
                            document.getElementById('subjects-container').style.display = 'none';
                        } else {
                            warningDiv.style.display = 'none';
                        }
                        updateSubmitButton();
                    });
            } else {
                warningDiv.style.display = 'none';
                hasCompulsorySubjects = true;
            }
        }
        
        function loadSubjects() {
            var courseId = document.getElementById('exam_course_id').value;
            var semester = document.getElementById('exam_semester').value;
            var section = document.getElementById('exam_section').value;
            var subjectsContainer = document.getElementById('subjects-container');
            var subjectsList = document.getElementById('subjects-list');
            
            // Set hidden semester field
            document.getElementById('selected_semester').value = semester;
            
            if (courseId && semester && section) {
                // Check if compulsory subjects exist first
                fetch('exams.php?ajax=check_compulsory_subjects&course_id=' + courseId + '&semester=' + semester)
                    .then(response => response.json())
                    .then(data => {
                        hasCompulsorySubjects = data.hasCompulsory;
                        if (!hasCompulsorySubjects) {
                            document.getElementById('no-compulsory-warning').style.display = 'block';
                            subjectsContainer.style.display = 'none';
                            document.getElementById('submitBtn').disabled = true;
                            return;
                        } else {
                            document.getElementById('no-compulsory-warning').style.display = 'none';
                        }
                        
                        // Filter subjects by course and semester
                        var filteredSubjects = allSubjects.filter(function(subject) {
                            return subject.course_id == courseId && subject.semester == semester;
                        });
                        
                        if (filteredSubjects.length > 0) {
                            var html = '';
                            
                            // Separate subjects by type
                            var compulsorySubjects = filteredSubjects.filter(s => s.type == 'Compulsory');
                            var optionalSubjects = filteredSubjects.filter(s => s.type == 'Optional' || s.type == 'Elective');
                            
                            // Compulsory subjects (automatically selected)
                            if (compulsorySubjects.length > 0) {
                                html += '<h4 style="margin-bottom: 10px;">Compulsory Subjects (Auto-selected)</h4>';
                                compulsorySubjects.forEach(function(subject) {
                                    html += generateSubjectCard(subject, true);
                                });
                            }
                            
                            // Optional/Elective subjects (checkbox selection)
                            if (optionalSubjects.length > 0) {
                                html += '<h4 style="margin: 20px 0 10px;">Optional/Elective Subjects (Optional to select)</h4>';
                                optionalSubjects.forEach(function(subject) {
                                    html += generateSubjectCard(subject, false);
                                });
                            }
                            
                            subjectsList.innerHTML = html;
                            subjectsContainer.style.display = 'block';
                            
                            // Set minimum date for all date inputs to today
                            document.querySelectorAll('.exam-date-input').forEach(function(input) {
                                input.min = today;
                                input.value = today; // Set default to today
                                input.addEventListener('change', function() {
                                    validateExamDate(this);
                                    updateSubmitButton();
                                });
                                input.addEventListener('blur', function() {
                                    validateExamDate(this);
                                    updateSubmitButton();
                                });
                            });
                            
                            // Add change event listeners to optional checkboxes
                            document.querySelectorAll('input[name="optional_subjects[]"]').forEach(function(checkbox) {
                                checkbox.addEventListener('change', function() {
                                    updateSubmitButton();
                                });
                            });
                            
                            // Enable submit button if no exam exists and dates are valid
                            updateSubmitButton();
                            
                        } else {
                            subjectsList.innerHTML = '<p style="text-align: center; padding: 20px; color: #666;">No subjects found for this semester.</p>';
                            subjectsContainer.style.display = 'block';
                            document.getElementById('submitBtn').disabled = true;
                        }
                    });
            }
        }
        
        function generateSubjectCard(subject, isCompulsory) {
            var checked = isCompulsory ? 'checked disabled' : '';
            var badgeClass = isCompulsory ? 'compulsory-badge' : (subject.type == 'Optional' ? 'optional-badge' : 'elective-badge');
            var subjectId = subject.id;
            var inputType = isCompulsory ? 'hidden' : 'checkbox';
            var namePrefix = isCompulsory ? 'compulsory_subjects[]' : 'optional_subjects[]';
            
            return `
                <div class="subject-card" id="subject_card_${subjectId}">
                    <div class="subject-header">
                        <input type="${inputType}" 
                               name="${namePrefix}" 
                               value="${subjectId}" ${checked}>
                        <strong>${subject.name} (${subject.code})</strong>
                        <span class="${badgeClass}">${subject.type}</span>
                    </div>
                    <div class="subject-details">
                        <div class="marks-input">
                            <label>Theory Full Marks <span style="color: red;">*</span></label>
                            <input type="number" name="theory_full_${subjectId}" id="theory_full_${subjectId}" 
                                   min="0" max="100" value="60" required 
                                   onchange="validateTotalMarks(${subjectId})">
                        </div>
                        <div class="marks-input">
                            <label>Theory Pass Marks <span style="color: red;">*</span></label>
                            <input type="number" name="theory_pass_${subjectId}" id="theory_pass_${subjectId}" 
                                   min="0" max="100" value="24" required>
                        </div>
                        <div class="marks-input">
                            <label>Practical Full Marks</label>
                            <input type="number" name="practical_full_${subjectId}" id="practical_full_${subjectId}" 
                                   min="0" max="100" value="40" placeholder="Optional"
                                   onchange="validateTotalMarks(${subjectId})">
                        </div>
                        <div class="marks-input">
                            <label>Practical Pass Marks</label>
                            <input type="number" name="practical_pass_${subjectId}" id="practical_pass_${subjectId}" 
                                   min="0" max="100" value="18" placeholder="Optional">
                        </div>
                        <div class="marks-input">
                            <label>Exam Date <span style="color: red;">*</span></label>
                            <input type="date" name="exam_date_${subjectId}" class="exam-date-input" 
                                   min="${today}" value="${today}" required>
                            <div class="validation-message" id="date_error_${subjectId}"></div>
                        </div>
                    </div>
                    <div class="validation-message" id="total_marks_error_${subjectId}" style="margin-top: 10px;"></div>
                </div>
            `;
        }
        
        function validateTotalMarks(subjectId) {
            var theoryFull = parseInt(document.getElementById('theory_full_' + subjectId).value) || 0;
            var practicalFull = parseInt(document.getElementById('practical_full_' + subjectId).value) || 0;
            var errorDiv = document.getElementById('total_marks_error_' + subjectId);
            var theoryInput = document.getElementById('theory_full_' + subjectId);
            var practicalInput = document.getElementById('practical_full_' + subjectId);
            
            var totalMarks = theoryFull + practicalFull;
            
            // Remove any existing total marks error classes
            theoryInput.classList.remove('error', 'success');
            if (practicalInput) practicalInput.classList.remove('error', 'success');
            
            if (practicalFull > 0) {
                // If practical marks are entered, total must be exactly 100
                if (totalMarks !== 100) {
                    errorDiv.innerHTML = 'Theory + Practical marks must equal 100 (current: ' + totalMarks + ')';
                    errorDiv.className = 'validation-message error';
                    theoryInput.classList.add('error');
                    practicalInput.classList.add('error');
                    return false;
                } else {
                    errorDiv.innerHTML = '✓ Total marks: ' + totalMarks + '/100';
                    errorDiv.className = 'validation-message success';
                    theoryInput.classList.add('success');
                    practicalInput.classList.add('success');
                    return true;
                }
            } else {
                // If no practical marks, theory must be 100
                if (theoryFull !== 100) {
                    errorDiv.innerHTML = 'Theory marks must be 100 when no practical (current: ' + theoryFull + ')';
                    errorDiv.className = 'validation-message error';
                    theoryInput.classList.add('error');
                    return false;
                } else {
                    errorDiv.innerHTML = '✓ Theory only: ' + theoryFull + '/100';
                    errorDiv.className = 'validation-message success';
                    theoryInput.classList.add('success');
                    return true;
                }
            }
        }
        
        function validateExamDate(input) {
            var dateValue = input.value;
            var subjectId = input.name.split('_')[2];
            var errorDiv = document.getElementById('date_error_' + subjectId);
            
            if (!errorDiv) {
                // Create error div if it doesn't exist
                errorDiv = document.createElement('div');
                errorDiv.className = 'validation-message';
                errorDiv.id = 'date_error_' + subjectId;
                input.parentNode.appendChild(errorDiv);
            }
            
            if (dateValue < today) {
                errorDiv.innerHTML = 'Exam date cannot be in the past';
                errorDiv.className = 'validation-message error';
                input.classList.add('error');
                input.classList.remove('success');
                return false;
            } else {
                errorDiv.innerHTML = '✓ Valid date';
                errorDiv.className = 'validation-message success';
                input.classList.remove('error');
                input.classList.add('success');
                return true;
            }
        }
        
        function checkExamExists() {
            var examName = document.getElementById('exam_name').value;
            var examType = document.getElementById('exam_type').value;
            var deptId = document.getElementById('exam_dept_filter').value;
            var courseId = document.getElementById('exam_course_id').value;
            var semester = document.getElementById('exam_semester').value;
            var section = document.getElementById('exam_section').value;
            var warningDiv = document.getElementById('exam-exists-warning');
            
            if (examName && examType && deptId && courseId && semester && section) {
                fetch('exams.php?ajax=check_exam_exists&exam_name=' + encodeURIComponent(examName) + 
                      '&exam_type=' + encodeURIComponent(examType) + 
                      '&dept_id=' + deptId + 
                      '&course_id=' + courseId + 
                      '&semester=' + semester + 
                      '&section=' + encodeURIComponent(section))
                    .then(response => response.json())
                    .then(data => {
                        examExists = data.exists;
                        if (examExists) {
                            warningDiv.style.display = 'block';
                        } else {
                            warningDiv.style.display = 'none';
                        }
                        updateSubmitButton();
                    });
            } else {
                warningDiv.style.display = 'none';
                examExists = false;
                updateSubmitButton();
            }
        }
        
        function updateSubmitButton() {
            var subjectsContainer = document.getElementById('subjects-container');
            var submitBtn = document.getElementById('submitBtn');
            var dateInputs = document.querySelectorAll('.exam-date-input');
            var allDatesValid = true;
            var allMarksValid = true;
            
            // Check if there are any subjects at all
            var subjectCards = document.querySelectorAll('[id^="subject_card_"]');
            if (subjectCards.length === 0) {
                submitBtn.disabled = true;
                return;
            }
            
            // Check all dates
            dateInputs.forEach(function(input) {
                if (!validateExamDate(input)) {
                    allDatesValid = false;
                }
            });
            
            // Check all marks totals
            subjectCards.forEach(function(card) {
                var subjectId = card.id.replace('subject_card_', '');
                if (!validateTotalMarks(subjectId)) {
                    allMarksValid = false;
                }
            });
            
            if (subjectsContainer.style.display === 'block' && !examExists && hasCompulsorySubjects && allDatesValid && allMarksValid) {
                submitBtn.disabled = false;
            } else {
                submitBtn.disabled = true;
            }
        }
        
        function validateExamForm() {
            var dateInputs = document.querySelectorAll('.exam-date-input');
            var subjectCards = document.querySelectorAll('[id^="subject_card_"]');
            var isValid = true;
            
            // Check if any subjects are selected (compulsory are auto-selected, optional need at least one checked)
            var optionalChecked = document.querySelectorAll('input[name="optional_subjects[]"]:checked').length;
            var compulsoryCount = document.querySelectorAll('input[name="compulsory_subjects[]"]').length;
            
            if (compulsoryCount === 0 && optionalChecked === 0) {
                alert('Please select at least one subject for the exam!');
                return false;
            }
            
            // Check dates
            dateInputs.forEach(function(input) {
                if (!validateExamDate(input)) {
                    isValid = false;
                }
            });
            
            // Check marks totals
            subjectCards.forEach(function(card) {
                var subjectId = card.id.replace('subject_card_', '');
                if (!validateTotalMarks(subjectId)) {
                    isValid = false;
                }
            });
            
            if (examExists) {
                alert('This exam already exists for the selected department, course, semester, and section!');
                return false;
            }
            
            if (!hasCompulsorySubjects) {
                alert('No compulsory subjects found for this course and semester. Please add compulsory subjects first.');
                return false;
            }
            
            if (!isValid) {
                alert('Please fix all errors:\n- All exam dates must be today or in the future\n- Theory + Practical marks must equal 100 for each subject');
                return false;
            }
            
            return true;
        }
        
        function viewExamDetails(examId) {
            // Show loading
            document.getElementById('exam-details-content').innerHTML = '<div class="loading">Loading exam details...</div>';
            document.getElementById('viewModal').style.display = 'block';
            
            // Fetch exam details via AJAX
            fetch('exams.php?ajax=get_exam_details&exam_id=' + examId)
                .then(response => response.json())
                .then(data => {
                    if (data.exam) {
                        displayExamDetails(data);
                    } else {
                        document.getElementById('exam-details-content').innerHTML = '<div class="loading">Exam details not found.</div>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('exam-details-content').innerHTML = '<div class="loading">Error loading exam details.</div>';
                });
        }
        
        function displayExamDetails(data) {
            var exam = data.exam;
            var subjects = data.subjects;
            var departments = data.departments || [];
            var courses = data.courses || [];
            var semesters = data.semesters || [];
            var sections = data.sections || [];
            var totalSubjects = data.total_subjects;
            
            // Format departments for display
            var deptDisplay = departments.map(d => d.dept_name).join(', ') || 'N/A';
            var courseDisplay = courses.map(c => c.course_name).join(', ') || 'N/A';
            var semesterDisplay = semesters.length > 0 ? 'Sem ' + semesters.join(', ') : 'N/A';
            var sectionDisplay = sections.length > 0 ? 'Sec ' + sections.join(', ') : 'N/A';
            
            var html = `
                <div class="exam-info-card">
                    <h3 style="margin-top: 0; color: #333;">${exam.exam_name}</h3>
                    <div class="exam-info-grid">
                        <div class="info-item">
                            <span class="info-label">Exam Type</span>
                            <span class="info-value"><span class="badge badge-info">${exam.exam_type}</span></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Department(s)</span>
                            <span class="info-value">${deptDisplay}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Course(s)</span>
                            <span class="info-value">${courseDisplay}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Semester(s)</span>
                            <span class="info-value">${semesterDisplay}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Section(s)</span>
                            <span class="info-value">${sectionDisplay}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Total Subjects</span>
                            <span class="info-value"><span class="badge badge-primary">${totalSubjects}</span></span>
                        </div>
                    </div>
                </div>
            `;
            
            if (subjects.length > 0) {
                html += `
                    <h3 style="margin: 20px 0 15px;">Subject-wise Exam Schedule</h3>
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Subject Code</th>
                                <th>Subject Name</th>
                                <th>Type</th>
                                <th>Semester</th>
                                <th>Course</th>
                                <th>Exam Date</th>
                                <th>Theory Marks</th>
                                <th>Practical Marks</th>
                            </tr>
                        </thead>
                        <tbody>
                `;
                
                subjects.forEach(function(subject) {
                    var typeClass = subject.subject_type == 'Compulsory' ? 'badge-primary' : (subject.subject_type == 'Optional' ? 'badge-success' : 'badge-warning');
                    
                    html += `
                        <tr>
                            <td><strong>${subject.subject_code}</strong></td>
                            <td>${subject.subject_name}</td>
                            <td><span class="badge ${typeClass}">${subject.subject_type}</span></td>
                            <td>Sem ${subject.semester_number}</td>
                            <td>${subject.course_name || 'N/A'}</td>
                            <td><span class="date-badge">${subject.exam_date}</span></td>
                            <td>
                                <span class="marks-badge">${subject.theory_full_marks} (Pass: ${subject.theory_pass_marks})</span>
                            </td>
                            <td>
                                ${subject.practical_full_marks ? 
                                    `<span class="practical-badge">${subject.practical_full_marks} (Pass: ${subject.practical_pass_marks})</span>` : 
                                    '<span style="color: #999;">N/A</span>'}
                            </td>
                        </tr>
                    `;
                });
                
                html += `
                        </tbody>
                    </table>
                `;
            } else {
                html += '<p style="text-align: center; padding: 30px; color: #666;">No subjects scheduled for this exam.</p>';
            }
            
            document.getElementById('exam-details-content').innerHTML = html;
        }
        
        // Close modals when clicking outside
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>