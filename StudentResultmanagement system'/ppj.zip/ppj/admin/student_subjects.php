<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
$semester = isset($_GET['semester']) ? intval($_GET['semester']) : 1;

// Get student details
$student_query = "SELECT s.*, c.course_name, c.total_semesters 
                  FROM Student s 
                  LEFT JOIN Course c ON s.course_id = c.course_id 
                  WHERE s.student_id = $student_id";
$student_result = $conn->query($student_query);
$student = $student_result->fetch_assoc();

if (!$student) {
    header("Location: students.php");
    exit();
}

// Handle subject selection
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_subjects'])) {
    $semester = intval($_POST['semester']);
    
    // Begin transaction
    $conn->begin_transaction();
    
    try {
        // Delete existing subjects for this student and semester
        $delete_sql = "DELETE FROM student_subjects WHERE student_id = $student_id AND semester = $semester";
        $conn->query($delete_sql);
        
        // Insert compulsory subjects (automatically selected)
        if (isset($_POST['compulsory_subjects']) && is_array($_POST['compulsory_subjects'])) {
            foreach ($_POST['compulsory_subjects'] as $subject_id) {
                $subject_id = intval($subject_id);
                $insert_sql = "INSERT INTO student_subjects (student_id, subject_id, subject_type, semester) 
                               VALUES ($student_id, $subject_id, 'compulsory', $semester)";
                $conn->query($insert_sql);
            }
        }
        
        // Insert optional subjects
        if (isset($_POST['optional_subjects']) && is_array($_POST['optional_subjects'])) {
            foreach ($_POST['optional_subjects'] as $subject_id) {
                $subject_id = intval($subject_id);
                $insert_sql = "INSERT INTO student_subjects (student_id, subject_id, subject_type, semester) 
                               VALUES ($student_id, $subject_id, 'optional', $semester)";
                $conn->query($insert_sql);
            }
        }
        
        // Insert elective subjects
        if (isset($_POST['elective_subjects']) && is_array($_POST['elective_subjects'])) {
            foreach ($_POST['elective_subjects'] as $subject_id) {
                $subject_id = intval($subject_id);
                $insert_sql = "INSERT INTO student_subjects (student_id, subject_id, subject_type, semester) 
                               VALUES ($student_id, $subject_id, 'elective', $semester)";
                $conn->query($insert_sql);
            }
        }
        
        $conn->commit();
        $_SESSION['message'] = "Subjects saved successfully for Semester $semester!";
        $_SESSION['msg_type'] = "success";
        
        // Redirect back to students page or stay here
        header("Location: student_subjects.php?student_id=$student_id&semester=$semester");
        exit();
        
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['message'] = "Error: " . $e->getMessage();
        $_SESSION['msg_type'] = "error";
    }
}

// Get all subjects for this course and semester
$subjects_query = "SELECT s.*, sub.type as subject_type 
                   FROM Subject s
                   LEFT JOIN (
                       SELECT subject_id, type FROM student_subjects 
                       WHERE student_id = $student_id AND semester = $semester
                   ) as sub ON s.subject_id = sub.subject_id
                   WHERE s.course_id = {$student['course_id']} 
                   AND s.semester = $semester
                   ORDER BY s.subject_type, s.subject_name";

$subjects = $conn->query($subjects_query);

// Group subjects by type
$compulsory_subjects = [];
$optional_subjects = [];
$elective_subjects = [];

while ($subject = $subjects->fetch_assoc()) {
    // Check if this subject is already selected
    $subject['is_selected'] = !is_null($subject['subject_type']);
    
    switch ($subject['subject_type_main']) {
        case 'compulsory':
            $compulsory_subjects[] = $subject;
            break;
        case 'optional':
            $optional_subjects[] = $subject;
            break;
        case 'elective':
            $elective_subjects[] = $subject;
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Student Subjects - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .subject-section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        
        .subject-section h3 {
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
        }
        
        .subject-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .subject-item {
            background: white;
            padding: 12px;
            border-radius: 6px;
            border: 1px solid #e0e0e0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .subject-item label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }
        
        .subject-item input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .subject-code {
            font-size: 12px;
            color: #666;
            margin-top: 4px;
            margin-left: 28px;
        }
        
        .compulsory-badge {
            background-color: #4CAF50;
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            margin-left: 8px;
        }
        
        .optional-badge {
            background-color: #FF9800;
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            margin-left: 8px;
        }
        
        .elective-badge {
            background-color: #2196F3;
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            margin-left: 8px;
        }
        
        .semester-nav {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .semester-btn {
            padding: 8px 16px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            color: #333;
        }
        
        .semester-btn.active {
            background-color: #4CAF50;
            color: white;
            border-color: #4CAF50;
        }
        
        .student-info {
            background: #e8f5e8;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .save-btn {
            background-color: #4CAF50;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
        }
        
        .save-btn:hover {
            background-color: #45a049;
        }
        
        .info-text {
            color: #666;
            font-style: italic;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <!-- Copy your navbar from students.php here -->
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2>Manage Subjects for <?php echo $student['first_name'] . ' ' . $student['last_name']; ?></h2>
                    <a href="students.php" class="btn">Back to Students</a>
                </div>
                
                <div class="student-info">
                    <p><strong>Roll Number:</strong> <?php echo $student['roll_number']; ?></p>
                    <p><strong>Course:</strong> <?php echo $student['course_name']; ?></p>
                    <p><strong>Current Semester:</strong> <?php echo $student['current_semester']; ?></p>
                    <p><strong>Section:</strong> <?php echo $student['section']; ?></p>
                </div>
                
                <!-- Semester Navigation -->
                <div class="semester-nav">
                    <?php for($i = 1; $i <= $student['total_semesters']; $i++): ?>
                        <a href="?student_id=<?php echo $student_id; ?>&semester=<?php echo $i; ?>" 
                           class="semester-btn <?php echo ($semester == $i) ? 'active' : ''; ?>">
                            Semester <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
                
                <form method="POST" id="subjectForm">
                    <input type="hidden" name="semester" value="<?php echo $semester; ?>">
                    
                    <!-- Compulsory Subjects (Automatically selected) -->
                    <div class="subject-section">
                        <h3>Compulsory Subjects <span class="compulsory-badge">Auto-selected</span></h3>
                        <p class="info-text">These subjects are automatically assigned to all students.</p>
                        <div class="subject-grid">
                            <?php 
                            $comp_query = "SELECT * FROM Subject WHERE course_id = {$student['course_id']} 
                                           AND semester = $semester AND subject_type = 'compulsory'";
                            $comp_result = $conn->query($comp_query);
                            while($subject = $comp_result->fetch_assoc()): 
                            ?>
                            <div class="subject-item">
                                <label>
                                    <input type="checkbox" 
                                           name="compulsory_subjects[]" 
                                           value="<?php echo $subject['subject_id']; ?>" 
                                           checked 
                                           disabled>
                                    <strong><?php echo $subject['subject_name']; ?></strong>
                                </label>
                                <div class="subject-code">Code: <?php echo $subject['subject_code']; ?></div>
                                <input type="hidden" name="compulsory_subjects[]" value="<?php echo $subject['subject_id']; ?>">
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    
                    <!-- Optional Subjects -->
                    <div class="subject-section">
                        <h3>Optional Subjects <span class="optional-badge">Select as needed</span></h3>
                        <p class="info-text">Choose from the optional subjects below.</p>
                        <div class="subject-grid">
                            <?php 
                            $opt_query = "SELECT s.*, ss.subject_id as selected 
                                         FROM Subject s
                                         LEFT JOIN student_subjects ss ON s.subject_id = ss.subject_id 
                                             AND ss.student_id = $student_id AND ss.semester = $semester
                                         WHERE s.course_id = {$student['course_id']} 
                                         AND s.semester = $semester AND s.subject_type = 'optional'";
                            $opt_result = $conn->query($opt_query);
                            while($subject = $opt_result->fetch_assoc()): 
                            ?>
                            <div class="subject-item">
                                <label>
                                    <input type="checkbox" 
                                           name="optional_subjects[]" 
                                           value="<?php echo $subject['subject_id']; ?>"
                                           <?php echo $subject['selected'] ? 'checked' : ''; ?>>
                                    <strong><?php echo $subject['subject_name']; ?></strong>
                                </label>
                                <div class="subject-code">Code: <?php echo $subject['subject_code']; ?></div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    
                    <!-- Elective Subjects -->
                    <div class="subject-section">
                        <h3>Elective Subjects <span class="elective-badge">Choose one</span></h3>
                        <p class="info-text">Select ONE elective subject from the options below.</p>
                        <div class="subject-grid">
                            <?php 
                            $elec_query = "SELECT s.*, ss.subject_id as selected 
                                          FROM Subject s
                                          LEFT JOIN student_subjects ss ON s.subject_id = ss.subject_id 
                                              AND ss.student_id = $student_id AND ss.semester = $semester
                                          WHERE s.course_id = {$student['course_id']} 
                                          AND s.semester = $semester AND s.subject_type = 'elective'";
                            $elec_result = $conn->query($elec_query);
                            while($subject = $elec_result->fetch_assoc()): 
                            ?>
                            <div class="subject-item">
                                <label>
                                    <input type="radio" 
                                           name="elective_subjects" 
                                           value="<?php echo $subject['subject_id']; ?>"
                                           class="elective-radio"
                                           <?php echo $subject['selected'] ? 'checked' : ''; ?>>
                                    <strong><?php echo $subject['subject_name']; ?></strong>
                                </label>
                                <div class="subject-code">Code: <?php echo $subject['subject_code']; ?></div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    
                    <button type="submit" name="save_subjects" class="save-btn">Save Subjects for Semester <?php echo $semester; ?></button>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Ensure only one elective is selected
            $('.elective-radio').on('change', function() {
                $('.elective-radio').not(this).prop('checked', false);
            });
            
            // Form validation
            $('#subjectForm').on('submit', function(e) {
                // Check if an elective is selected
                if ($('.elective-radio:checked').length === 0 && $('.elective-radio').length > 0) {
                    e.preventDefault();
                    alert('Please select one elective subject.');
                    return false;
                }
                
                return true;
            });
        });
    </script>
</body>
</html>