<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Handle Add/Edit/Delete operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add') {
            $dept_name = $database->escapeString($_POST['dept_name']);
            $dept_code = $database->escapeString($_POST['dept_code']);
            
            // Check if department name already exists
            $check_name = $conn->query("SELECT dept_id FROM Department WHERE dept_name = '$dept_name'");
            if ($check_name->num_rows > 0) {
                $_SESSION['message'] = "Department name already exists! Please use a different name.";
                $_SESSION['msg_type'] = "error";
                header("Location: departments.php");
                exit();
            }
            
            // Check if department code already exists (if provided)
            if (!empty($dept_code)) {
                $check_code = $conn->query("SELECT dept_id FROM Department WHERE dept_code = '$dept_code'");
                if ($check_code->num_rows > 0) {
                    $_SESSION['message'] = "Department code already exists! Please use a different code.";
                    $_SESSION['msg_type'] = "error";
                    header("Location: departments.php");
                    exit();
                }
            }
            
            $sql = "INSERT INTO Department (dept_name, dept_code) VALUES ('$dept_name', '$dept_code')";
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Department added successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
        }
        
        elseif ($action == 'edit') {
            $dept_id = $_POST['dept_id'];
            $dept_name = $database->escapeString($_POST['dept_name']);
            $dept_code = $database->escapeString($_POST['dept_code']);
            
            // Check if department name already exists for another department
            $check_name = $conn->query("SELECT dept_id FROM Department WHERE dept_name = '$dept_name' AND dept_id != $dept_id");
            if ($check_name->num_rows > 0) {
                $_SESSION['message'] = "Department name already exists! Please use a different name.";
                $_SESSION['msg_type'] = "error";
                header("Location: departments.php");
                exit();
            }
            
            // Check if department code already exists for another department (if provided)
            if (!empty($dept_code)) {
                $check_code = $conn->query("SELECT dept_id FROM Department WHERE dept_code = '$dept_code' AND dept_id != $dept_id");
                if ($check_code->num_rows > 0) {
                    $_SESSION['message'] = "Department code already exists! Please use a different code.";
                    $_SESSION['msg_type'] = "error";
                    header("Location: departments.php");
                    exit();
                }
            }
            
            $sql = "UPDATE Department SET dept_name='$dept_name', dept_code='$dept_code' WHERE dept_id=$dept_id";
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Department updated successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
        }
        
    elseif ($action == 'delete') {
    $dept_id = $_POST['dept_id'];
    
    // Optional: Show warning message about cascade delete
    $_SESSION['message'] = "Department deleted successfully! All associated courses, subjects, and related data have been removed.";
    $_SESSION['msg_type'] = "success";
    
    // Simple delete - cascade will handle everything
    $sql = "DELETE FROM Department WHERE dept_id=$dept_id";
    
    if ($conn->query($sql)) {
        $_SESSION['message'] = "Department deleted successfully! All associated courses, subjects, and related data have been removed.";
        $_SESSION['msg_type'] = "success";
    } else {
        $_SESSION['message'] = "Error: " . $conn->error;
        $_SESSION['msg_type'] = "error";
    }
}
        
        header("Location: departments.php");
        exit();
    }
}

// Handle AJAX validation requests
if (isset($_GET['ajax']) && $_GET['ajax'] == 'validate') {
    $field = $_GET['field'];
    $value = $database->escapeString($_GET['value']);
    $current_id = isset($_GET['current_id']) ? intval($_GET['current_id']) : 0;
    
    $response = ['valid' => true, 'message' => ''];
    
    if ($field == 'dept_name') {
        $query = "SELECT dept_id FROM Department WHERE dept_name = '$value'";
        if ($current_id > 0) {
            $query .= " AND dept_id != $current_id";
        }
        $result = $conn->query($query);
        if ($result->num_rows > 0) {
            $response['valid'] = false;
            $response['message'] = 'Department name already exists';
        }
    }
    elseif ($field == 'dept_code') {
        if (!empty($value)) {
            $query = "SELECT dept_id FROM Department WHERE dept_code = '$value'";
            if ($current_id > 0) {
                $query .= " AND dept_id != $current_id";
            }
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                $response['valid'] = false;
                $response['message'] = 'Department code already exists';
            }
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Get all departments
$departments = $conn->query("SELECT * FROM Department ORDER BY dept_id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Manage Departments - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Additional styles for validation */
        .validation-message {
            font-size: 12px;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .validation-success {
            color: #28a745;
        }
        .validation-error {
            color: #dc3545;
        }
        .validation-spinner {
            display: inline-block;
            width: 12px;
            height: 12px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 5px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .input-error {
            border-color: #dc3545 !important;
        }
        .input-success {
            border-color: #28a745 !important;
        }
        .status-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 20px;
            height: 20px;
        }
        .form-group {
            position: relative;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                <a href="adminDashboard.php">
                    <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
                </a>
                <a href="departments.php" class="active">
                    <img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5>
                </a>
                <a href="courses.php">
                    <img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5>
                </a>
                <a href="subjects.php">
                    <img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5>
                </a>
                <a href="teachers.php">
                    <img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5>
                </a>
                <a href="students.php">
                    <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5>
                </a>
                <a href="allocations.php">
                    <img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5>
                </a>
                <a href="exams.php">
                    <img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5>
                </a>
                <a href="results.php">
                    <img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5>
                </a>
                <a href="feedbacks.php">
                    <img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5>
                </a>
                <a href="settings.php">
                    <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5>
                </a>
                <a href="../logout.php">
                    <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5>
                </a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2> <img src="../icons/Department.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Manage Departments</h2>
                    <button class="btn" onclick="$('#addModal').show()">Add New Department <img src="../icons/Add.png" style="height: 27px; vertical-align: middle; margin-right: 10px;"></button>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Department Name</th>
                            <th>Department Code</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $departments->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['dept_id']; ?></td>
                            <td><?php echo $row['dept_name']; ?></td>
                            <td><?php echo $row['dept_code']; ?></td>
                            <td>
                                <button class="action-btn edit-btn" onclick="editDepartment(<?php echo htmlspecialchars(json_encode($row)); ?>)" title="Edit"><img src="../icons/Edit.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></button>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this department? This action cannot be undone.')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="dept_id" value="<?php echo $row['dept_id']; ?>">
                                    <button type="submit" class="action-btn delete-btn" title="Delete"><img src="../icons/Delete.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Add New Department</h2>
            <form method="POST" id="addForm" onsubmit="return validateAddForm()">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label>Department Name <span style="color: red;">*</span></label>
                    <input type="text" name="dept_name" id="add_dept_name" required onkeyup="validateField('add', 'dept_name', this.value)">
                    <div id="add_dept_name_validation" class="validation-message"></div>
                </div>
                
                <div class="form-group">
                    <label>Department Code</label>
                    <input type="text" name="dept_code" id="add_dept_code" onkeyup="validateField('add', 'dept_code', this.value)">
                    <div id="add_dept_code_validation" class="validation-message"></div>
                </div>
                
                <button type="submit" class="btn" id="add_submit_btn">Add Department</button>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Edit Department</h2>
            <form method="POST" id="editForm" onsubmit="return validateEditForm()">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="dept_id" id="edit_dept_id">
                
                <div class="form-group">
                    <label>Department Name <span style="color: red;">*</span></label>
                    <input type="text" name="dept_name" id="edit_dept_name" required onkeyup="validateField('edit', 'dept_name', this.value, document.getElementById('edit_dept_id').value)">
                    <div id="edit_dept_name_validation" class="validation-message"></div>
                </div>
                
                <div class="form-group">
                    <label>Department Code</label>
                    <input type="text" name="dept_code" id="edit_dept_code" onkeyup="validateField('edit', 'dept_code', this.value, document.getElementById('edit_dept_id').value)">
                    <div id="edit_dept_code_validation" class="validation-message"></div>
                </div>
                
                <button type="submit" class="btn" id="edit_submit_btn">Update Department</button>
            </form>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
    let validationTimeouts = {};
    let validationState = {
        add: { dept_name: true, dept_code: true },
        edit: { dept_name: true, dept_code: true }
    };
    
    function validateField(modal, field, value, currentId = 0) {
        const validationDiv = document.getElementById(`${modal}_${field}_validation`);
        const inputField = document.getElementById(`${modal}_${field}`);
        
        // Clear previous timeout
        if (validationTimeouts[`${modal}_${field}`]) {
            clearTimeout(validationTimeouts[`${modal}_${field}`]);
        }
        
        // Handle empty fields
        if (value.trim() === '') {
            if (field === 'dept_name') {
                // Required field - invalid when empty
                validationDiv.innerHTML = '<span class="validation-error">Department name is required</span>';
                inputField.classList.add('input-error');
                inputField.classList.remove('input-success');
                validationState[modal][field] = false;
            } else {
                // Optional field (dept_code) - valid when empty
                validationDiv.innerHTML = '<span class="validation-success">✓ Optional</span>';
                inputField.classList.remove('input-error', 'input-success');
                validationState[modal][field] = true;
            }
            updateSubmitButton(modal);
            return;
        }
        
        // Show loading state
        validationDiv.innerHTML = '<span class="validation-spinner"></span> Checking...';
        validationDiv.className = 'validation-message';
        inputField.classList.remove('input-error', 'input-success');
        
        // Set timeout to avoid too many requests
        validationTimeouts[`${modal}_${field}`] = setTimeout(() => {
            fetch(`departments.php?ajax=validate&field=${field}&value=${encodeURIComponent(value)}&current_id=${currentId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.valid) {
                        validationDiv.innerHTML = '<span class="validation-success">✓ Available</span>';
                        inputField.classList.add('input-success');
                        inputField.classList.remove('input-error');
                        validationState[modal][field] = true;
                    } else {
                        validationDiv.innerHTML = `<span class="validation-error"> ${data.message}</span>`;
                        inputField.classList.add('input-error');
                        inputField.classList.remove('input-success');
                        validationState[modal][field] = false;
                    }
                    updateSubmitButton(modal);
                })
                .catch(error => {
                    console.error('Validation error:', error);
                    validationDiv.innerHTML = '<span class="validation-error">⚠ Validation failed</span>';
                    validationState[modal][field] = true; // Allow submission on error
                    updateSubmitButton(modal);
                });
        }, 500);
    }
    
    function updateSubmitButton(modal) {
        const submitBtn = document.getElementById(`${modal}_submit_btn`);
        const state = validationState[modal];
        
        // Check if all fields are valid
        // dept_name must be true, dept_code must be true (empty is true, valid code is true)
        if (state.dept_name && state.dept_code) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
        } else {
            submitBtn.disabled = true;
            submitBtn.style.opacity = '0.5';
            submitBtn.style.cursor = 'not-allowed';
        }
    }
    
    function validateAddForm() {
        const state = validationState.add;
        const deptName = document.getElementById('add_dept_name').value.trim();
        const deptCode = document.getElementById('add_dept_code').value.trim();
        
        // Check if required fields are filled
        if (!deptName) {
            alert('Please enter a department name.');
            return false;
        }
        
        // Check validation state
        if (!state.dept_name) {
            alert('Please fix validation errors in department name before submitting.');
            return false;
        }
        
        // For dept_code, we only need to check if it's invalid (false) - if it's empty or valid, it's fine
        if (deptCode !== '' && !state.dept_code) {
            alert('Please fix validation errors in department code before submitting.');
            return false;
        }
        
        return true;
    }
    
    function validateEditForm() {
        const state = validationState.edit;
        const deptName = document.getElementById('edit_dept_name').value.trim();
        const deptCode = document.getElementById('edit_dept_code').value.trim();
        
        // Check if required fields are filled
        if (!deptName) {
            alert('Please enter a department name.');
            return false;
        }
        
        // Check validation state
        if (!state.dept_name) {
            alert('Please fix validation errors in department name before submitting.');
            return false;
        }
        
        // For dept_code, we only need to check if it's invalid (false) - if it's empty or valid, it's fine
        if (deptCode !== '' && !state.dept_code) {
            alert('Please fix validation errors in department code before submitting.');
            return false;
        }
        
        return true;
    }
    
    function editDepartment(dept) {
        $('#edit_dept_id').val(dept.dept_id);
        $('#edit_dept_name').val(dept.dept_name);
        $('#edit_dept_code').val(dept.dept_code);
        
        // Reset validation state for edit modal
        validationState.edit = { dept_name: true, dept_code: true };
        
        // Clear validation messages
        document.getElementById('edit_dept_name_validation').innerHTML = '';
        document.getElementById('edit_dept_code_validation').innerHTML = '';
        
        // Remove input classes
        document.getElementById('edit_dept_name').classList.remove('input-error', 'input-success');
        document.getElementById('edit_dept_code').classList.remove('input-error', 'input-success');
        
        // Enable submit button
        document.getElementById('edit_submit_btn').disabled = false;
        document.getElementById('edit_submit_btn').style.opacity = '1';
        
        $('#editModal').show();
    }
    
    // Initialize on document ready
    $(document).ready(function() {
        // Initialize add modal with submit button disabled because dept_name is required and empty
        document.getElementById('add_submit_btn').disabled = true;
        document.getElementById('add_submit_btn').style.opacity = '0.5';
        
        // Close modals when clicking outside
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = 'none';
            }
        }
    });
    
    // Reset validation when opening add modal
    $('#addModal').on('click', function(event) {
        if (event.target === this) {
            setTimeout(() => {
                validationState.add = { dept_name: true, dept_code: true };
                document.getElementById('add_dept_name_validation').innerHTML = '';
                document.getElementById('add_dept_code_validation').innerHTML = '';
                document.getElementById('add_dept_name').classList.remove('input-error', 'input-success');
                document.getElementById('add_dept_code').classList.remove('input-error', 'input-success');
                document.getElementById('add_submit_btn').disabled = true; // Disabled because dept_name is empty
                document.getElementById('add_submit_btn').style.opacity = '0.5';
            }, 100);
        }
    });
    
    // Add input event listeners for real-time validation
    document.addEventListener('DOMContentLoaded', function() {
        // Add modal listeners
        document.getElementById('add_dept_name').addEventListener('input', function() {
            validateField('add', 'dept_name', this.value);
        });
        
        document.getElementById('add_dept_code').addEventListener('input', function() {
            validateField('add', 'dept_code', this.value);
        });
        
        // Edit modal listeners
        document.getElementById('edit_dept_name').addEventListener('input', function() {
            validateField('edit', 'dept_name', this.value, document.getElementById('edit_dept_id').value);
        });
        
        document.getElementById('edit_dept_code').addEventListener('input', function() {
            validateField('edit', 'dept_code', this.value, document.getElementById('edit_dept_id').value);
        });
        
        // Focus listeners for add modal
        document.getElementById('add_dept_name').addEventListener('focus', function() {
            if (this.value.trim() !== '') {
                validateField('add', 'dept_name', this.value);
            } else {
                // Show required message on focus if empty
                document.getElementById('add_dept_name_validation').innerHTML = '<span class="validation-error">❌ Department name is required</span>';
                document.getElementById('add_dept_name').classList.add('input-error');
                validationState.add.dept_name = false;
                updateSubmitButton('add');
            }
        });
        
        document.getElementById('add_dept_code').addEventListener('focus', function() {
            if (this.value.trim() !== '') {
                validateField('add', 'dept_code', this.value);
            } else {
                // Show optional message on focus if empty
                document.getElementById('add_dept_code_validation').innerHTML = '<span class="validation-success">✓ Optional</span>';
                document.getElementById('add_dept_code').classList.remove('input-error', 'input-success');
                validationState.add.dept_code = true;
                updateSubmitButton('add');
            }
        });
        
        // Blur listeners to maintain validation state
        document.getElementById('add_dept_name').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                document.getElementById('add_dept_name_validation').innerHTML = '<span class="validation-error">❌ Department name is required</span>';
                document.getElementById('add_dept_name').classList.add('input-error');
                validationState.add.dept_name = false;
                updateSubmitButton('add');
            }
        });
    });
</script>
</body>
</html>