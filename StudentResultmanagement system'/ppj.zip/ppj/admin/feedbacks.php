<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Handle Reply and Delete operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'reply') {
            $contact_id = intval($_POST['contact_id']); // Sanitize as integer
            $admin_reply = $database->escapeString(trim($_POST['admin_reply']));
            
            // Use prepared statement or properly escape
            $sql = "UPDATE contact SET 
                    admin_reply = '$admin_reply', 
                    reply_date = NOW() 
                    WHERE contact_id = $contact_id";
            
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Reply sent successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
            
            // Redirect to prevent form resubmission
            header("Location: feedbacks.php");
            exit();
        }
        
        elseif ($action == 'delete') {
            $contact_id = intval($_POST['contact_id']); // Sanitize as integer
            $sql = "DELETE FROM contact WHERE contact_id = $contact_id";
            
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Feedback deleted successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
            
            header("Location: feedbacks.php");
            exit();
        }
    }
}

// Handle AJAX search requests
if (isset($_GET['ajax_search'])) {
    $search = $database->escapeString($_GET['search']);
    
    $query = "SELECT * FROM contact WHERE 1=1";
    
    if (!empty($search)) {
        $query .= " AND (name LIKE '%$search%' OR email LIKE '%$search%' OR suggestion LIKE '%$search%')";
    }
    
    $query .= " ORDER BY contact_date DESC LIMIT 10";
    $result = $conn->query($query);
    
    $output = '';
    $i = 1;
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Properly escape for JSON
            $suggestion = str_replace(["\r\n", "\r", "\n"], '\\n', addslashes($row['suggestion']));
            $name = addslashes($row['name']);
            
            $replyHtml = !empty($row['admin_reply']) 
                ? "<strong>Reply:</strong><br>" . nl2br(htmlspecialchars($row['admin_reply'])) . "<br><small class='reply-date'>{$row['reply_date']}</small>"
                : "<span class='status-badge status-pending'>Not Replied</span>";
            
            $output .= "<tr>
                <td>{$i}</td>
                <td>" . htmlspecialchars($row['name']) . "</td>
                <td>" . htmlspecialchars($row['email']) . "</td>
                <td class='suggestion-cell'>" . nl2br(htmlspecialchars($row['suggestion'])) . "</td>
                <td>{$row['contact_date']}</td>
                <td class='reply-cell'>{$replyHtml}</td>
                <td class='action-cell'>
                    <button class='action-btn reply-btn' onclick='openReplyModal({$row['contact_id']}, \"{$name}\", \"" . htmlspecialchars($row['email']) . "\", \"{$suggestion}\")' title='Reply'>
                        <img src='../icons/reply.png' style='height: 22px; vertical-align: middle;'>
                    </button>
                    <form method='POST' style='display: inline;' onsubmit='return confirm(\"Are you sure you want to delete this feedback?\")'>
                        <input type='hidden' name='action' value='delete'>
                        <input type='hidden' name='contact_id' value='{$row['contact_id']}'>
                        <button type='submit' class='action-btn delete-btn' title='Delete'>
                            <img src='../icons/Delete.png' style='height: 22px; vertical-align: middle;'>
                        </button>
                    </form>
                </td>
            </tr>";
            $i++;
        }
    } else {
        $output = "<tr><td colspan='7' class='no-data'>No messages found</td></tr>";
    }
    
    echo $output;
    exit();
}

// Get all feedbacks with pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Get total records for pagination
$total_result = $conn->query("SELECT COUNT(*) as total FROM contact");
$total_row = $total_result->fetch_assoc();
$total_records = $total_row['total'];
$total_pages = ceil($total_records / $limit);

// Get feedbacks for current page
$feedbacks = $conn->query("
    SELECT * FROM contact 
    ORDER BY 
        CASE WHEN admin_reply IS NULL OR admin_reply = '' THEN 0 ELSE 1 END,
        contact_date DESC 
    LIMIT $offset, $limit
");

// Get counts for stats
$total_feedbacks = $conn->query("SELECT COUNT(*) as count FROM contact")->fetch_assoc()['count'];
$replied_feedbacks = $conn->query("SELECT COUNT(*) as count FROM contact WHERE admin_reply IS NOT NULL AND admin_reply != ''")->fetch_assoc()['count'];
$pending_feedbacks = $total_feedbacks - $replied_feedbacks;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Manage Feedbacks - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Feedback Page Specific Styles */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .stat-card.pending {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        
        .stat-card.replied {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        
        .stat-card h3 {
            margin: 0;
            font-size: 14px;
            opacity: 0.9;
        }
        
        .stat-card .stat-number {
            font-size: 36px;
            font-weight: bold;
            margin: 10px 0;
        }
        
        .search-section {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .search-box {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .search-box input {
            flex: 1;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .search-box input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .search-box button {
            padding: 12px 24px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .search-box button:hover {
            background: #5a67d8;
        }
        
        .table-container {
            overflow-x: auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #dee2e6;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            vertical-align: top;
        }
        
        .suggestion-cell {
            max-width: 300px;
            word-wrap: break-word;
        }
        
        .reply-cell {
            max-width: 250px;
            word-wrap: break-word;
        }
        
        .reply-date {
            color: #6c757d;
            font-size: 12px;
            margin-top: 5px;
            display: block;
        }
        
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-replied {
            background: #d4edda;
            color: #155724;
        }
        
        .action-cell {
            white-space: nowrap;
        }
        
        .action-btn {
            background: none;
            border: none;
            cursor: pointer;
            padding: 5px;
            margin: 0 2px;
            border-radius: 4px;
            transition: background 0.3s;
        }
        
        .action-btn:hover {
            background: #f0f0f0;
        }
        
        .reply-btn:hover {
            background: #e3f2fd;
        }
        
        .delete-btn:hover {
            background: #ffebee;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
            padding: 20px;
        }
        
        .pagination a {
            padding: 8px 12px;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            text-decoration: none;
            color: #667eea;
            transition: all 0.3s;
        }
        
        .pagination a:hover {
            background: #667eea;
            color: white;
        }
        
        .pagination a.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            position: relative;
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            position: absolute;
            right: 20px;
            top: 15px;
        }
        
        .close:hover {
            color: #333;
        }
        
        .feedback-details {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
            margin: 20px 0;
        }
        
        .feedback-details p {
            margin: 10px 0;
        }
        
        .feedback-details strong {
            color: #333;
            display: inline-block;
            width: 80px;
        }
        
        .feedback-message {
            background: white;
            padding: 15px;
            border-radius: 6px;
            margin-top: 10px;
            border-left: 4px solid #667eea;
        }
        
        .reply-form textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
            margin: 15px 0;
            resize: vertical;
        }
        
        .reply-form textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn {
            padding: 12px 24px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #5a67d8;
        }
        
        .btn-secondary {
            background: #6c757d;
            margin-left: 10px;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 6px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @media (max-width: 768px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .search-box {
                flex-direction: column;
            }
            
            .search-box button {
                width: 100%;
            }
            
            td {
                min-width: 150px;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                <a href="adminDashboard.php">
                    <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
                </a>
                <a href="departments.php">
                    <img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5>
                </a>
                <a href="courses.php">
                    <img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5>
                </a>
                <a href="subjects.php">
                    <img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5>
                </a>
                <a href="students.php">
                    <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5>
                </a>
                <a href="teachers.php">
                    <img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5>
                </a>
                <a href="allocations.php">
                    <img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5>
                </a>
                <a href="exams.php">
                    <img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5>
                </a>
                <a href="results.php">
                    <img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5>
                </a>
                <a href="feedbacks.php" class="active">
                    <img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5>
                </a>
                <a href="settings.php">
                    <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5>
                </a>
                <a href="../logout.php">
                    <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5>
                </a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <?php 
                    echo htmlspecialchars($_SESSION['message']);
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <!-- Statistics Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <h3>Total Feedbacks</h3>
                    <div class="stat-number"><?php echo $total_feedbacks; ?></div>
                </div>
                <div class="stat-card replied">
                    <h3>Replied</h3>
                    <div class="stat-number"><?php echo $replied_feedbacks; ?></div>
                </div>
                <div class="stat-card pending">
                    <h3>Pending</h3>
                    <div class="stat-number"><?php echo $pending_feedbacks; ?></div>
                </div>
            </div>
            
            <!-- Search Section -->
            <div class="search-section">
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="Search by name, email, or message..." autocomplete="off">
                    <button onclick="searchFeedbacks()">Search</button>
                </div>
            </div>
            
            <!-- Feedbacks Table -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Message</th>
                            <th>Received</th>
                            <th>Reply Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="feedbacksTableBody">
                        <?php 
                        $i = $offset + 1;
                        if ($feedbacks && $feedbacks->num_rows > 0) {
                            while($row = $feedbacks->fetch_assoc()): 
                        ?>
                        <tr>
                            <td><?php echo $i++; ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td class="suggestion-cell"><?php echo nl2br(htmlspecialchars($row['suggestion'])); ?></td>
                            <td><?php echo $row['contact_date']; ?></td>
                            <td class="reply-cell">
                                <?php if(!empty($row['admin_reply'])): ?>
                                    <span class="status-badge status-replied">Replied</span>
                                    <div style="margin-top: 5px; font-size: 13px;">
                                        <?php echo nl2br(htmlspecialchars($row['admin_reply'])); ?>
                                        <small class="reply-date"><?php echo $row['reply_date']; ?></small>
                                    </div>
                                <?php else: ?>
                                    <span class="status-badge status-pending">Not Replied</span>
                                <?php endif; ?>
                            </td>
                            <td class="action-cell">
                                <button class="action-btn reply-btn" onclick='openReplyModal(
                                    <?php echo $row['contact_id']; ?>, 
                                    "<?php echo addslashes(htmlspecialchars($row['name'])); ?>", 
                                    "<?php echo addslashes(htmlspecialchars($row['email'])); ?>", 
                                    "<?php echo addslashes(str_replace(["\r\n", "\r", "\n"], '\\n', $row['suggestion'])); ?>"
                                )' title="Reply">
                                    <img src="../icons/reply.png" style="height: 22px; vertical-align: middle;">
                                </button>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this feedback?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="contact_id" value="<?php echo $row['contact_id']; ?>">
                                    <button type="submit" class="action-btn delete-btn" title="Delete">
                                        <img src="../icons/Delete.png" style="height: 22px; vertical-align: middle;">
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php 
                            endwhile;
                        } else {
                            echo "<tr><td colspan='7' class='no-data'>No feedbacks found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if($total_pages > 1): ?>
            <div class="pagination">
                <?php if($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>">Previous</a>
                <?php endif; ?>
                
                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?php echo $i; ?>" class="<?php echo $i == $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
                
                <?php if($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>">Next</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Reply Modal -->
    <div id="replyModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeReplyModal()">&times;</span>
            <h2>Reply to Feedback</h2>
            
            <div class="feedback-details" id="feedbackDetails">
                <!-- Will be filled by JavaScript -->
            </div>
            
            <form method="POST" class="reply-form" id="replyForm" onsubmit="return validateReplyForm()">
                <input type="hidden" name="action" value="reply">
                <input type="hidden" name="contact_id" id="replyContactId">
                
                <label for="admin_reply">Your Reply:</label>
                <textarea name="admin_reply" id="adminReply" rows="6" required placeholder="Type your reply here..."></textarea>
                
                <div style="text-align: right;">
                    <button type="button" class="btn btn-secondary" onclick="closeReplyModal()">Cancel</button>
                    <button type="submit" class="btn">Send Reply</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        let searchTimeout;
        let currentSearchTerm = '';
        
        function searchFeedbacks() {
            const searchTerm = document.getElementById('searchInput').value;
            currentSearchTerm = searchTerm;
            
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                fetch(`feedbacks.php?ajax_search=1&search=${encodeURIComponent(searchTerm)}`)
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('feedbacksTableBody').innerHTML = data;
                    })
                    .catch(error => console.error('Error:', error));
            }, 300);
        }
        
        // Add event listener for search input
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.addEventListener('keyup', searchFeedbacks);
            }
        });
        
        function openReplyModal(id, name, email, suggestion) {
            document.getElementById('replyContactId').value = id;
            
            // Convert escaped newlines back to actual newlines for display
            const displaySuggestion = suggestion.replace(/\\n/g, '<br>');
            
            const detailsHtml = `
                <p><strong>Name:</strong> ${name}</p>
                <p><strong>Email:</strong> ${email}</p>
                <div class="feedback-message">
                    <strong>Message:</strong><br>
                    ${displaySuggestion}
                </div>
            `;
            
            document.getElementById('feedbackDetails').innerHTML = detailsHtml;
            document.getElementById('adminReply').value = '';
            document.getElementById('replyModal').style.display = 'block';
            
            // Prevent body scrolling when modal is open
            document.body.style.overflow = 'hidden';
        }
        
        function closeReplyModal() {
            document.getElementById('replyModal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        function validateReplyForm() {
            const reply = document.getElementById('adminReply').value.trim();
            if (reply === '') {
                alert('Please enter a reply message.');
                return false;
            }
            return true;
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('replyModal');
            if (event.target == modal) {
                closeReplyModal();
            }
        }
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeReplyModal();
            }
        });
        
        // Auto-refresh search results every 30 seconds (optional)
        setInterval(() => {
            if (document.getElementById('searchInput').value === '') {
                searchFeedbacks();
            }
        }, 30000);
    </script>
</body>
</html>