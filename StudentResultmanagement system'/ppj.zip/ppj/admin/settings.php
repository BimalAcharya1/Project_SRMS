<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Get current admin info
$admin_id = $_SESSION['admin_id'];
$admin_result = $conn->query("SELECT * FROM Admin WHERE admin_id = $admin_id");
$admin = $admin_result->fetch_assoc();

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'update_profile') {
            // Verify old password
            if (!password_verify($_POST['old_password'], $admin['password'])) {
                $_SESSION['message'] = "Old password is incorrect!";
                $_SESSION['msg_type'] = "error";
                header("Location: settings.php");
                exit();
            }
            
            $username = $database->escapeString($_POST['username']);
            $college = $database->escapeString($_POST['college_school']);
            $address = $database->escapeString($_POST['address']);
            
            $sql = "UPDATE Admin SET 
                    username = '$username',
                    college_school = '$college',
                    address = '$address'";
            
            // Handle password change (only if new password is provided)
            if (!empty($_POST['new_password'])) {
                if ($_POST['new_password'] !== $_POST['confirm_password']) {
                    $_SESSION['message'] = "New passwords do not match!";
                    $_SESSION['msg_type'] = "error";
                    header("Location: settings.php");
                    exit();
                }
                
                $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                $sql .= ", password = '$new_password'";
            }
            
            // Handle college logo upload
            if (!empty($_FILES['college_logo']['name'])) {
                $target_dir = "../admin/adminlog/uploads/";
                
                // Create directory if it doesn't exist
                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                
                // Delete old logo if exists
                if (!empty($admin['image']) && file_exists($target_dir . $admin['image'])) {
                    unlink($target_dir . $admin['image']);
                }
                
                $image_extension = pathinfo($_FILES['college_logo']['name'], PATHINFO_EXTENSION);
                $image_name = 'college_' . uniqid() . '.' . $image_extension;
                $target_file = $target_dir . $image_name;
                
                // Validate image
                $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'svg'];
                $max_file_size = 500 * 1024; // 500KB
                
                if ($_FILES['college_logo']['size'] > $max_file_size) {
                    $_SESSION['message'] = "File size too large. Maximum size is 500KB.";
                    $_SESSION['msg_type'] = "error";
                    header("Location: settings.php");
                    exit();
                }
                
                if (in_array(strtolower($image_extension), $allowed_types)) {
                    if (move_uploaded_file($_FILES['college_logo']['tmp_name'], $target_file)) {
                        $sql .= ", image = '$image_name'";
                    } else {
                        $_SESSION['message'] = "Failed to upload image.";
                        $_SESSION['msg_type'] = "error";
                        header("Location: settings.php");
                        exit();
                    }
                } else {
                    $_SESSION['message'] = "Invalid image format. Please upload JPG, PNG, GIF, or SVG.";
                    $_SESSION['msg_type'] = "error";
                    header("Location: settings.php");
                    exit();
                }
            }
            
            $sql .= " WHERE admin_id = $admin_id";
            
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Profile updated successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
            
            header("Location: settings.php");
            exit();
        }
        
        elseif ($action == 'delete_account') {
            // Verify password
            if (!password_verify($_POST['delete_password'], $admin['password'])) {
                $_SESSION['message'] = "Password incorrect. Cannot delete account.";
                $_SESSION['msg_type'] = "error";
                header("Location: settings.php");
                exit();
            }
            
            // Delete college logo if exists
            if (!empty($admin['image'])) {
                $image_path = "../admin/adminlog/uploads/" . $admin['image'];
                if (file_exists($image_path)) {
                    unlink($image_path);
                }
            }
            
            // Delete admin account
            $sql = "DELETE FROM Admin WHERE admin_id = $admin_id";
            
            if ($conn->query($sql)) {
                session_destroy();
                header("Location: ../login.php");
                exit();
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
                header("Location: settings.php");
                exit();
            }
        }
    }
}

// Get statistics for display
$total_departments = $conn->query("SELECT COUNT(*) as count FROM Department")->fetch_assoc()['count'];
$total_courses = $conn->query("SELECT COUNT(*) as count FROM Course")->fetch_assoc()['count'];
$total_subjects = $conn->query("SELECT COUNT(*) as count FROM Subject")->fetch_assoc()['count'];
$total_students = $conn->query("SELECT COUNT(*) as count FROM Student")->fetch_assoc()['count'];
$total_teachers = $conn->query("SELECT COUNT(*) as count FROM Teacher")->fetch_assoc()['count'];
$total_feedbacks = $conn->query("SELECT COUNT(*) as count FROM Contact")->fetch_assoc()['count'];

// Set image path
$image_path = "../admin/adminlog/uploads/";
$default_logo = "../icons/college-default.png";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Admin Settings - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Settings Page Specific Styles */
        :root {
            --primary-color: #4f46e5;
            --primary-dark: #4338ca;
            --primary-light: #818cf8;
            --secondary-color: #10b981;
            --danger-color: #ef4444;
            --warning-color: #f59e0b;
            --dark-bg: #1f2937;
        }
        
        .settings-container {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 30px;
            margin-top: 20px;
        }
        
        /* Sidebar Styles */
        .profile-sidebar {
            background: white;
            border-radius: 20px;
            padding: 25px 20px;
            box-shadow: 0 10px 40px rgba(79, 70, 229, 0.1);
            text-align: center;
            position: sticky;
            top: 20px;
            height: fit-content;
            border: 1px solid rgba(79, 70, 229, 0.1);
        }
        
        .college-logo-container {
            width: 140px;
            height: 140px;
            margin: 0 auto 15px;
            padding: 10px;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border-radius: 50%;
            box-shadow: 0 15px 30px rgba(79, 70, 229, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .college-logo-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.2), transparent);
            transform: rotate(45deg);
            animation: shimmer 3s infinite;
        }
        
        @keyframes shimmer {
            0% { transform: translateX(-100%) rotate(45deg); }
            100% { transform: translateX(100%) rotate(45deg); }
        }
        
        .college-logo {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .default-logo {
            width: 100%;
            height: 100%;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
            color: var(--primary-color);
            border: 3px solid white;
        }
        
        .college-name {
            font-size: 20px;
            font-weight: 700;
            color: var(--dark-bg);
            margin: 10px 0 5px;
        }
        
        .admin-badge {
            background: var(--primary-light);
            color: white;
            padding: 5px 15px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
            margin-bottom: 15px;
            letter-spacing: 0.5px;
        }
        
        .admin-info {
            background: #f8fafc;
            border-radius: 16px;
            padding: 15px;
            margin: 15px 0;
            border: 1px solid #e2e8f0;
        }
        
        .admin-info-item {
            display: flex;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px dashed #e2e8f0;
        }
        
        .admin-info-item:last-child {
            border-bottom: none;
        }
        
        .admin-info-icon {
            width: 32px;
            height: 32px;
            background: white;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            color: var(--primary-color);
            font-size: 16px;
            box-shadow: 0 3px 8px rgba(79, 70, 229, 0.1);
        }
        
        .admin-info-content {
            flex: 1;
            text-align: left;
        }
        
        .admin-info-label {
            font-size: 11px;
            color: #64748b;
            margin-bottom: 2px;
        }
        
        .admin-info-value {
            font-size: 14px;
            font-weight: 600;
            color: var(--dark-bg);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 15px;
        }
        
        .stat-card-small {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            padding: 12px 8px;
            border-radius: 16px;
            text-align: center;
            transition: all 0.3s;
            color: white;
            box-shadow: 0 8px 20px rgba(79, 70, 229, 0.2);
        }
        
        .stat-card-small:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(79, 70, 229, 0.3);
        }
        
        .stat-number-small {
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 2px;
        }
        
        .stat-label-small {
            font-size: 10px;
            opacity: 0.9;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Main Settings Styles */
        .settings-main {
            flex: 1;
        }
        
        .settings-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(79, 70, 229, 0.1);
            border: 1px solid rgba(79, 70, 229, 0.1);
        }
        
        .settings-header {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f1f5f9;
        }
        
        .settings-header h3 {
            margin: 0;
            color: var(--dark-bg);
            font-size: 20px;
            font-weight: 700;
        }
        
        .settings-header .header-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 22px;
            box-shadow: 0 8px 15px rgba(79, 70, 229, 0.2);
        }
        
        .form-row {
            margin-bottom: 25px;
        }
        
        .form-row label {
            display: block;
            margin-bottom: 8px;
            color: var(--dark-bg);
            font-weight: 600;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            font-size: 14px;
            transition: all 0.3s;
            background: #f8fafc;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
            background: white;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            width: 20px;
            height: 20px;
            opacity: 0.6;
        }
        
        .input-with-icon {
            padding-left: 45px;
        }
        
        /* File Upload Styles */
        .file-upload {
            border: 2px dashed var(--primary-color);
            border-radius: 14px;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: #e8f5e5;
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: auto;
            min-width: 250px;

        }
        
        .file-upload:hover {
            border-color: var(--secondary-color);
            background: #f5f9fc;
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(46, 39, 163, 0.15);
        }
        
        .file-upload input {
            display: none;
        }
        
        .file-upload-label {
            color: var(--primary-color);
            font-weight: 600;
            font-size: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .file-upload-label img {
            width: 20px;
            height: 20px;
        }
        
        .file-name {
            margin-top: 8px;
            font-size: 11px;
            color: var(--dark-bg);
            padding: 4px 12px;
            background: white;
            border-radius: 30px;
            display: inline-block;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
            border: 1px solid #e2e8f0;
        }
        
        /* Password Strength */
        .password-strength {
            margin-top: 8px;
            height: 5px;
            background: #e2e8f0;
            border-radius: 3px;
            overflow: hidden;
            width: 100%;
        }
        
        .strength-bar {
            height: 100%;
            width: 0;
            transition: width 0.3s;
        }
        
        .strength-bar.weak {
            background: var(--danger-color);
            width: 33.33%;
        }
        
        .strength-bar.medium {
            background: var(--warning-color);
            width: 66.66%;
        }
        
        .strength-bar.strong {
            background: var(--secondary-color);
            width: 100%;
        }
        
        .password-match {
            font-size: 12px;
            margin-top: 6px;
            padding: 6px 12px;
            border-radius: 8px;
            display: inline-block;
        }
        
        .match-success {
            background: #d1fae5;
            color: var(--secondary-color);
            border-left: 3px solid var(--secondary-color);
        }
        
        .match-error {
            background: #fee2e2;
            color: var(--danger-color);
            border-left: 3px solid var(--danger-color);
        }
        
        /* Buttons */
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            box-shadow: 0 8px 20px rgba(79, 70, 229, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 25px rgba(79, 70, 229, 0.4);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, var(--danger-color) 0%, #f87171 100%);
            color: white;
            box-shadow: 0 8px 20px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 25px rgba(239, 68, 68, 0.4);
        }
        
        /* Alerts */
        .alert {
            padding: 15px 20px;
            border-radius: 14px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s ease-out;
            border-left: 4px solid;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left-color: var(--secondary-color);
        }
        
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left-color: var(--danger-color);
        }
        
        /* Danger Zone */
        .danger-zone {
            border: 2px solid var(--danger-color);
            background: #fff5f5;
        }
        
        .danger-header {
            color: var(--danger-color);
        }
        
        /* Info Box */
        .info-box {
            background: linear-gradient(135deg, #dbeafe 0%, #ede9fe 100%);
            padding: 15px 20px;
            border-radius: 14px;
            margin-bottom: 25px;
            border-left: 4px solid var(--primary-color);
        }
        
        .info-box p {
            margin: 3px 0;
            color: var(--dark-bg);
            font-size: 13px;
        }
        
        .info-box strong {
            color: var(--primary-color);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .settings-container {
                grid-template-columns: 1fr;
            }
            
            .profile-sidebar {
                position: static;
            }
            
            .college-logo-container {
                width: 120px;
                height: 120px;
            }
            
            .file-upload {
                width: 100%;
            }
            
            .current-logo {
                width: 100%;
            }
        }
        
        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                <a href="adminDashboard.php">
                    <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
                </a>
                <a href="departments.php">
                    <img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5>
                </a>
                <a href="courses.php">
                    <img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5>
                </a>
                <a href="subjects.php">
                    <img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5>
                </a>
                <a href="students.php">
                    <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5>
                </a>
                <a href="teachers.php">
                    <img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5>
                </a>
                <a href="allocations.php">
                    <img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5>
                </a>
                <a href="exams.php">
                    <img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5>
                </a>
                <a href="results.php">
                    <img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5>
                </a>
                <a href="feedbacks.php">
                    <img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5>
                </a>
                <a href="settings.php" class="active">
                    <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5>
                </a>
                <a href="../logout.php">
                    <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5>
                </a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="settings-container">
                <!-- Profile Sidebar -->
                <div class="profile-sidebar">
                    <div class="college-logo-container">
                        <?php if(!empty($admin['image']) && file_exists($image_path . $admin['image'])): ?>
                            <img src="<?php echo $image_path . $admin['image']; ?>" alt="College Logo" class="college-logo">
                        <?php else: ?>
                            <div class="default-logo">
                               <img src="../icons/college.png" style="height: 80px; vertical-align: middle; margin-right: 10px;">
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="college-name">
                        <?php echo $admin['college_school'] ?? 'College Name'; ?>
                    </div>
                    
                    <div class="admin-badge">
                        Administrator
                    </div>
                    
                    <div class="admin-info">
                        <div class="admin-info-item">
                            <div class="admin-info-icon">
                                <img src="../icons/Admin.png" style="width: 18px; height: 18px;">
                            </div>
                            <div class="admin-info-content">
                                <div class="admin-info-label">Username</div>
                                <div class="admin-info-value"><?php echo $admin['username']; ?></div>
                            </div>
                        </div>
                        <div class="admin-info-item">
                            <div class="admin-info-icon">
                                <img src="../icons/id.png" style="width: 18px; height: 18px;">
                            </div>
                            <div class="admin-info-content">
                                <div class="admin-info-label">Admin ID</div>
                                <div class="admin-info-value"><?php echo $admin['admin_id']; ?></div>
                            </div>
                        </div>
                        <div class="admin-info-item">
                            <div class="admin-info-icon">
                                <img src="../icons/location.png" style="width: 18px; height: 18px;">
                            </div>
                            <div class="admin-info-content">
                                <div class="admin-info-label">Address</div>
                                <div class="admin-info-value"><?php echo $admin['address'] ?? 'Not set'; ?></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stats-grid">
                        <div class="stat-card-small">
                            <div class="stat-number-small"><?php echo $total_departments; ?></div>
                            <div class="stat-label-small">Depts</div>
                        </div>
                        <div class="stat-card-small">
                            <div class="stat-number-small"><?php echo $total_courses; ?></div>
                            <div class="stat-label-small">Courses</div>
                        </div>
                        <div class="stat-card-small">
                            <div class="stat-number-small"><?php echo $total_subjects; ?></div>
                            <div class="stat-label-small">Subjects</div>
                        </div>
                        <div class="stat-card-small">
                            <div class="stat-number-small"><?php echo $total_students; ?></div>
                            <div class="stat-label-small">Students</div>
                        </div>
                        <div class="stat-card-small">
                            <div class="stat-number-small"><?php echo $total_teachers; ?></div>
                            <div class="stat-label-small">Teachers</div>
                        </div>
                        <div class="stat-card-small">
                            <div class="stat-number-small"><?php echo $total_feedbacks; ?></div>
                            <div class="stat-label-small">Feedback</div>
                        </div>
                    </div>
                </div>
                
                <!-- Settings Main -->
                <div class="settings-main">
                    <!-- Profile Settings Card -->
                    <div class="settings-card">
                        <div class="settings-header">
                            <span class="header-icon"><img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></span>
                            <h3>Profile Settings</h3>
                        </div>
                        
                        <div class="info-box">
                            <p><strong><img src="../icons/note.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"> Note:</strong> Update your profile information below.</p>
                            <p><strong><img src="../icons/image.png" style="height: 22px; vertical-align: middle; margin-right: 10px;">Logo:</strong> Upload college logo (Max: 500KB, Format: JPG, PNG, GIF, SVG)</p>
                            <p><strong><img src="../icons/passwords.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"> Password:</strong> Leave password fields blank to keep current password.</p>
                        </div>
                        
                        <form method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="update_profile">
                            
                            <div class="form-row">
                                <label>Username</label>
                                <div class="input-group">
                                   
                                    <input type="text" name="username" class="form-control input-with-icon" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <label>College/School Name</label>
                                <div class="input-group">
                                
                                    <input type="text" name="college_school" class="form-control input-with-icon" value="<?php echo htmlspecialchars($admin['college_school'] ?? ''); ?>">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <label>Address</label>
                                <div class="input-group">
                                  
                                    <input type="text" name="address" class="form-control input-with-icon" value="<?php echo htmlspecialchars($admin['address'] ?? ''); ?>">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <label>College Logo</label>
                                <div class="file-upload" onclick="document.getElementById('collegeLogo').click()">
                                    <input type="file" name="college_logo" id="collegeLogo" accept="image/*" onchange="updateFileName(this)">
                                    <span class="file-upload-label">
                                        <img src="../icons/upload.png" alt="Upload">
                                        Click to upload college logo
                                    </span>
                                    <div id="fileName" class="file-name"></div>
                                </div>
                
                            </div>
                            
                            <div class="form-row">
                                <label>Old Password</label>
                                <div class="input-group">
                                    
                                    <input type="password" name="old_password" class="form-control input-with-icon" placeholder="Enter current password" required>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <label>New Password (optional)</label>
                                <div class="input-group">
                                    
                                    <input type="password" name="new_password" id="newPassword" class="form-control input-with-icon" placeholder="Enter new password" onkeyup="checkPasswordStrength()">
                                </div>
                                <div class="password-strength">
                                    <div class="strength-bar" id="strengthBar"></div>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <label>Confirm New Password</label>
                                <div class="input-group">
                                    
                                    <input type="password" name="confirm_password" id="confirmPassword" class="form-control input-with-icon" placeholder="Confirm new password" onkeyup="checkPasswordMatch()">
                                </div>
                                <div id="passwordMatchMsg" class="password-match"></div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Update Profile</button>
                        </form>
                    </div>
                    
                    <!-- Danger Zone Card -->
                    <div class="settings-card danger-zone">
                        <div class="settings-header">
                            <span class="header-icon" style="background: var(--danger-color);"><img src="../icons/danger.png" style="height: 25px; vertical-align: middle; margin-right: 10px;"></span>
                            <h3 class="danger-header">Danger Zone</h3>
                        </div>
                        
                        <p style="color: #64748b; margin-bottom: 20px;">Once you delete your account, there is no going back. Please be certain.</p>
                        
                        <form method="POST" onsubmit="return confirm('Are you absolutely sure you want to delete your account? This action cannot be undone and will delete all your data permanently.')">
                            <input type="hidden" name="action" value="delete_account">
                            
                            <div class="form-row">
                                <label>Enter Password to Confirm</label>
                                <div class="input-group">
                        
                                    <input type="password" name="delete_password" class="form-control input-with-icon" placeholder="Enter your password" required>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-danger">Delete My Account</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        function updateFileName(input) {
            if (input.files && input.files[0]) {
                document.getElementById('fileName').innerHTML = '📎 Selected: ' + input.files[0].name;
            }
        }
        
        function checkPasswordStrength() {
            const password = document.getElementById('newPassword').value;
            const strengthBar = document.getElementById('strengthBar');
            
            strengthBar.className = 'strength-bar';
            
            if (password.length === 0) {
                strengthBar.style.width = '0';
                return;
            }
            
            let strength = 0;
            
            if (password.length >= 8) strength++;
            if (password.length >= 12) strength++;
            if (/\d/.test(password)) strength++;
            if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength++;
            if (/[A-Z]/.test(password)) strength++;
            
            if (strength <= 2) {
                strengthBar.classList.add('weak');
            } else if (strength <= 4) {
                strengthBar.classList.add('medium');
            } else {
                strengthBar.classList.add('strong');
            }
        }
        
        function checkPasswordMatch() {
            const password = document.getElementById('newPassword').value;
            const confirm = document.getElementById('confirmPassword').value;
            const msg = document.getElementById('passwordMatchMsg');
            
            if (confirm.length === 0) {
                msg.innerHTML = '';
                msg.className = 'password-match';
                return;
            }
            
            if (password === confirm) {
                msg.innerHTML = 'Passwords match';
                msg.className = 'password-match match-success';
            } else {
                msg.innerHTML = 'Passwords do not match';
                msg.className = 'password-match match-error';
            }
        }
        
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                alert.style.transition = 'opacity 0.5s';
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 500);
            });
        }, 5000);
    </script>
</body>
</html>