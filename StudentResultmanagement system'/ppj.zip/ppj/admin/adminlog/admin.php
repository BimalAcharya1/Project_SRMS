<?php
include "../../Database/dbc.php";

// Check if any admin exists
$result = $conn->query("SELECT COUNT(*) AS total FROM admin");
$row = $result->fetch_assoc();
$adminExists = $row['total'] > 0;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Access</title>
     <link rel="icon" type="image/png" href="../../icons/SRMS.png">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../CSS/dashboard.css">
    <link rel="stylesheet" href="../CSS/icons.css">
    <link rel="stylesheet" href="../../CSS/form.css">
     <style>
        body{
        background: url("../../images/Admin.jpg") no-repeat center center/cover;
         height: 100vh;
        }
    </style>
</head>
<body>

<?php if (!$adminExists): ?>
    <!-- ================= SIGN UP FORM ================= -->
   
<form method="POST" action="admin_signup.php" enctype="multipart/form-data" class="form-box" onsubmit="return checkPasswordMatch()">
     
    <h2 style="text-align: center;"> 
    <img src="../../icons/Admin.png"><br></h2>

    <input type="text" name="admin_id" placeholder="Admin ID" required><br><br>

    <input type="text" name="username" placeholder="Username" required><br><br>

    <!-- PASSWORD -->
    <div class="password-box">
        <input type="password" name="password" id="password" placeholder="Password" required>
        <img src="../../icons/eyeClosed.png"
             id="signupEye"
             onclick="togglePassword('password','signupEye')">
    </div>
    <br>

    <!-- CONFIRM PASSWORD -->
    <div class="password-box">
        <input type="password" id="confirm_password" placeholder="Confirm Password" required>
        <img src="../../icons/eyeClosed.png"
             id="confirmEye"
             onclick="togglePassword('confirm_password','confirmEye')">
             <p id="passMsg" style="font-size:14px;margin-bottom:5px;"></p>
    </div>
    <br>

    <input type="file" name="image" accept="image/*" required><br><br>

    <input type="text" name="college_school" placeholder="College/School Full Name"><br><br>

    <input type="text" name="address" placeholder="College/School Full Address"><br><br>

    <button type="submit" name="signup">SIGN UP</button>
</form>


<?php else: ?>
    <!-- ================= LOGIN FORM ================= -->
    
<form method="POST" action="admin_login.php" class="form-box">
        <h2 style="text-align: center;"> 
    <img src="../../icons/Admin.png"><br></h2>
    <!-- USERNAME -->
    <div class="input-box">
        <img src="../../icons/id.gif" class="left-icon">
        <input type="text" name="username" placeholder="Username" required>
    </div>
    <br>

    <!-- PASSWORD -->
    <div class="input-box">
        <img src="../../icons/password.gif" class="left-icon">

        <input type="password" name="password" id="loginPassword" placeholder="Password" required>

        <img src="../../icons/eyeclosed.png"
             class="right-icon"
             id="loginEye"
             onclick="togglePassword('loginPassword','loginEye')">
    </div>
    <br>

    <button type="submit" name="login">LOGIN</button>
</form>
<?php endif; ?>

<!-- Password Visible  -->
<script>
function togglePassword(inputId, eyeId) {
    const input = document.getElementById(inputId);
    const eye = document.getElementById(eyeId);

    if (input.type === "password") {
        input.type = "text";
        eye.src = "../../icons/eyeOpened.png";
    } else {
        input.type = "password";
        eye.src = "../../icons/eyeClosed.png";
    }
}
</script>

<!-- CONFIRM PASSWORD -->
 <script>
function togglePassword(inputId, eyeId) {
    const input = document.getElementById(inputId);
    const eye = document.getElementById(eyeId);

    if (input.type === "password") {
        input.type = "text";
        eye.src = "../../icons/eyeOpened.png";
    } else {
        input.type = "password";
        eye.src = "../../icons/eyeClosed.png";
    }
}
</script>

<!-- PASSWORD CHECKING -->
 <script>
const pass = document.getElementById("password");
const confirmPass = document.getElementById("confirm_password");
const msg = document.getElementById("passMsg");
const submitBtn = document.querySelector("button[name='signup']");

confirmPass.addEventListener("keyup", checkPassword);
pass.addEventListener("keyup", checkPassword);

function checkPassword() {
    let p1 = pass.value;
    let p2 = confirmPass.value;

    if (p2 === "") {
        msg.innerHTML = "";
        submitBtn.disabled = true;
        return;
    }

    // AJAX (fetch)
    fetch("password_check.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "password=" + encodeURIComponent(p1) +
              "&confirm=" + encodeURIComponent(p2)
    })
    .then(res => res.text())
    .then(data => {
        if (data === "match") {
            msg.style.color = "green";
            msg.innerHTML = "Passwords match";
            submitBtn.disabled = false;
        } else {
            msg.style.color = "red";
            msg.innerHTML = "Passwords do not match";
            submitBtn.disabled = true;
        }
    });
}
</script>

</body>
</html>
