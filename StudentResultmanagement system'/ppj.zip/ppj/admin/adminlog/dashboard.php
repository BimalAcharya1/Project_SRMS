<?php
session_start();
include "../Database/dbc.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location:admin.php");
    exit;
}

$id = $_SESSION['admin_id'];
$admin = $conn->query("SELECT * FROM admin WHERE admin_id='$id'")->fetch_assoc();
?>

<img src="../uploads/admin/<?php echo $admin['image']; ?>" width="80" style="border-radius:50%">
<h3>Welcome, <?php echo $admin['username']; ?></h3>
