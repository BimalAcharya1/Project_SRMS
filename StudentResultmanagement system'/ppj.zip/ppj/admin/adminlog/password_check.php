<?php
$password = $_POST['password'] ?? '';
$confirm  = $_POST['confirm'] ?? '';

if ($password === $confirm && strlen($password) >= 4) {
    echo "match";
} else {
    echo "nomatch";
}
