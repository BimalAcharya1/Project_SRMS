<?php
include "../../Database/dbc.php";

if (isset($_POST['signup'])) {

    $admin_id = $_POST['admin_id'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $college  = $_POST['college_school'];
    $address  = $_POST['address'];

    // IMAGE UPLOAD
    $imgName = $_FILES['image']['name'];
    $tmpName = $_FILES['image']['tmp_name'];
    $imgExt  = pathinfo($imgName, PATHINFO_EXTENSION);

    $newImgName = uniqid("admin_") . "." . $imgExt;
    $uploadPath = "uploads/admin/" . $newImgName;

    if (!is_dir("uploads/admin")) {
        mkdir("uploads/admin", 0777, true);
    }

    if (!move_uploaded_file($tmpName, $uploadPath)) {
        die("Image upload failed!");
    }

    $sql = "INSERT INTO admin 
            (admin_id, username, password, image, college_school, address)
            VALUES 
            ('$admin_id', '$username', '$password', '$newImgName', '$college', '$address')";

    if ($conn->query($sql)) {
        header("Location: admin.php");
        exit;
    } else {
        echo "Error creating admin!";
    }
}