<?php
session_start();
include "../../Database/dbc.php";

if (isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $admin = $result->fetch_assoc();

        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['admin_id'];
            echo "<script>
                    window.location.href = '../adminDashboard.php';
                  </script>";
            exit;
        } else {
            echo "<script>
                    alert('Invalid password!');
                    window.history.back();
                  </script>";
        }
    } else {
        echo "<script>
                alert('Admin not found!');
                window.history.back();
              </script>";
    }
}
?>
