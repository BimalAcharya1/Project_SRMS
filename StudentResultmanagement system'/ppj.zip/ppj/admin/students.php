<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Handle Add/Edit/Delete operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add') {
            $roll_number = $database->escapeString($_POST['roll_number']);
            $first_name = $database->escapeString($_POST['first_name']);
            $middle_name = $database->escapeString($_POST['middle_name']);
            $last_name = $database->escapeString($_POST['last_name']);
            $dob = $_POST['dob'];
            $gender = $_POST['gender'];
            $phone = $database->escapeString($_POST['phone']);
            $email = $database->escapeString($_POST['email']);
            $address = $database->escapeString($_POST['address']);
            $course_id = $_POST['course_id'];
            $current_semester = $_POST['current_semester'];
            $section = $database->escapeString($_POST['section']);
            
            // Validate email format
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $_SESSION['message'] = "Invalid email format! Please enter a valid email address.";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            // Check if roll number already exists
            $check_roll = $conn->query("SELECT student_id FROM Student WHERE roll_number = '$roll_number'");
            if ($check_roll->num_rows > 0) {
                $_SESSION['message'] = "Roll number already exists! Please use a different roll number.";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            // Check if email already exists
            $check_email = $conn->query("SELECT student_id FROM Student WHERE email = '$email'");
            if ($check_email->num_rows > 0) {
                $_SESSION['message'] = "Email already exists! Please use a different email.";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            // Validate phone number format (10 digits, starts with 97 or 98)
            if (!preg_match('/^(97|98)\d{8}$/', $phone)) {
                $_SESSION['message'] = "Phone number must be 10 digits and start with 97 or 98!";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            // Validate age (must be between 14 and 99 years)
            $dob_date = new DateTime($dob);
            $today = new DateTime();
            $age = $today->diff($dob_date)->y;
            
            if ($age < 14) {
                $_SESSION['message'] = "Student must be at least 14 years old!";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            if ($age > 99) {
                $_SESSION['message'] = "Age cannot be more than 99 years! Please check the date of birth.";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            // Get batch_id from course (you might want to modify this based on your logic)
            // For now, we'll set batch_id as NULL or you can add a batch selection if needed
            $batch_id = 'NULL';
            
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Insert student
                $sql = "INSERT INTO Student (roll_number, first_name, middle_name, last_name, dob, gender, 
                        phone, email, address, course_id, batch_id, current_semester, section) 
                        VALUES ('$roll_number', '$first_name', '$middle_name', '$last_name', '$dob', '$gender',
                        '$phone', '$email', '$address', $course_id, $batch_id, $current_semester, '$section')";
                
                if (!$conn->query($sql)) {
                    throw new Exception("Error inserting student: " . $conn->error);
                }
                
                $student_id = $conn->insert_id;
                
                // Insert compulsory subjects for this semester
                $compulsory_sql = "INSERT INTO student_subjects (student_id, subject_id, subject_type, semester)
                                  SELECT $student_id, subject_id, 'compulsory', $current_semester
                                  FROM Subject 
                                  WHERE course_id = $course_id 
                                  AND semester_number = $current_semester 
                                  AND subject_type = 'Compulsory'";
                
                if (!$conn->query($compulsory_sql)) {
                    throw new Exception("Error inserting compulsory subjects: " . $conn->error);
                }
                
                // Insert selected optional/elective subjects
                if (isset($_POST['optional_subjects']) && is_array($_POST['optional_subjects'])) {
                    foreach ($_POST['optional_subjects'] as $subject_id) {
                        // Get subject type
                        $type_result = $conn->query("SELECT subject_type FROM Subject WHERE subject_id = $subject_id");
                        $type_row = $type_result->fetch_assoc();
                        $subject_type = strtolower($type_row['subject_type']);
                        
                        $optional_sql = "INSERT INTO student_subjects (student_id, subject_id, subject_type, semester)
                                        VALUES ($student_id, $subject_id, '$subject_type', $current_semester)";
                        
                        if (!$conn->query($optional_sql)) {
                            throw new Exception("Error inserting optional subject: " . $conn->error);
                        }
                    }
                }
                
                $conn->commit();
                $_SESSION['message'] = "Student added successfully with subjects!";
                $_SESSION['msg_type'] = "success";
                
            } catch (Exception $e) {
                $conn->rollback();
                $_SESSION['message'] = "Error: " . $e->getMessage();
                $_SESSION['msg_type'] = "error";
            }
        }
        
        elseif ($action == 'edit') {
            $student_id = $_POST['student_id'];
            $roll_number = $database->escapeString($_POST['roll_number']);
            $first_name = $database->escapeString($_POST['first_name']);
            $middle_name = $database->escapeString($_POST['middle_name']);
            $last_name = $database->escapeString($_POST['last_name']);
            $dob = $_POST['dob'];
            $gender = $_POST['gender'];
            $phone = $database->escapeString($_POST['phone']);
            $email = $database->escapeString($_POST['email']);
            $address = $database->escapeString($_POST['address']);
            $course_id = $_POST['course_id'];
            $current_semester = $_POST['current_semester'];
            $section = $database->escapeString($_POST['section']);
            
            // Validate email format
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $_SESSION['message'] = "Invalid email format! Please enter a valid email address.";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            // Check if roll number already exists for another student
            $check_roll = $conn->query("SELECT student_id FROM Student WHERE roll_number = '$roll_number' AND student_id != $student_id");
            if ($check_roll->num_rows > 0) {
                $_SESSION['message'] = "Roll number already exists! Please use a different roll number.";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            // Check if email already exists for another student
            $check_email = $conn->query("SELECT student_id FROM Student WHERE email = '$email' AND student_id != $student_id");
            if ($check_email->num_rows > 0) {
                $_SESSION['message'] = "Email already exists! Please use a different email.";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            // Validate phone number format (10 digits, starts with 97 or 98)
            if (!preg_match('/^(97|98)\d{8}$/', $phone)) {
                $_SESSION['message'] = "Phone number must be 10 digits and start with 97 or 98!";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            // Validate age (must be between 14 and 99 years)
            $dob_date = new DateTime($dob);
            $today = new DateTime();
            $age = $today->diff($dob_date)->y;
            
            if ($age < 14) {
                $_SESSION['message'] = "Student must be at least 14 years old!";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            if ($age > 99) {
                $_SESSION['message'] = "Age cannot be more than 99 years! Please check the date of birth.";
                $_SESSION['msg_type'] = "error";
                header("Location: students.php");
                exit();
            }
            
            // Keep existing batch_id or set to NULL
            $batch_id = 'NULL';
            
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Update student
                $sql = "UPDATE Student SET roll_number='$roll_number', first_name='$first_name', 
                        middle_name='$middle_name', last_name='$last_name', dob='$dob', gender='$gender',
                        phone='$phone', email='$email', address='$address', course_id=$course_id, 
                        batch_id=$batch_id, current_semester=$current_semester, section='$section' 
                        WHERE student_id=$student_id";
                
                if (!$conn->query($sql)) {
                    throw new Exception("Error updating student: " . $conn->error);
                }
                
                // Delete existing subject selections for this semester
                $delete_sql = "DELETE FROM student_subjects WHERE student_id = $student_id AND semester = $current_semester";
                if (!$conn->query($delete_sql)) {
                    throw new Exception("Error updating subjects: " . $conn->error);
                }
                
                // Insert compulsory subjects for this semester
                $compulsory_sql = "INSERT INTO student_subjects (student_id, subject_id, subject_type, semester)
                                  SELECT $student_id, subject_id, 'compulsory', $current_semester
                                  FROM Subject 
                                  WHERE course_id = $course_id 
                                  AND semester_number = $current_semester 
                                  AND subject_type = 'Compulsory'";
                
                if (!$conn->query($compulsory_sql)) {
                    throw new Exception("Error inserting compulsory subjects: " . $conn->error);
                }
                
                // Insert selected optional/elective subjects
                if (isset($_POST['optional_subjects']) && is_array($_POST['optional_subjects'])) {
                    foreach ($_POST['optional_subjects'] as $subject_id) {
                        // Get subject type
                        $type_result = $conn->query("SELECT subject_type FROM Subject WHERE subject_id = $subject_id");
                        $type_row = $type_result->fetch_assoc();
                        $subject_type = strtolower($type_row['subject_type']);
                        
                        $optional_sql = "INSERT INTO student_subjects (student_id, subject_id, subject_type, semester)
                                        VALUES ($student_id, $subject_id, '$subject_type', $current_semester)";
                        
                        if (!$conn->query($optional_sql)) {
                            throw new Exception("Error inserting optional subject: " . $conn->error);
                        }
                    }
                }
                
                $conn->commit();
                $_SESSION['message'] = "Student updated successfully with subjects!";
                $_SESSION['msg_type'] = "success";
                
            } catch (Exception $e) {
                $conn->rollback();
                $_SESSION['message'] = "Error: " . $e->getMessage();
                $_SESSION['msg_type'] = "error";
            }
        }
        
      elseif ($action == 'delete') {
    $student_id = $_POST['student_id'];
    
    // Simple delete - cascade will handle subjects and results
    $sql = "DELETE FROM Student WHERE student_id=$student_id";
    
    if ($conn->query($sql)) {
        $_SESSION['message'] = "Student deleted successfully! All associated results and subject enrollments have been removed.";
        $_SESSION['msg_type'] = "success";
    } else {
        $_SESSION['message'] = "Error: " . $conn->error;
        $_SESSION['msg_type'] = "error";
    }
}
        
        header("Location: students.php");
        exit();
    }
}

// Handle AJAX validation requests
if (isset($_GET['ajax']) && $_GET['ajax'] == 'validate') {
    $field = $_GET['field'];
    $value = $database->escapeString($_GET['value']);
    $current_id = isset($_GET['current_id']) ? intval($_GET['current_id']) : 0;
    
    $response = ['valid' => true, 'message' => ''];
    
    if ($field == 'roll_number') {
        $query = "SELECT student_id FROM Student WHERE roll_number = '$value'";
        if ($current_id > 0) {
            $query .= " AND student_id != $current_id";
        }
        $result = $conn->query($query);
        if ($result->num_rows > 0) {
            $response['valid'] = false;
            $response['message'] = 'Roll number already exists';
        }
    }
    elseif ($field == 'email') {
        // Validate email format
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $response['valid'] = false;
            $response['message'] = 'Invalid email format';
        } else {
            $query = "SELECT student_id FROM Student WHERE email = '$value'";
            if ($current_id > 0) {
                $query .= " AND student_id != $current_id";
            }
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                $response['valid'] = false;
                $response['message'] = 'Email already registered';
            }
        }
    }
    elseif ($field == 'phone') {
        // Validate phone format: 10 digits, starts with 97 or 98
        if (!preg_match('/^(97|98)\d{8}$/', $value)) {
            $response['valid'] = false;
            $response['message'] = 'Phone must be 10 digits starting with 97 or 98';
        }
    }
    elseif ($field == 'dob') {
        // Validate age (between 14 and 99)
        $dob_date = new DateTime($value);
        $today = new DateTime();
        $age = $today->diff($dob_date)->y;
        
        if ($age < 14) {
            $response['valid'] = false;
            $response['message'] = 'Student must be at least 14 years old';
        } elseif ($age > 99) {
            $response['valid'] = false;
            $response['message'] = 'Age cannot be more than 99 years';
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Handle AJAX request to load subjects
if (isset($_GET['ajax']) && $_GET['ajax'] == 'load_subjects') {
    $course_id = intval($_GET['course_id']);
    $semester = intval($_GET['semester']);
    $student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
    
    // Get all subjects for this course and semester
    $subjects_query = "SELECT * FROM Subject WHERE course_id = $course_id AND semester_number = $semester ORDER BY subject_type, subject_name";
    $subjects = $conn->query($subjects_query);
    
    // Get student's selected optional subjects if editing
    $selected_subjects = [];
    if ($student_id > 0) {
        $selected_query = "SELECT subject_id FROM student_subjects WHERE student_id = $student_id AND semester = $semester AND subject_type IN ('optional', 'elective')";
        $selected_result = $conn->query($selected_query);
        while ($row = $selected_result->fetch_assoc()) {
            $selected_subjects[] = $row['subject_id'];
        }
    }
    
    $html = '';
    $compulsory_count = 0;
    $optional_count = 0;
    
    while ($subject = $subjects->fetch_assoc()) {
        if ($subject['subject_type'] == 'Compulsory') {
            $compulsory_count++;
            $html .= '<div class="subject-item compulsory-item">';
            $html .= '<input type="checkbox" checked disabled>';
            $html .= '<div class="subject-info">';
            $html .= '<span class="subject-name">' . htmlspecialchars($subject['subject_name']) . '</span>';
            $html .= '<span class="subject-code"> (' . $subject['subject_code'] . ')</span>';
            $html .= '<span class="subject-type type-compulsory">Compulsory</span>';
            $html .= '</div></div>';
        } else {
            $checked = in_array($subject['subject_id'], $selected_subjects) ? 'checked' : '';
            $type_class = $subject['subject_type'] == 'Optional' ? 'type-optional' : 'type-elective';
            
            $html .= '<div class="subject-item optional-item">';
            $html .= '<input type="checkbox" name="optional_subjects[]" value="' . $subject['subject_id'] . '" ' . $checked . ' onchange="updateOptionalCount(\'' . ($student_id ? 'edit' : 'add') . '\')">';
            $html .= '<div class="subject-info">';
            $html .= '<span class="subject-name">' . htmlspecialchars($subject['subject_name']) . '</span>';
            $html .= '<span class="subject-code"> (' . $subject['subject_code'] . ')</span>';
            $html .= '<span class="subject-type ' . $type_class . '">' . $subject['subject_type'] . '</span>';
            $html .= '</div></div>';
            
            $optional_count++;
        }
    }
    
    if ($compulsory_count == 0 && $optional_count == 0) {
        $html = '<div class="no-subjects">No subjects found for this semester</div>';
    }
    
    echo json_encode([
        'html' => $html,
        'compulsory_count' => $compulsory_count,
        'optional_count' => $optional_count
    ]);
    exit();
}

// Handle AJAX request to get student details
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_student_details') {
    $student_id = intval($_GET['student_id']);
    
    $query = "SELECT s.*, c.course_name, d.dept_name, 
                     (SELECT COUNT(*) FROM result WHERE student_id = s.student_id) as result_count,
                     (SELECT COUNT(*) FROM student_subjects WHERE student_id = s.student_id) as enrolled_subjects
              FROM Student s
              LEFT JOIN Course c ON s.course_id = c.course_id
              LEFT JOIN Department d ON c.dept_id = d.dept_id
              WHERE s.student_id = $student_id";
    
    $result = $conn->query($query);
    
    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
        
        // Calculate age
        $dob = new DateTime($student['dob']);
        $today = new DateTime();
        $age = $today->diff($dob)->y;
        $student['age'] = $age;
        
        // Get enrolled subjects with details
        $subjects_query = "SELECT ss.*, sub.subject_name, sub.subject_code, sub.subject_type as sub_type
                          FROM student_subjects ss
                          JOIN Subject sub ON ss.subject_id = sub.subject_id
                          WHERE ss.student_id = $student_id
                          ORDER BY ss.semester, ss.subject_type";
        
        $subjects_result = $conn->query($subjects_query);
        $subjects = [];
        while ($subject = $subjects_result->fetch_assoc()) {
            $subjects[] = $subject;
        }
        $student['subjects'] = $subjects;
        
        // Get recent results
        $results_query = "SELECT r.*, sub.subject_name, sub.subject_code, e.exam_name, e.exam_type
                         FROM result r
                         JOIN Subject sub ON r.subject_id = sub.subject_id
                         JOIN exam e ON r.exam_id = e.exam_id
                         WHERE r.student_id = $student_id
                         ORDER BY r.result_id DESC
                         LIMIT 10";
        
        $results_result = $conn->query($results_query);
        $results = [];
        while ($result_row = $results_result->fetch_assoc()) {
            $results[] = $result_row;
        }
        $student['recent_results'] = $results;
        
        echo json_encode(['success' => true, 'student' => $student]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Student not found']);
    }
    exit();
}

// Handle department filter
$dept_filter = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;
$course_filter = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$semester_filter = isset($_GET['semester']) ? intval($_GET['semester']) : 0;

// Get all students with related info and filters
$student_query = "
    SELECT s.*, c.course_name, d.dept_name, d.dept_id,
           (SELECT COUNT(*) FROM student_subjects WHERE student_id = s.student_id) as subject_count
    FROM Student s
    LEFT JOIN Course c ON s.course_id = c.course_id
    LEFT JOIN Department d ON c.dept_id = d.dept_id
    WHERE 1=1
";

if ($dept_filter > 0) {
    $student_query .= " AND c.dept_id = $dept_filter";
}

if ($course_filter > 0) {
    $student_query .= " AND s.course_id = $course_filter";
}

if ($semester_filter > 0) {
    $student_query .= " AND s.current_semester = $semester_filter";
}

$student_query .= " ORDER BY s.student_id DESC";
$students = $conn->query($student_query);

// Get departments for filter dropdown
$departments = $conn->query("SELECT * FROM Department ORDER BY dept_name");

// Get courses based on selected department for filter dropdown
$course_filter_query = "SELECT c.*, d.dept_name FROM Course c LEFT JOIN Department d ON c.dept_id = d.dept_id";
if ($dept_filter > 0) {
    $course_filter_query .= " WHERE c.dept_id = $dept_filter";
}
$course_filter_query .= " ORDER BY c.course_name";
$filter_courses = $conn->query($course_filter_query);

// Get all courses for forms
$all_courses = $conn->query("SELECT c.*, d.dept_name FROM Course c LEFT JOIN Department d ON c.dept_id = d.dept_id ORDER BY d.dept_name, c.course_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Manage Students - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Additional styles for validation and subject selection */
        .validation-message {
            font-size: 12px;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .validation-success {
            color: #28a745;
        }
        .validation-error {
            color: #dc3545;
        }
        .validation-spinner {
            display: inline-block;
            width: 12px;
            height: 12px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 5px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .input-error {
            border-color: #dc3545 !important;
        }
        .input-success {
            border-color: #28a745 !important;
        }
        .form-group {
            position: relative;
            margin-bottom: 15px;
        }
        .required-field::after {
            content: " *";
            color: red;
        }
        .phone-hint, .age-hint {
            font-size: 11px;
            color: #666;
            margin-top: 3px;
        }
        
        /* Subject selection styles */
        .subjects-section {
            grid-column: span 2;
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }
        
        .subjects-section h3 {
            margin-bottom: 15px;
            color: #333;
            font-size: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .subjects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 10px;
            max-height: 350px;
            overflow-y: auto;
            padding: 10px;
            background: white;
            border-radius: 6px;
        }
        
        .subject-item {
            display: flex;
            align-items: center;
            padding: 10px;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            transition: all 0.3s;
        }
        
        .subject-item:hover {
            background: #f0f4ff;
            border-color: #667eea;
        }
        
        .compulsory-item {
            background: #e8f4fd;
            border-color: #007bff;
        }
        
        .optional-item {
            background: white;
        }
        
        .subject-item input[type="checkbox"] {
            margin-right: 12px;
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .subject-item input[type="checkbox"]:disabled {
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .subject-info {
            flex: 1;
        }
        
        .subject-name {
            font-weight: 600;
            color: #333;
        }
        
        .subject-code {
            font-size: 11px;
            color: #666;
            margin-left: 5px;
        }
        
        .subject-type {
            font-size: 10px;
            padding: 2px 8px;
            border-radius: 12px;
            margin-left: 8px;
            display: inline-block;
        }
        
        .type-compulsory {
            background: #007bff;
            color: white;
        }
        
        .type-optional {
            background: #28a745;
            color: white;
        }
        
        .type-elective {
            background: #ffc107;
            color: black;
        }
        
        .no-subjects {
            grid-column: span 2;
            text-align: center;
            padding: 30px;
            color: #666;
            font-style: italic;
        }
        
        .subject-summary {
            margin-top: 10px;
            font-size: 13px;
            color: #666;
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .summary-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .summary-badge {
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-compulsory {
            background: #007bff;
            color: white;
        }
        
        .badge-optional {
            background: #28a745;
            color: white;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .form-group label {
            font-weight: 600;
            margin-bottom: 5px;
            display: block;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        /* Modal display fix */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 30px auto;
            padding: 20px;
            border: 1px solid #888;
            border-radius: 10px;
            width: 90%;
            max-width: 900px;
            max-height: 85vh;
            overflow-y: auto;
            position: relative;
            animation: modalSlideDown 0.3s ease-out;
        }
        
        @keyframes modalSlideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            position: sticky;
            top: 0;
            z-index: 1;
        }
        
        .close:hover,
        .close:focus {
            color: #333;
            text-decoration: none;
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .card-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .card-header > div {
                width: 100%;
            }
            #dept_filter, #course_filter, #semester_filter {
                width: 100%;
            }
        }

        /* View Details Modal Styles */
        .details-container {
            padding: 10px;
        }
        
        .details-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .student-avatar {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 40px;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .student-title h3 {
            font-size: 24px;
            margin-bottom: 5px;
            color: #333;
        }
        
        .student-title p {
            color: #666;
            font-size: 16px;
        }
        
        .details-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .detail-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }
        
        .detail-label {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
        }
        
        .detail-value {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        
        .detail-value small {
            font-size: 14px;
            font-weight: normal;
            color: #666;
            margin-left: 5px;
        }
        
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success {
            background: #d4edda;
            color: #155724;
        }
        
        .badge-info {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        .badge-warning {
            background: #fff3cd;
            color: #856404;
        }
        
        .subjects-table, .results-table {
            margin-top: 30px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .subjects-table h4, .results-table h4 {
            background: #f8f9fa;
            padding: 15px;
            margin: 0;
            border-bottom: 1px solid #e0e0e0;
            font-size: 16px;
        }
        
        .table-mini {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table-mini th {
            background: #f8f9fa;
            padding: 10px;
            text-align: left;
            font-size: 13px;
            font-weight: 600;
            color: #666;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .table-mini td {
            padding: 10px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 14px;
        }
        
        .table-mini tr:last-child td {
            border-bottom: none;
        }
        
        .grade-badge {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .grade-A {
            background: #d4edda;
            color: #155724;
        }
        
        .grade-B {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        .grade-C {
            background: #fff3cd;
            color: #856404;
        }
        
        .grade-D {
            background: #f8d7da;
            color: #721c24;
        }
        
        .grade-F {
            background: #f8d7da;
            color: #721c24;
        }
        
        .tab-container {
            margin-top: 20px;
        }
        
        .tabs {
            display: flex;
            gap: 10px;
            border-bottom: 1px solid #e0e0e0;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .tab {
            padding: 8px 20px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 14px;
            color: #666;
            border-radius: 20px;
            transition: all 0.3s;
        }
        
        .tab:hover {
            background: #f0f0f0;
        }
        
        .tab.active {
            background: #667eea;
            color: white;
        }
        
        .tab-pane {
            display: none;
        }
        
        .tab-pane.active {
            display: block;
        }
        
        .info-card {
            background: #fff;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .info-row {
            display: flex;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .info-row:last-child {
            border-bottom: none;
        }
        
        .info-label {
            width: 150px;
            font-weight: 600;
            color: #666;
        }
        
        .info-value {
            flex: 1;
            color: #333;
        }
        
        .action-btn {
            background: none;
            border: none;
            cursor: pointer;
            padding: 5px;
            margin: 0 2px;
            border-radius: 4px;
            transition: all 0.3s;
        }
        
        .action-btn:hover {
            background: #f0f0f0;
        }
        
        .view-btn:hover {
            background: #e3f2fd;
        }
        
        .edit-btn:hover {
            background: #fff3e0;
        }
        
        .delete-btn:hover {
            background: #ffebee;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                   <a href="adminDashboard.php">
            <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
            </a>
               <a href="departments.php">
            <img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5>
            </a>
                <a href="courses.php">
            <img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5>
            </a>
                  <a href="subjects.php">
            <img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5>
        </a>

        <a href="teachers.php">
            <img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5>
        </a>

         <a href="students.php" class="active">
            <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5>
        </a>
           
        <a href="allocations.php">
            <img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5>
        </a>
        <a href="exams.php">
            <img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5>
        </a>
        <a href="results.php">
            <img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5>
        </a>

        <a href="feedbacks.php">
            <img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5>
        </a>
        <a href="settings.php">
            <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5>
        </a>
        <a href="../logout.php">
            <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5>
        </a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2> <img src="../icons/student.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Manage Students</h2>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <!-- Department Filter Dropdown -->
                        <select id="dept_filter" onchange="filterByDepartment()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 200px;">
                            <option value="0">All Departments</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                                $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $dept['dept_name']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        
                        <!-- Course Filter Dropdown -->
                        <select id="course_filter" onchange="filterByCourse()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 250px;" <?php echo $dept_filter == 0 ? 'disabled' : ''; ?>>
                            <option value="0">All Courses</option>
                            <?php 
                            if($dept_filter > 0):
                                $filter_courses->data_seek(0);
                                while($course = $filter_courses->fetch_assoc()): 
                                    $selected = ($course_filter == $course['course_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $course['course_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $course['course_name']; ?>
                            </option>
                            <?php 
                                endwhile;
                            endif; 
                            ?>
                        </select>
                        
                        <!-- Semester Filter Dropdown -->
                        <select id="semester_filter" onchange="filterBySemester()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 150px;">
                            <option value="0">All Semesters</option>
                            <?php for($i = 1; $i <= 8; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo ($semester_filter == $i) ? 'selected' : ''; ?>>
                                    Semester <?php echo $i; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                        
                        <!-- Clear Filters Button -->
                        <?php if($dept_filter > 0 || $course_filter > 0 || $semester_filter > 0): ?>
                        <button class="btn btn-secondary" onclick="clearFilters()">Clear Filters</button>
                        <?php endif; ?>
                        
                        <button class="btn" onclick="document.getElementById('addModal').style.display='block'">Add New Student <img src="../icons/Add.png" style="height: 27px; vertical-align: middle; margin-right: 10px;"></button>
                    </div>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Roll No</th>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Course</th>
                            <th>Semester</th>
                            <th>Section</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Subjects</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
    <?php if($students->num_rows > 0): ?>
        <?php while($row = $students->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['student_id']; ?></td>
            <td><strong><?php echo $row['roll_number']; ?></strong></td>
            <td><?php echo $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name']; ?></td>
            <td>
                <?php if($row['dept_id']): ?>
                    <a href="?dept_id=<?php echo $row['dept_id']; ?>" style="text-decoration: none; color: inherit;">
                        <?php echo $row['dept_name'] ?? 'N/A'; ?>
                    </a>
                <?php else: ?>
                    <?php echo 'N/A'; ?>
                <?php endif; ?>
            </td>
            <td>
                <?php if($row['course_id']): ?>
                    <a href="?dept_id=<?php echo $row['dept_id']; ?>&course_id=<?php echo $row['course_id']; ?>" style="text-decoration: none; color: inherit;">
                        <?php echo $row['course_name'] ?? 'N/A'; ?>
                    </a>
                <?php else: ?>
                    <?php echo 'N/A'; ?>
                <?php endif; ?>
            </td>
            <td>
                <a href="?<?php echo $dept_filter > 0 ? 'dept_id='.$dept_filter.'&' : ''; ?><?php echo $course_filter > 0 ? 'course_id='.$course_filter.'&' : ''; ?>semester=<?php echo $row['current_semester']; ?>" style="text-decoration: none; color: inherit;">
                    Semester <?php echo $row['current_semester']; ?>
                </a>
            </td>
            <td><?php echo $row['section']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['phone']; ?></td>
            <td>
                <span class="badge badge-info"><?php echo $row['subject_count']; ?> Subjects</span>
            </td>
            <td>
                <button class="action-btn view-btn" onclick="viewStudent(<?php echo $row['student_id']; ?>)" title="View Details">
                    <img src="../icons/search.png" style="height: 22px; vertical-align: middle;">
                </button>
                <button class="action-btn edit-btn" onclick="editStudent(<?php echo htmlspecialchars(json_encode($row)); ?>)" title="Edit">
                    <img src="../icons/Edit.png" style="height: 22px; vertical-align: middle;">
                </button>
                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure? Deleting this student will also remove all their results and history.')">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                    <button type="submit" class="action-btn delete-btn" title="Delete">
                        <img src="../icons/Delete.png" style="height: 22px; vertical-align: middle;">
                    </button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="11" style="text-align: center; padding: 20px;">
                No students found
                <?php if($dept_filter > 0 || $course_filter > 0 || $semester_filter > 0): ?>
                    with the selected filters. <a href="students.php">View all students</a>
                <?php endif; ?>
            </td>
        </tr>
    <?php endif; ?>
</tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="document.getElementById('addModal').style.display='none'">&times;</span>
            <h2>Add New Student</h2>
            <form method="POST" id="addForm" onsubmit="return validateAddForm()">
                <input type="hidden" name="action" value="add">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label class="required-field">Roll Number</label>
                        <input type="text" name="roll_number" id="add_roll_number" placeholder="e.g., 2024001" required onkeyup="validateField('add', 'roll_number', this.value)">
                        <div id="add_roll_number_validation" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">First Name</label>
                        <input type="text" name="first_name" id="add_first_name" placeholder="First name" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Middle Name</label>
                        <input type="text" name="middle_name" placeholder="Middle name (optional)">
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Last Name</label>
                        <input type="text" name="last_name" placeholder="Last name" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Date of Birth</label>
                        <input type="date" name="dob" id="add_dob" required onchange="validateField('add', 'dob', this.value)">
                        <div id="add_dob_validation" class="validation-message"></div>
                        <div class="age-hint">Student must be between 14 and 99 years old</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Gender</label>
                        <select name="gender" required>
                            <option value="">Select Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Phone</label>
                        <input type="text" name="phone" id="add_phone" placeholder="e.g., 9812345678" required onkeyup="validateField('add', 'phone', this.value)">
                        <div id="add_phone_validation" class="validation-message"></div>
                        <div class="phone-hint">Must be 10 digits starting with 97 or 98</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Email</label>
                        <input type="email" name="email" id="add_email" placeholder="student@example.com" required onkeyup="validateField('add', 'email', this.value)">
                        <div id="add_email_validation" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group" style="grid-column: span 2;">
                        <label class="required-field">Address</label>
                        <textarea name="address" rows="2" placeholder="Full address" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Department</label>
                        <select id="add_dept_filter" onchange="filterCoursesByDepartment('add')" required>
                            <option value="">Select Department First</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                                $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $dept['dept_name']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Course</label>
                        <select name="course_id" id="add_course_id" onchange="updateSemesterOptions('add'); loadSubjects('add')" required disabled>
                            <option value="">Select Department First</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Current Semester</label>
                        <select name="current_semester" id="add_semester_number" onchange="loadSubjects('add')" required disabled>
                            <option value="">Select Course First</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Section</label>
                        <input type="text" name="section" placeholder="e.g., A, B, C" maxlength="10" required>
                    </div>
                    
                    <!-- Subject Selection Section -->
                    <div class="subjects-section">
                        <h3>
                            Subject Selection
                            <span id="add_subject_summary" class="subject-summary"></span>
                        </h3>
                        <div id="add_subjects_grid" class="subjects-grid">
                            <div class="no-subjects">Select course and semester to view subjects</div>
                        </div>
                        <div id="add_loading" class="validation-spinner" style="display: none; margin: 10px auto;"></div>
                    </div>
                </div>
                
                <div style="margin-top: 20px; text-align: right;">
                    <button type="submit" class="btn" id="add_submit_btn">Add Student <img src="../icons/Add.png" style="height: 20px; vertical-align: middle; margin-left: 5px;"></button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="document.getElementById('editModal').style.display='none'">&times;</span>
            <h2>Edit Student</h2>
            <form method="POST" id="editForm" onsubmit="return validateEditForm()">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="student_id" id="edit_student_id">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label class="required-field">Roll Number</label>
                        <input type="text" name="roll_number" id="edit_roll_number" required onkeyup="validateField('edit', 'roll_number', this.value, document.getElementById('edit_student_id').value)">
                        <div id="edit_roll_number_validation" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">First Name</label>
                        <input type="text" name="first_name" id="edit_first_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Middle Name</label>
                        <input type="text" name="middle_name" id="edit_middle_name">
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Last Name</label>
                        <input type="text" name="last_name" id="edit_last_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Date of Birth</label>
                        <input type="date" name="dob" id="edit_dob" required onchange="validateField('edit', 'dob', this.value)">
                        <div id="edit_dob_validation" class="validation-message"></div>
                        <div class="age-hint">Student must be between 14 and 99 years old</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Gender</label>
                        <select name="gender" id="edit_gender" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Phone</label>
                        <input type="text" name="phone" id="edit_phone" required onkeyup="validateField('edit', 'phone', this.value)">
                        <div id="edit_phone_validation" class="validation-message"></div>
                        <div class="phone-hint">Must be 10 digits starting with 97 or 98</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Email</label>
                        <input type="email" name="email" id="edit_email" required onkeyup="validateField('edit', 'email', this.value, document.getElementById('edit_student_id').value)">
                        <div id="edit_email_validation" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group" style="grid-column: span 2;">
                        <label class="required-field">Address</label>
                        <textarea name="address" id="edit_address" rows="2" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Department</label>
                        <select id="edit_dept_filter" onchange="filterCoursesByDepartment('edit')" required>
                            <option value="">Select Department</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>"><?php echo $dept['dept_name']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Course</label>
                        <select name="course_id" id="edit_course_id" onchange="updateSemesterOptions('edit'); loadSubjects('edit')" required disabled>
                            <option value="">Select Department First</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Current Semester</label>
                        <select name="current_semester" id="edit_semester_number" onchange="loadSubjects('edit')" required disabled>
                            <option value="">Select Course First</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Section</label>
                        <input type="text" name="section" id="edit_section" maxlength="10" required>
                    </div>
                    
                    <!-- Subject Selection Section for Edit -->
                    <div class="subjects-section">
                        <h3>
                            Subject Selection
                            <span id="edit_subject_summary" class="subject-summary"></span>
                        </h3>
                        <div id="edit_subjects_grid" class="subjects-grid">
                            <div class="no-subjects">Select course and semester to view subjects</div>
                        </div>
                        <div id="edit_loading" class="validation-spinner" style="display: none; margin: 10px auto;"></div>
                    </div>
                </div>
                
                <div style="margin-top: 20px; text-align: right;">
                    <button type="submit" class="btn" id="edit_submit_btn">Update Student <img src="../icons/Edit.png" style="height: 20px; vertical-align: middle; margin-left: 5px;"></button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- View Details Modal -->
    <div id="viewModal" class="modal">
        <div class="modal-content" style="max-width: 1000px;">
            <span class="close" onclick="document.getElementById('viewModal').style.display='none'">&times;</span>
            <div id="viewLoading" style="text-align: center; padding: 50px;">
                <div class="validation-spinner" style="width: 30px; height: 30px; margin: 0 auto;"></div>
                <p style="margin-top: 20px; color: #666;">Loading student details...</p>
            </div>
            <div id="viewContent" style="display: none;">
                <!-- Content will be loaded dynamically -->
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
    // Store courses data for filtering
    var allCourses = [];
    
    <?php 
    $all_courses->data_seek(0);
    while($course = $all_courses->fetch_assoc()): 
    ?>
    allCourses.push({
        id: <?php echo $course['course_id']; ?>,
        name: '<?php echo addslashes($course['course_name']); ?>',
        dept_id: <?php echo $course['dept_id'] ?? 'null'; ?>,
        total_semesters: <?php echo $course['total_semesters']; ?>
    });
    <?php endwhile; ?>
    
    // Validation variables
    let validationTimeouts = {};
    let validationState = {
        add: { roll_number: true, email: true, phone: true, dob: true },
        edit: { roll_number: true, email: true, phone: true, dob: true }
    };
    
    function filterByDepartment() {
        var deptId = document.getElementById('dept_filter').value;
        var url = 'students.php';
        var params = [];
        
        if (deptId > 0) {
            params.push('dept_id=' + deptId);
        }
        
        <?php if($course_filter > 0): ?>
        params.push('course_id=<?php echo $course_filter; ?>');
        <?php endif; ?>
        
        <?php if($semester_filter > 0): ?>
        params.push('semester=<?php echo $semester_filter; ?>');
        <?php endif; ?>
        
        if (params.length > 0) {
            url += '?' + params.join('&');
        }
        
        window.location.href = url;
    }
    
    function filterByCourse() {
        var deptId = document.getElementById('dept_filter').value;
        var courseId = document.getElementById('course_filter').value;
        var url = 'students.php';
        var params = [];
        
        if (deptId > 0) {
            params.push('dept_id=' + deptId);
        }
        if (courseId > 0) {
            params.push('course_id=' + courseId);
        }
        
        <?php if($semester_filter > 0): ?>
        params.push('semester=<?php echo $semester_filter; ?>');
        <?php endif; ?>
        
        if (params.length > 0) {
            url += '?' + params.join('&');
        }
        
        window.location.href = url;
    }
    
    function filterBySemester() {
        var semester = document.getElementById('semester_filter').value;
        var url = 'students.php';
        var params = [];
        
        <?php if($dept_filter > 0): ?>
        params.push('dept_id=<?php echo $dept_filter; ?>');
        <?php endif; ?>
        
        <?php if($course_filter > 0): ?>
        params.push('course_id=<?php echo $course_filter; ?>');
        <?php endif; ?>
        
        if (semester > 0) {
            params.push('semester=' + semester);
        }
        
        if (params.length > 0) {
            url += '?' + params.join('&');
        }
        
        window.location.href = url;
    }
    
    function clearFilters() {
        window.location.href = 'students.php';
    }
    
    function filterCoursesByDepartment(modal) {
        var deptSelect = document.getElementById(modal + '_dept_filter');
        var courseSelect = document.getElementById(modal + '_course_id');
        var semesterSelect = document.getElementById(modal + '_semester_number');
        var subjectsGrid = document.getElementById(modal + '_subjects_grid');
        var deptId = deptSelect.value;
        
        // Clear current options
        courseSelect.innerHTML = '<option value="">Select Course</option>';
        semesterSelect.innerHTML = '<option value="">Select Course First</option>';
        semesterSelect.disabled = true;
        subjectsGrid.innerHTML = '<div class="no-subjects">Select course and semester to view subjects</div>';
        
        if (deptId) {
            // Filter courses by department
            var filteredCourses = allCourses.filter(function(course) {
                return course.dept_id == deptId;
            });
            
            if (filteredCourses.length > 0) {
                filteredCourses.forEach(function(course) {
                    var option = document.createElement('option');
                    option.value = course.id;
                    option.text = course.name;
                    option.setAttribute('data-semesters', course.total_semesters);
                    courseSelect.appendChild(option);
                });
                courseSelect.disabled = false;
            } else {
                courseSelect.innerHTML = '<option value="">No courses in this department</option>';
                courseSelect.disabled = true;
            }
        } else {
            courseSelect.innerHTML = '<option value="">Select Department First</option>';
            courseSelect.disabled = true;
        }
    }
    
    function updateSemesterOptions(modal) {
        var courseSelect = document.getElementById(modal + '_course_id');
        var semesterSelect = document.getElementById(modal + '_semester_number');
        var selectedOption = courseSelect.options[courseSelect.selectedIndex];
        
        if (selectedOption && selectedOption.value) {
            var totalSemesters = selectedOption.getAttribute('data-semesters');
            semesterSelect.innerHTML = '<option value="">Select Semester</option>';
            
            for (var i = 1; i <= totalSemesters; i++) {
                var option = document.createElement('option');
                option.value = i;
                option.text = 'Semester ' + i;
                semesterSelect.appendChild(option);
            }
            semesterSelect.disabled = false;
        } else {
            semesterSelect.innerHTML = '<option value="">Select Course First</option>';
            semesterSelect.disabled = true;
        }
    }
    
    function loadSubjects(modal) {
        var courseId = document.getElementById(modal + '_course_id').value;
        var semester = document.getElementById(modal + '_semester_number').value;
        var subjectsGrid = document.getElementById(modal + '_subjects_grid');
        var loading = document.getElementById(modal + '_loading');
        var studentId = modal === 'edit' ? document.getElementById('edit_student_id').value : 0;
        
        if (courseId && semester) {
            loading.style.display = 'inline-block';
            subjectsGrid.innerHTML = '<div class="no-subjects">Loading subjects...</div>';
            
            fetch(`students.php?ajax=load_subjects&course_id=${courseId}&semester=${semester}&student_id=${studentId}`)
                .then(response => response.json())
                .then(data => {
                    loading.style.display = 'none';
                    subjectsGrid.innerHTML = data.html;
                    
                    // Update summary
                    var summary = document.getElementById(modal + '_subject_summary');
                    if (data.compulsory_count > 0 || data.optional_count > 0) {
                        summary.innerHTML = `
                            <span class="summary-item">
                                <span class="summary-badge badge-compulsory">${data.compulsory_count} Compulsory</span>
                            </span>
                            <span class="summary-item">
                                <span class="summary-badge badge-optional">${data.optional_count} Optional/Elective</span>
                            </span>
                        `;
                    } else {
                        summary.innerHTML = '';
                    }
                    
                    updateOptionalCount(modal);
                })
                .catch(error => {
                    console.error('Error loading subjects:', error);
                    loading.style.display = 'none';
                    subjectsGrid.innerHTML = '<div class="no-subjects">Error loading subjects. Please try again.</div>';
                });
        } else {
            subjectsGrid.innerHTML = '<div class="no-subjects">Select course and semester to view subjects</div>';
        }
    }
    
    function updateOptionalCount(modal) {
        var checkboxes = document.querySelectorAll('#' + modal + '_subjects_grid input[name="optional_subjects[]"]:checked');
        var count = checkboxes.length;
        
        var summary = document.getElementById(modal + '_subject_summary');
        if (summary) {
            var currentHtml = summary.innerHTML;
            // Remove any existing selected count
            currentHtml = currentHtml.replace(/<span class="summary-item"><span class="summary-badge" style="background:#667eea;">\d+ Selected<\/span><\/span>/, '');
            // Add new selected count
            if (count > 0) {
                currentHtml += '<span class="summary-item"><span class="summary-badge" style="background:#667eea;">' + count + ' Selected</span></span>';
            }
            summary.innerHTML = currentHtml;
        }
    }
    
    function validateField(modal, field, value, currentId = 0) {
        const validationDiv = document.getElementById(modal + '_' + field + '_validation');
        const inputField = document.getElementById(modal + '_' + field);
        
        // Clear previous timeout
        if (validationTimeouts[modal + '_' + field]) {
            clearTimeout(validationTimeouts[modal + '_' + field]);
        }
        
        // If field is empty, mark as valid
        if (value.length === 0) {
            validationDiv.innerHTML = '';
            inputField.classList.remove('input-error', 'input-success');
            validationState[modal][field] = true; // Valid when empty
            updateSubmitButton(modal);
            return;
        }
        
        // Email format validation (client-side)
        if (field === 'email') {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                validationDiv.innerHTML = '<span class="validation-error"> Invalid email format</span>';
                inputField.classList.add('input-error');
                inputField.classList.remove('input-success');
                validationState[modal][field] = false;
                updateSubmitButton(modal);
                return;
            }
        }
        
        // Phone format validation (client-side)
        if (field === 'phone') {
            if (!/^(97|98)\d{8}$/.test(value)) {
                validationDiv.innerHTML = '<span class="validation-error"> Phone must be 10 digits starting with 97 or 98</span>';
                inputField.classList.add('input-error');
                inputField.classList.remove('input-success');
                validationState[modal][field] = false;
                updateSubmitButton(modal);
                return;
            } else {
                validationDiv.innerHTML = '<span class="validation-success">✓ Valid phone number</span>';
                inputField.classList.add('input-success');
                inputField.classList.remove('input-error');
                validationState[modal][field] = true;
                updateSubmitButton(modal);
                return;
            }
        }
        
        // Age validation (client-side)
        if (field === 'dob') {
            var dobDate = new Date(value);
            var today = new Date();
            var age = today.getFullYear() - dobDate.getFullYear();
            var m = today.getMonth() - dobDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < dobDate.getDate())) {
                age--;
            }
            
            if (age < 14) {
                validationDiv.innerHTML = '<span class="validation-error"> Student must be at least 14 years old</span>';
                inputField.classList.add('input-error');
                inputField.classList.remove('input-success');
                validationState[modal][field] = false;
                updateSubmitButton(modal);
                return;
            }
            
            if (age > 99) {
                validationDiv.innerHTML = '<span class="validation-error"> Age cannot be more than 99 years</span>';
                inputField.classList.add('input-error');
                inputField.classList.remove('input-success');
                validationState[modal][field] = false;
                updateSubmitButton(modal);
                return;
            }
            
            validationDiv.innerHTML = '<span class="validation-success">✓ Valid age</span>';
            inputField.classList.add('input-success');
            inputField.classList.remove('input-error');
            validationState[modal][field] = true;
            updateSubmitButton(modal);
            return;
        }
        
        // For roll_number and email, show loading state
        if (field === 'roll_number' || field === 'email') {
            validationDiv.innerHTML = '<span class="validation-spinner"></span> Checking availability...';
            inputField.classList.remove('input-error', 'input-success');
            
            // Set timeout to avoid too many requests
            validationTimeouts[modal + '_' + field] = setTimeout(() => {
                fetch(`students.php?ajax=validate&field=${field}&value=${encodeURIComponent(value)}&current_id=${currentId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.valid) {
                            validationDiv.innerHTML = '<span class="validation-success">✓ Available</span>';
                            inputField.classList.add('input-success');
                            inputField.classList.remove('input-error');
                            validationState[modal][field] = true;
                        } else {
                            validationDiv.innerHTML = `<span class="validation-error"> ${data.message}</span>`;
                            inputField.classList.add('input-error');
                            inputField.classList.remove('input-success');
                            validationState[modal][field] = false;
                        }
                        updateSubmitButton(modal);
                    })
                    .catch(error => {
                        console.error('Validation error:', error);
                        validationDiv.innerHTML = '<span class="validation-error">⚠ Validation failed</span>';
                        validationState[modal][field] = true; // Allow submission on error
                        updateSubmitButton(modal);
                    });
            }, 500);
        }
    }
    
    function updateSubmitButton(modal) {
        const submitBtn = document.getElementById(modal + '_submit_btn');
        const state = validationState[modal];
        
        // Check if all fields are valid (including empty fields)
        if (state.roll_number && state.email && state.phone && state.dob) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
        } else {
            submitBtn.disabled = true;
            submitBtn.style.opacity = '0.5';
            submitBtn.style.cursor = 'not-allowed';
        }
    }
    
    function validateAddForm() {
        const state = validationState.add;
        const rollNumber = document.getElementById('add_roll_number').value.trim();
        const email = document.getElementById('add_email').value.trim();
        const phone = document.getElementById('add_phone').value.trim();
        const dob = document.getElementById('add_dob').value;
        const firstName = document.getElementById('add_first_name').value.trim();
        const lastName = document.querySelector('input[name="last_name"]').value.trim();
        const courseId = document.getElementById('add_course_id').value;
        const semester = document.getElementById('add_semester_number').value;
        const address = document.querySelector('textarea[name="address"]').value.trim();
        
        // Check if required fields are filled
        if (!rollNumber) {
            alert('Please enter a roll number.');
            return false;
        }
        if (!firstName) {
            alert('Please enter first name.');
            return false;
        }
        if (!lastName) {
            alert('Please enter last name.');
            return false;
        }
        if (!dob) {
            alert('Please enter date of birth.');
            return false;
        }
        if (!phone) {
            alert('Please enter a phone number.');
            return false;
        }
        if (!email) {
            alert('Please enter an email.');
            return false;
        }
        if (!address) {
            alert('Please enter an address.');
            return false;
        }
        if (!courseId) {
            alert('Please select a course.');
            return false;
        }
        if (!semester) {
            alert('Please select a semester.');
            return false;
        }
        
        // Check validation state
        if (!state.roll_number || !state.email || !state.phone || !state.dob) {
            alert('Please fix validation errors before submitting.');
            return false;
        }
        return true;
    }
    
    function validateEditForm() {
        const state = validationState.edit;
        const rollNumber = document.getElementById('edit_roll_number').value.trim();
        const email = document.getElementById('edit_email').value.trim();
        const phone = document.getElementById('edit_phone').value.trim();
        const dob = document.getElementById('edit_dob').value;
        const firstName = document.getElementById('edit_first_name').value.trim();
        const lastName = document.getElementById('edit_last_name').value.trim();
        const courseId = document.getElementById('edit_course_id').value;
        const semester = document.getElementById('edit_semester_number').value;
        const address = document.getElementById('edit_address').value.trim();
        
        // Check if required fields are filled
        if (!rollNumber) {
            alert('Please enter a roll number.');
            return false;
        }
        if (!firstName) {
            alert('Please enter first name.');
            return false;
        }
        if (!lastName) {
            alert('Please enter last name.');
            return false;
        }
        if (!dob) {
            alert('Please enter date of birth.');
            return false;
        }
        if (!phone) {
            alert('Please enter a phone number.');
            return false;
        }
        if (!email) {
            alert('Please enter an email.');
            return false;
        }
        if (!address) {
            alert('Please enter an address.');
            return false;
        }
        if (!courseId) {
            alert('Please select a course.');
            return false;
        }
        if (!semester) {
            alert('Please select a semester.');
            return false;
        }
        
        // Check validation state
        if (!state.roll_number || !state.email || !state.phone || !state.dob) {
            alert('Please fix validation errors before submitting.');
            return false;
        }
        return true;
    }
    
    function editStudent(student) {
        $('#edit_student_id').val(student.student_id);
        $('#edit_roll_number').val(student.roll_number);
        $('#edit_first_name').val(student.first_name);
        $('#edit_middle_name').val(student.middle_name);
        $('#edit_last_name').val(student.last_name);
        $('#edit_dob').val(student.dob);
        $('#edit_gender').val(student.gender);
        $('#edit_phone').val(student.phone);
        $('#edit_email').val(student.email);
        $('#edit_address').val(student.address);
        $('#edit_section').val(student.section);
        
        // Reset validation state for edit modal
        validationState.edit = { roll_number: true, email: true, phone: true, dob: true };
        
        // Clear validation messages
        document.getElementById('edit_roll_number_validation').innerHTML = '';
        document.getElementById('edit_email_validation').innerHTML = '';
        document.getElementById('edit_phone_validation').innerHTML = '';
        document.getElementById('edit_dob_validation').innerHTML = '';
        
        // Remove input classes
        document.getElementById('edit_roll_number').classList.remove('input-error', 'input-success');
        document.getElementById('edit_email').classList.remove('input-error', 'input-success');
        document.getElementById('edit_phone').classList.remove('input-error', 'input-success');
        document.getElementById('edit_dob').classList.remove('input-error', 'input-success');
        
        // Get course details to set department
        var course = allCourses.find(c => c.id == student.course_id);
        if (course) {
            // Set department filter
            $('#edit_dept_filter').val(course.dept_id);
            
            // Trigger course filter
            filterCoursesByDepartment('edit');
            
            // Small delay to ensure courses are loaded then set course
            setTimeout(function() {
                $('#edit_course_id').val(student.course_id);
                updateSemesterOptions('edit');
                
                // Small delay to ensure semesters are loaded then set semester
                setTimeout(function() {
                    $('#edit_semester_number').val(student.current_semester);
                    loadSubjects('edit');
                }, 100);
            }, 200);
        }
        
        // Enable submit button
        document.getElementById('edit_submit_btn').disabled = false;
        document.getElementById('edit_submit_btn').style.opacity = '1';
        
        document.getElementById('editModal').style.display = 'block';
    }
    
    function viewStudent(studentId) {
        // Show loading
        document.getElementById('viewLoading').style.display = 'block';
        document.getElementById('viewContent').style.display = 'none';
        document.getElementById('viewModal').style.display = 'block';
        
        // Fetch student details
        fetch(`students.php?ajax=get_student_details&student_id=${studentId}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('viewLoading').style.display = 'none';
                
                if (data.success) {
                    const s = data.student;
                    let subjectsHtml = '';
                    let resultsHtml = '';
                    
                    // Build subjects table
                    if (s.subjects && s.subjects.length > 0) {
                        subjectsHtml = `
                            <div class="subjects-table">
                                <h4>Enrolled Subjects (${s.subjects.length})</h4>
                                <table class="table-mini">
                                    <thead>
                                        <tr>
                                            <th>Subject Code</th>
                                            <th>Subject Name</th>
                                            <th>Semester</th>
                                            <th>Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                        `;
                        
                        s.subjects.forEach(subject => {
                            let typeClass = '';
                            if (subject.subject_type === 'compulsory') typeClass = 'badge-info';
                            else if (subject.subject_type === 'optional') typeClass = 'badge-success';
                            else typeClass = 'badge-warning';
                            
                            subjectsHtml += `
                                <tr>
                                    <td><strong>${subject.subject_code}</strong></td>
                                    <td>${subject.subject_name}</td>
                                    <td>Semester ${subject.semester}</td>
                                    <td><span class="badge ${typeClass}">${subject.subject_type}</span></td>
                                </tr>
                            `;
                        });
                        
                        subjectsHtml += `
                                    </tbody>
                                </table>
                            </div>
                        `;
                    } else {
                        subjectsHtml = '<p style="color: #666; text-align: center; padding: 20px;">No subjects enrolled yet.</p>';
                    }
                    
                    // Build recent results table
                    if (s.recent_results && s.recent_results.length > 0) {
                        resultsHtml = `
                            <div class="results-table">
                                <h4>Recent Results</h4>
                                <table class="table-mini">
                                    <thead>
                                        <tr>
                                            <th>Exam</th>
                                            <th>Subject</th>
                                            <th>Theory</th>
                                            <th>Practical</th>
                                            <th>Total</th>
                                            <th>Grade</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                        `;
                        
                        s.recent_results.forEach(result => {
                            let gradeClass = 'grade-';
                            if (result.grade) {
                                if (result.grade.startsWith('A')) gradeClass += 'A';
                                else if (result.grade.startsWith('B')) gradeClass += 'B';
                                else if (result.grade.startsWith('C')) gradeClass += 'C';
                                else if (result.grade.startsWith('D')) gradeClass += 'D';
                                else gradeClass += 'F';
                            } else {
                                gradeClass = 'grade-F';
                            }
                            
                            resultsHtml += `
                                <tr>
                                    <td>${result.exam_name}</td>
                                    <td>${result.subject_name}</td>
                                    <td>${result.theory_marks || 0}</td>
                                    <td>${result.practical_marks || 0}</td>
                                    <td><strong>${result.total_marks || 0}</strong></td>
                                    <td><span class="grade-badge ${gradeClass}">${result.grade || 'F'}</span></td>
                                </tr>
                            `;
                        });
                        
                        resultsHtml += `
                                    </tbody>
                                </table>
                            </div>
                        `;
                    } else {
                        resultsHtml = '<p style="color: #666; text-align: center; padding: 20px;">No results available yet.</p>';
                    }
                    
                    // Build the complete view
                    document.getElementById('viewContent').innerHTML = `
                        <div class="details-container">
                            <div class="details-header">
                                <div class="student-avatar">
                                    ${s.first_name.charAt(0)}${s.last_name.charAt(0)}
                                </div>
                                <div class="student-title">
                                    <h3>${s.first_name} ${s.middle_name ? s.middle_name + ' ' : ''}${s.last_name}</h3>
                                    <p>Roll Number: <strong>${s.roll_number}</strong> | Student ID: ${s.student_id}</p>
                                </div>
                            </div>
                            
                            <div class="tab-container">
                                <div class="tabs">
                                    <button class="tab active" onclick="showTab('personal')">Personal Information</button>
                                    <button class="tab" onclick="showTab('academic')">Academic Information</button>
                                    <button class="tab" onclick="showTab('subjects')">Enrolled Subjects</button>
                                    <button class="tab" onclick="showTab('results')">Recent Results</button>
                                </div>
                                
                                <div id="personal-tab" class="tab-pane active">
                                    <div class="info-card">
                                        <div class="info-row">
                                            <div class="info-label">Full Name</div>
                                            <div class="info-value">${s.first_name} ${s.middle_name ? s.middle_name + ' ' : ''}${s.last_name}</div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Date of Birth</div>
                                            <div class="info-value">${s.dob} (Age: ${s.age} years)</div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Gender</div>
                                            <div class="info-value">${s.gender}</div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Email</div>
                                            <div class="info-value">${s.email}</div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Phone</div>
                                            <div class="info-value">${s.phone}</div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Address</div>
                                            <div class="info-value">${s.address}</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div id="academic-tab" class="tab-pane">
                                    <div class="info-card">
                                        <div class="info-row">
                                            <div class="info-label">Department</div>
                                            <div class="info-value">${s.dept_name || 'N/A'}</div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Course</div>
                                            <div class="info-value">${s.course_name || 'N/A'}</div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Current Semester</div>
                                            <div class="info-value">Semester ${s.current_semester}</div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Section</div>
                                            <div class="info-value">${s.section || 'N/A'}</div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Enrolled Subjects</div>
                                            <div class="info-value">${s.enrolled_subjects || 0}</div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Total Results</div>
                                            <div class="info-value">${s.result_count || 0}</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div id="subjects-tab" class="tab-pane">
                                    ${subjectsHtml}
                                </div>
                                
                                <div id="results-tab" class="tab-pane">
                                    ${resultsHtml}
                                </div>
                            </div>
                        </div>
                    `;
                    
                    document.getElementById('viewContent').style.display = 'block';
                } else {
                    document.getElementById('viewContent').innerHTML = `
                        <div style="text-align: center; padding: 50px; color: #dc3545;">
                            <h3>Error</h3>
                            <p>${data.message || 'Failed to load student details.'}</p>
                        </div>
                    `;
                    document.getElementById('viewContent').style.display = 'block';
                }
            })
            .catch(error => {
                console.error('Error loading student details:', error);
                document.getElementById('viewLoading').style.display = 'none';
                document.getElementById('viewContent').innerHTML = `
                    <div style="text-align: center; padding: 50px; color: #dc3545;">
                        <h3>Error</h3>
                        <p>Failed to load student details. Please try again.</p>
                    </div>
                `;
                document.getElementById('viewContent').style.display = 'block';
            });
    }
    
    function showTab(tabName) {
        // Hide all tabs
        document.querySelectorAll('.tab-pane').forEach(tab => {
            tab.classList.remove('active');
        });
        
        // Remove active class from all tab buttons
        document.querySelectorAll('.tab').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Show selected tab
        document.getElementById(tabName + '-tab').classList.add('active');
        
        // Add active class to clicked button
        event.target.classList.add('active');
    }
    
    // Initialize filters based on URL parameters
    $(document).ready(function() {
        var deptFilter = <?php echo $dept_filter; ?>;
        var courseFilter = <?php echo $course_filter; ?>;
        var semesterFilter = <?php echo $semester_filter; ?>;
        
        if (deptFilter > 0 && courseFilter > 0) {
            $('#course_filter').val(courseFilter);
        }
        
        if (semesterFilter > 0) {
            $('#semester_filter').val(semesterFilter);
        }
        
        // Close modals when clicking outside
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = 'none';
            }
        }
        
        // Initialize add modal with submit button enabled (since all fields are empty and valid)
        document.getElementById('add_submit_btn').disabled = false;
        document.getElementById('add_submit_btn').style.opacity = '1';
    });
    
    // Reset validation when opening add modal
    document.getElementById('addModal').addEventListener('click', function(event) {
        // Only reset if clicking on the modal background, not the content
        if (event.target === this) {
            setTimeout(() => {
                validationState.add = { roll_number: true, email: true, phone: true, dob: true };
                document.getElementById('add_roll_number_validation').innerHTML = '';
                document.getElementById('add_email_validation').innerHTML = '';
                document.getElementById('add_phone_validation').innerHTML = '';
                document.getElementById('add_dob_validation').innerHTML = '';
                document.getElementById('add_roll_number').classList.remove('input-error', 'input-success');
                document.getElementById('add_email').classList.remove('input-error', 'input-success');
                document.getElementById('add_phone').classList.remove('input-error', 'input-success');
                document.getElementById('add_dob').classList.remove('input-error', 'input-success');
                document.getElementById('add_submit_btn').disabled = false; // Enable button when modal opens
                document.getElementById('add_submit_btn').style.opacity = '1';
            }, 100);
        }
    });
    
    // Add input event listeners for real-time validation
    document.addEventListener('DOMContentLoaded', function() {
        // Add modal listeners
        document.getElementById('add_roll_number').addEventListener('input', function() {
            validateField('add', 'roll_number', this.value);
        });
        
        document.getElementById('add_email').addEventListener('input', function() {
            validateField('add', 'email', this.value);
        });
        
        document.getElementById('add_phone').addEventListener('input', function() {
            validateField('add', 'phone', this.value);
        });
        
        document.getElementById('add_dob').addEventListener('change', function() {
            validateField('add', 'dob', this.value);
        });
        
        // Add listener for last name (required field)
        document.querySelector('input[name="last_name"]').addEventListener('input', function() {
            // No validation needed, but we can use this to ensure it's not empty in form submit
        });
        
        // Add listener for first name (required field)
        document.getElementById('add_first_name').addEventListener('input', function() {
            // No validation needed, but we can use this to ensure it's not empty in form submit
        });
        
        // Edit modal listeners
        document.getElementById('edit_roll_number').addEventListener('input', function() {
            validateField('edit', 'roll_number', this.value, document.getElementById('edit_student_id').value);
        });
        
        document.getElementById('edit_email').addEventListener('input', function() {
            validateField('edit', 'email', this.value, document.getElementById('edit_student_id').value);
        });
        
        document.getElementById('edit_phone').addEventListener('input', function() {
            validateField('edit', 'phone', this.value);
        });
        
        document.getElementById('edit_dob').addEventListener('change', function() {
            validateField('edit', 'dob', this.value);
        });
        
        // Focus listeners for add modal
        document.getElementById('add_roll_number').addEventListener('focus', function() {
            if (this.value.trim() !== '') {
                validateField('add', 'roll_number', this.value);
            }
        });
        
        document.getElementById('add_email').addEventListener('focus', function() {
            if (this.value.trim() !== '') {
                validateField('add', 'email', this.value);
            }
        });
        
        document.getElementById('add_phone').addEventListener('focus', function() {
            if (this.value.trim() !== '') {
                validateField('add', 'phone', this.value);
            }
        });
    });
</script>
</body>
</html>