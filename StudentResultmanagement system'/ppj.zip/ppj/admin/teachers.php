<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$database = new Database();
$conn = $database->getConnection();

// Handle Add/Edit/Delete operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add') {
            $username = $database->escapeString($_POST['username']);
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $first_name = $database->escapeString($_POST['first_name']);
            $middle_name = $database->escapeString($_POST['middle_name']);
            $last_name = $database->escapeString($_POST['last_name']);
            $email = $database->escapeString($_POST['email']);
            $phone = $database->escapeString($_POST['phone']);
            $dept_id = $_POST['dept_id'] ?: 'NULL';
            
            // Check if username already exists
            $check_username = $conn->query("SELECT teacher_id FROM Teacher WHERE username = '$username'");
            if ($check_username->num_rows > 0) {
                $_SESSION['message'] = "Username already exists! Please choose a different username.";
                $_SESSION['msg_type'] = "error";
                header("Location: teachers.php");
                exit();
            }
            
            // Check if email already exists
            $check_email = $conn->query("SELECT teacher_id FROM Teacher WHERE email = '$email'");
            if ($check_email->num_rows > 0) {
                $_SESSION['message'] = "Email already exists! Please use a different email.";
                $_SESSION['msg_type'] = "error";
                header("Location: teachers.php");
                exit();
            }
            
            // Validate phone number format (10 digits, starts with 97 or 98)
            if (!preg_match('/^(97|98)\d{8}$/', $phone)) {
                $_SESSION['message'] = "Phone number must be 10 digits and start with 97 or 98!";
                $_SESSION['msg_type'] = "error";
                header("Location: teachers.php");
                exit();
            }
            
            $sql = "INSERT INTO Teacher (username, password, first_name, middle_name, last_name, email, phone, dept_id) 
                    VALUES ('$username', '$password', '$first_name', '$middle_name', '$last_name', '$email', '$phone', $dept_id)";
            
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Teacher added successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
        }
        
        elseif ($action == 'edit') {
            $teacher_id = intval($_POST['teacher_id']);
            $username = $database->escapeString($_POST['username']);
            $first_name = $database->escapeString($_POST['first_name']);
            $middle_name = $database->escapeString($_POST['middle_name']);
            $last_name = $database->escapeString($_POST['last_name']);
            $email = $database->escapeString($_POST['email']);
            $phone = $database->escapeString($_POST['phone']);
            $dept_id = $_POST['dept_id'] ?: 'NULL';
            
            // Check if username already exists for another teacher
            $check_username = $conn->query("SELECT teacher_id FROM Teacher WHERE username = '$username' AND teacher_id != $teacher_id");
            if ($check_username->num_rows > 0) {
                $_SESSION['message'] = "Username already exists! Please choose a different username.";
                $_SESSION['msg_type'] = "error";
                header("Location: teachers.php");
                exit();
            }
            
            // Check if email already exists for another teacher
            $check_email = $conn->query("SELECT teacher_id FROM Teacher WHERE email = '$email' AND teacher_id != $teacher_id");
            if ($check_email->num_rows > 0) {
                $_SESSION['message'] = "Email already exists! Please use a different email.";
                $_SESSION['msg_type'] = "error";
                header("Location: teachers.php");
                exit();
            }
            
            // Validate phone number format (10 digits, starts with 97 or 98)
            if (!preg_match('/^(97|98)\d{8}$/', $phone)) {
                $_SESSION['message'] = "Phone number must be 10 digits and start with 97 or 98!";
                $_SESSION['msg_type'] = "error";
                header("Location: teachers.php");
                exit();
            }
            
            // Update password if provided
            if (!empty($_POST['password'])) {
                $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $sql = "UPDATE Teacher SET username='$username', password='$password', first_name='$first_name', 
                        middle_name='$middle_name', last_name='$last_name', email='$email', 
                        phone='$phone', dept_id=$dept_id WHERE teacher_id=$teacher_id";
            } else {
                $sql = "UPDATE Teacher SET username='$username', first_name='$first_name', 
                        middle_name='$middle_name', last_name='$last_name', email='$email', 
                        phone='$phone', dept_id=$dept_id WHERE teacher_id=$teacher_id";
            }
            
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Teacher updated successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
        }
        
       elseif ($action == 'delete') {
    $teacher_id = intval($_POST['teacher_id']);
    
    // Simple delete - cascade will handle allocations
    $sql = "DELETE FROM Teacher WHERE teacher_id=$teacher_id";
    
    if ($conn->query($sql)) {
        $_SESSION['message'] = "Teacher deleted successfully! All associated allocations have been removed.";
        $_SESSION['msg_type'] = "success";
    } else {
        $_SESSION['message'] = "Error: " . $conn->error;
        $_SESSION['msg_type'] = "error";
    }
}
        
        header("Location: teachers.php");
        exit();
    }
}

// Handle AJAX validation requests
if (isset($_GET['ajax']) && $_GET['ajax'] == 'validate') {
    header('Content-Type: application/json');
    
    $field = $_GET['field'];
    $value = $database->escapeString($_GET['value']);
    $current_id = isset($_GET['current_id']) ? intval($_GET['current_id']) : 0;
    
    $response = ['valid' => true, 'message' => ''];
    
    if ($field == 'username') {
        $query = "SELECT teacher_id FROM Teacher WHERE username = '$value'";
        if ($current_id > 0) {
            $query .= " AND teacher_id != $current_id";
        }
        $result = $conn->query($query);
        if ($result && $result->num_rows > 0) {
            $response['valid'] = false;
            $response['message'] = 'Username already taken';
        }
    }
    elseif ($field == 'email') {
        // First validate email format
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $response['valid'] = false;
            $response['message'] = 'Invalid email format';
        } else {
            $query = "SELECT teacher_id FROM Teacher WHERE email = '$value'";
            if ($current_id > 0) {
                $query .= " AND teacher_id != $current_id";
            }
            $result = $conn->query($query);
            if ($result && $result->num_rows > 0) {
                $response['valid'] = false;
                $response['message'] = 'Email already registered';
            }
        }
    }
    elseif ($field == 'phone') {
        // Validate phone format: 10 digits, starts with 97 or 98
        if (!preg_match('/^(97|98)\d{8}$/', $value)) {
            $response['valid'] = false;
            $response['message'] = 'Phone must be 10 digits starting with 97 or 98';
        }
    }
    
    echo json_encode($response);
    exit();
}

// Handle department filter
$dept_filter = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;

// Get all teachers with department names and filter
$teacher_query = "
    SELECT t.*, d.dept_name 
    FROM Teacher t
    LEFT JOIN Department d ON t.dept_id = d.dept_id
";

if ($dept_filter > 0) {
    $teacher_query .= " WHERE t.dept_id = $dept_filter";
}

$teacher_query .= " ORDER BY t.first_name, t.last_name";
$teachers = $conn->query($teacher_query);

// Get departments for filter dropdown
$departments = $conn->query("SELECT * FROM Department ORDER BY dept_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Manage Teachers - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Additional styles for validation */
        .validation-message {
            font-size: 12px;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .validation-success {
            color: #28a745;
        }
        .validation-error {
            color: #dc3545;
        }
        .validation-spinner {
            display: inline-block;
            width: 12px;
            height: 12px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 5px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .input-error {
            border-color: #dc3545 !important;
        }
        .input-success {
            border-color: #28a745 !important;
        }
        .form-group {
            position: relative;
            margin-bottom: 15px;
        }
        .required-field::after {
            content: " *";
            color: red;
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .form-group label {
            font-weight: 600;
            margin-bottom: 5px;
            display: block;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .phone-hint {
            font-size: 11px;
            color: #666;
            margin-top: 3px;
        }
        @media (max-width: 768px) {
            .card-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .card-header > div {
                width: 100%;
            }
            #dept_filter {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                   <a href="adminDashboard.php">
            <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
            </a>
               <a href="departments.php">
            <img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5>
            </a>
                <a href="courses.php">
            <img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5>
            </a>
                  <a href="subjects.php">
            <img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5>
        </a>
         <a href="teachers.php" class="active">
            <img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5>
        </a>

         <a href="students.php">
            <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5>
        </a>
          
        <a href="allocations.php">
            <img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5>
        </a>
        <a href="exams.php">
            <img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5>
        </a>
        <a href="results.php">
            <img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5>
        </a>

        <a href="feedbacks.php">
            <img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5>
        </a>
        <a href="settings.php">
            <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5>
        </a>
        <a href="../logout.php">
            <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5>
        </a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2> <img src="../icons/Teacher.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Manage Teachers</h2>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <!-- Department Filter Dropdown -->
                        <select id="dept_filter" onchange="filterByDepartment()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 200px;">
                            <option value="0">All Departments</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                                $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $dept['dept_name']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        
                        <!-- Clear Filters Button -->
                        <?php if($dept_filter > 0): ?>
                        <button class="btn btn-secondary" onclick="clearFilters()">Clear Filters</button>
                        <?php endif; ?>
                        
                        <button class="btn" onclick="openAddModal()">Add New Teacher <img src="../icons/Add.png" style="height: 27px; vertical-align: middle; margin-right: 10px;"></button>
                    </div>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($teachers && $teachers->num_rows > 0): ?>
                            <?php while($row = $teachers->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['teacher_id']; ?></td>
                                <td><strong><?php echo htmlspecialchars($row['username']); ?></strong></td>
                                <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name']); ?></td>
                                <td>
                                    <?php if($row['dept_id']): ?>
                                        <a href="?dept_id=<?php echo $row['dept_id']; ?>" style="text-decoration: none; color: inherit;">
                                            <?php echo htmlspecialchars($row['dept_name'] ?? 'N/A'); ?>
                                        </a>
                                    <?php else: ?>
                                        <?php echo 'N/A'; ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                <td>
                                    <button class="action-btn edit-btn" onclick='editTeacher(<?php echo json_encode($row); ?>)' title="Edit"><img src="../icons/Edit.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></button>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure? Deleting this teacher will also remove all their allocations.')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="teacher_id" value="<?php echo $row['teacher_id']; ?>">
                                        <button type="submit" class="action-btn delete-btn" title="Delete"><img src="../icons/Delete.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 20px;">
                                    No teachers found
                                    <?php if($dept_filter > 0): ?>
                                        in this department. <a href="teachers.php">View all teachers</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content" style="max-width: 700px;">
            <span class="close" onclick="closeModal('addModal')">&times;</span>
            <h2>Add New Teacher</h2>
            <form method="POST" id="addForm" onsubmit="return validateAddForm()">
                <input type="hidden" name="action" value="add">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label class="required-field">Username</label>
                        <input type="text" name="username" id="add_username" placeholder="e.g., johndoe" required>
                        <div id="add_username_validation" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Password</label>
                        <input type="password" name="password" id="add_password" placeholder="Enter password" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">First Name</label>
                        <input type="text" name="first_name" id="add_first_name" placeholder="First name" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Middle Name</label>
                        <input type="text" name="middle_name" id="add_middle_name" placeholder="Middle name (optional)">
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Last Name</label>
                        <input type="text" name="last_name" id="add_last_name" placeholder="Last name" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Email</label>
                        <input type="email" name="email" id="add_email" placeholder="teacher@example.com" required>
                        <div id="add_email_validation" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Phone</label>
                        <input type="text" name="phone" id="add_phone" placeholder="e.g., 9812345678" required>
                        <div id="add_phone_validation" class="validation-message"></div>
                        <div class="phone-hint">Must be 10 digits starting with 97 or 98</div>
                    </div>
                    
                    <div class="form-group">
                        <label>Department</label>
                        <select name="dept_id" id="add_dept_id">
                            <option value="">--Select Department--</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>">
                                <?php echo htmlspecialchars($dept['dept_name']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                
                <div style="margin-top: 20px; text-align: right;">
                    <button type="submit" class="btn" id="add_submit_btn">Add Teacher <img src="../icons/Add.png" style="height: 20px; vertical-align: middle; margin-left: 5px;"></button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content" style="max-width: 700px;">
            <span class="close" onclick="closeModal('editModal')">&times;</span>
            <h2>Edit Teacher</h2>
            <form method="POST" id="editForm" onsubmit="return validateEditForm()">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="teacher_id" id="edit_teacher_id">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label class="required-field">Username</label>
                        <input type="text" name="username" id="edit_username" required>
                        <div id="edit_username_validation" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label>Password (leave blank to keep current)</label>
                        <input type="password" name="password" id="edit_password" placeholder="Enter new password">
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">First Name</label>
                        <input type="text" name="first_name" id="edit_first_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Middle Name</label>
                        <input type="text" name="middle_name" id="edit_middle_name">
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Last Name</label>
                        <input type="text" name="last_name" id="edit_last_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Email</label>
                        <input type="email" name="email" id="edit_email" required>
                        <div id="edit_email_validation" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label class="required-field">Phone</label>
                        <input type="text" name="phone" id="edit_phone" required>
                        <div id="edit_phone_validation" class="validation-message"></div>
                        <div class="phone-hint">Must be 10 digits starting with 97 or 98</div>
                    </div>
                    
                    <div class="form-group">
                        <label>Department</label>
                        <select name="dept_id" id="edit_dept_id">
                            <option value="">--Select Department--</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>"><?php echo htmlspecialchars($dept['dept_name']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                
                <div style="margin-top: 20px; text-align: right;">
                    <button type="submit" class="btn" id="edit_submit_btn">Update Teacher <img src="../icons/Edit.png" style="height: 20px; vertical-align: middle; margin-left: 5px;"></button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        // Validation state management
        let validationTimeouts = {};
        let validationState = {
            add: { username: false, email: false, phone: false },
            edit: { username: false, email: false, phone: false }
        };
        
        // Modal functions
        function openAddModal() {
            document.getElementById('addModal').style.display = 'block';
            resetValidation('add');
            document.getElementById('addForm').reset();
            
            // Set default department if filter is active
            var deptFilter = <?php echo $dept_filter; ?>;
            if (deptFilter > 0) {
                document.getElementById('add_dept_id').value = deptFilter;
            }
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        function filterByDepartment() {
            var deptId = document.getElementById('dept_filter').value;
            var url = 'teachers.php';
            if (deptId > 0) {
                url += '?dept_id=' + deptId;
            }
            window.location.href = url;
        }
        
        function clearFilters() {
            window.location.href = 'teachers.php';
        }
        
        // Validation functions
        function validateField(modal, field, value, currentId = 0) {
            const validationDiv = document.getElementById(modal + '_' + field + '_validation');
            const inputField = document.getElementById(modal + '_' + field);
            const submitBtn = document.getElementById(modal + '_submit_btn');
            
            // Clear previous timeout
            if (validationTimeouts[modal + '_' + field]) {
                clearTimeout(validationTimeouts[modal + '_' + field]);
            }
            
            // If field is empty, mark as invalid
            if (value.trim().length === 0) {
                validationDiv.innerHTML = '<span class="validation-error"> This field is required</span>';
                inputField.classList.add('input-error');
                inputField.classList.remove('input-success');
                validationState[modal][field] = false;
                updateSubmitButton(modal);
                return;
            }
            
            // Email format validation
            if (field === 'email') {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(value)) {
                    validationDiv.innerHTML = '<span class="validation-error">Please enter a valid email address</span>';
                    inputField.classList.add('input-error');
                    inputField.classList.remove('input-success');
                    validationState[modal][field] = false;
                    updateSubmitButton(modal);
                    return;
                }
            }
            
            // Phone format validation
            if (field === 'phone') {
                const phoneRegex = /^(97|98)\d{8}$/;
                if (!phoneRegex.test(value)) {
                    validationDiv.innerHTML = '<span class="validation-error"> Phone must be 10 digits starting with 97 or 98</span>';
                    inputField.classList.add('input-error');
                    inputField.classList.remove('input-success');
                    validationState[modal][field] = false;
                    updateSubmitButton(modal);
                    return;
                }
            }
            
            // Show loading state
            validationDiv.innerHTML = '<span class="validation-spinner"></span> Checking...';
            inputField.classList.remove('input-error', 'input-success');
            
            // Set timeout to avoid too many requests
            validationTimeouts[modal + '_' + field] = setTimeout(() => {
                // Create the URL with proper encoding
                let url = `teachers.php?ajax=validate&field=${field}&value=${encodeURIComponent(value)}`;
                if (currentId > 0) {
                    url += `&current_id=${currentId}`;
                }
                
                fetch(url)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log('Validation response for', field, ':', data);
                        
                        if (data.valid) {
                            let successMessage = '';
                            switch(field) {
                                case 'username': successMessage = ' Username available'; break;
                                case 'email': successMessage = 'Email available'; break;
                                case 'phone': successMessage = ' Valid phone number'; break;
                                default: successMessage = ' Valid';
                            }
                            validationDiv.innerHTML = '<span class="validation-success">' + successMessage + '</span>';
                            inputField.classList.add('input-success');
                            inputField.classList.remove('input-error');
                            validationState[modal][field] = true;
                        } else {
                            validationDiv.innerHTML = `<span class="validation-error"> ${data.message}</span>`;
                            inputField.classList.add('input-error');
                            inputField.classList.remove('input-success');
                            validationState[modal][field] = false;
                        }
                        updateSubmitButton(modal);
                    })
                    .catch(error => {
                        console.error('Validation error:', error);
                        validationDiv.innerHTML = '<span class="validation-error">Validation failed. Please try again.</span>';
                        validationState[modal][field] = true; // Allow submission on error
                        updateSubmitButton(modal);
                    });
            }, 500);
        }
        
        function updateSubmitButton(modal) {
            const submitBtn = document.getElementById(modal + '_submit_btn');
            if (!submitBtn) return;
            
            const state = validationState[modal];
            
            // Check if all validations are true
            if (state && state.username && state.email && state.phone) {
                submitBtn.disabled = false;
                submitBtn.style.opacity = '1';
                submitBtn.style.cursor = 'pointer';
            } else {
                submitBtn.disabled = true;
                submitBtn.style.opacity = '0.5';
                submitBtn.style.cursor = 'not-allowed';
            }
        }
        
        function resetValidation(modal) {
            validationState[modal] = { username: false, email: false, phone: false };
            
            // Clear validation messages and classes
            ['username', 'email', 'phone'].forEach(field => {
                const div = document.getElementById(modal + '_' + field + '_validation');
                const input = document.getElementById(modal + '_' + field);
                if (div) div.innerHTML = '';
                if (input) {
                    input.classList.remove('input-error', 'input-success');
                }
            });
            
            // Disable submit button
            const submitBtn = document.getElementById(modal + '_submit_btn');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.style.opacity = '0.5';
            }
        }
        
        function validateAddForm() {
            const state = validationState.add;
            
            // Check if all required fields are filled
            const username = document.getElementById('add_username').value.trim();
            const password = document.getElementById('add_password').value.trim();
            const firstName = document.getElementById('add_first_name').value.trim();
            const lastName = document.getElementById('add_last_name').value.trim();
            const email = document.getElementById('add_email').value.trim();
            const phone = document.getElementById('add_phone').value.trim();
            
            if (!username || !password || !firstName || !lastName || !email || !phone) {
                alert('Please fill in all required fields.');
                return false;
            }
            
            // Check validation state
            if (!state.username || !state.email || !state.phone) {
                alert('Please fix validation errors before submitting.');
                return false;
            }
            
            return true;
        }
        
        function validateEditForm() {
            const state = validationState.edit;
            
            // Check if all required fields are filled
            const username = document.getElementById('edit_username').value.trim();
            const firstName = document.getElementById('edit_first_name').value.trim();
            const lastName = document.getElementById('edit_last_name').value.trim();
            const email = document.getElementById('edit_email').value.trim();
            const phone = document.getElementById('edit_phone').value.trim();
            
            if (!username || !firstName || !lastName || !email || !phone) {
                alert('Please fill in all required fields.');
                return false;
            }
            
            // Check validation state
            if (!state.username || !state.email || !state.phone) {
                alert('Please fix validation errors before submitting.');
                return false;
            }
            
            return true;
        }
        
        function editTeacher(teacher) {
            document.getElementById('edit_teacher_id').value = teacher.teacher_id;
            document.getElementById('edit_username').value = teacher.username || '';
            document.getElementById('edit_first_name').value = teacher.first_name || '';
            document.getElementById('edit_middle_name').value = teacher.middle_name || '';
            document.getElementById('edit_last_name').value = teacher.last_name || '';
            document.getElementById('edit_email').value = teacher.email || '';
            document.getElementById('edit_phone').value = teacher.phone || '';
            document.getElementById('edit_dept_id').value = teacher.dept_id || '';
            
            // Reset validation
            resetValidation('edit');
            
            // Re-validate existing values
            if (teacher.email) {
                setTimeout(() => {
                    validateField('edit', 'email', teacher.email, teacher.teacher_id);
                }, 100);
            }
            if (teacher.phone) {
                setTimeout(() => {
                    validateField('edit', 'phone', teacher.phone);
                }, 100);
            }
            if (teacher.username) {
                setTimeout(() => {
                    validateField('edit', 'username', teacher.username, teacher.teacher_id);
                }, 100);
            }
            
            document.getElementById('editModal').style.display = 'block';
        }
        
        // Close modals when clicking on X or outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
        
        // Add event listeners when document is ready
        document.addEventListener('DOMContentLoaded', function() {
            // Add modal input listeners
            document.getElementById('add_username').addEventListener('input', function() {
                validateField('add', 'username', this.value);
            });
            
            document.getElementById('add_email').addEventListener('input', function() {
                validateField('add', 'email', this.value);
            });
            
            document.getElementById('add_phone').addEventListener('input', function() {
                validateField('add', 'phone', this.value);
            });
            
            // Edit modal input listeners
            document.getElementById('edit_username').addEventListener('input', function() {
                validateField('edit', 'username', this.value, document.getElementById('edit_teacher_id').value);
            });
            
            document.getElementById('edit_email').addEventListener('input', function() {
                validateField('edit', 'email', this.value, document.getElementById('edit_teacher_id').value);
            });
            
            document.getElementById('edit_phone').addEventListener('input', function() {
                validateField('edit', 'phone', this.value);
            });
            
            // Focus events for validation
            document.getElementById('add_username').addEventListener('focus', function() {
                if (this.value.trim() !== '') {
                    validateField('add', 'username', this.value);
                }
            });
            
            document.getElementById('add_email').addEventListener('focus', function() {
                if (this.value.trim() !== '') {
                    validateField('add', 'email', this.value);
                }
            });
            
            document.getElementById('add_phone').addEventListener('focus', function() {
                if (this.value.trim() !== '') {
                    validateField('add', 'phone', this.value);
                }
            });
            
            document.getElementById('edit_username').addEventListener('focus', function() {
                if (this.value.trim() !== '') {
                    validateField('edit', 'username', this.value, document.getElementById('edit_teacher_id').value);
                }
            });
            
            document.getElementById('edit_email').addEventListener('focus', function() {
                if (this.value.trim() !== '') {
                    validateField('edit', 'email', this.value, document.getElementById('edit_teacher_id').value);
                }
            });
            
            document.getElementById('edit_phone').addEventListener('focus', function() {
                if (this.value.trim() !== '') {
                    validateField('edit', 'phone', this.value);
                }
            });
        });
    </script>
</body>
</html>