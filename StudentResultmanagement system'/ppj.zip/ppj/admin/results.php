<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Handle AJAX request to get result details for printing
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_result_details') {
    $student_id = intval($_GET['student_id']);
    $exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;
    
    // Get student information
    $student_query = "
        SELECT 
            s.student_id,
            s.roll_number,
            s.first_name,
            s.middle_name,
            s.last_name,
            s.section,
            c.course_id,
            c.course_name,
            d.dept_id,
            d.dept_name
        FROM Student s
        INNER JOIN Course c ON s.course_id = c.course_id
        INNER JOIN Department d ON c.dept_id = d.dept_id
        WHERE s.student_id = $student_id
    ";
    
    $student_result = $conn->query($student_query);
    
    if (!$student_result || $student_result->num_rows == 0) {
        echo json_encode(['success' => false, 'message' => 'Student not found']);
        exit();
    }
    
    $student = $student_result->fetch_assoc();
    
    // Build exam condition
    $exam_condition = "";
    if ($exam_id > 0) {
        $exam_condition = " AND r.exam_id = $exam_id";
    }
    
    // Get all results for this student
    $results_query = "
        SELECT 
            r.result_id,
            r.theory_marks,
            r.practical_marks,
            r.grade,
            r.remarks,
            r.exam_id,
            sub.subject_id,
            sub.subject_name,
            sub.subject_code,
            sub.semester_number,
            sub.credit_hours,
            COALESCE(es.theory_full_marks, 60) as theory_full_marks,
            COALESCE(es.theory_pass_marks, 24) as theory_pass_marks,
            COALESCE(es.practical_full_marks, 40) as practical_full_marks,
            COALESCE(es.practical_pass_marks, 18) as practical_pass_marks,
            e.exam_name,
            e.exam_type,
            e.exam_id
        FROM Result r
        INNER JOIN Subject sub ON r.subject_id = sub.subject_id
        INNER JOIN Exam e ON r.exam_id = e.exam_id
        LEFT JOIN Exam_Subject es ON r.exam_id = es.exam_id AND r.subject_id = es.subject_id
        WHERE r.student_id = $student_id
        $exam_condition
        ORDER BY sub.semester_number, sub.subject_name
    ";
    
    $results_data = $conn->query($results_query);
    
    if (!$results_data || $results_data->num_rows == 0) {
        echo json_encode(['success' => false, 'message' => 'No results found for this student']);
        exit();
    }
    
    $subjects = [];
    $total_obtained = 0;
    $total_full = 0;
    $exam_info = null;
    
    while ($row = $results_data->fetch_assoc()) {
        $subjects[] = $row;
        $total_obtained += ($row['theory_marks'] ?? 0) + ($row['practical_marks'] ?? 0);
        $total_full += ($row['theory_full_marks'] ?? 60) + ($row['practical_full_marks'] ?? 40);
        
        if (!$exam_info) {
            $exam_info = [
                'exam_name' => $row['exam_name'],
                'exam_type' => $row['exam_type'],
                'exam_id' => $row['exam_id']
            ];
        }
    }
    
    // Format the full name
    $full_name = trim($student['first_name'] . ' ' . ($student['middle_name'] ?? '') . ' ' . $student['last_name']);
    $student['full_name'] = preg_replace('/\s+/', ' ', $full_name);
    
    $response = [
        'success' => true,
        'student' => $student,
        'subjects' => $subjects,
        'exam_info' => $exam_info,
        'totals' => [
            'obtained' => $total_obtained,
            'full' => $total_full
        ]
    ];
    
    echo json_encode($response);
    exit();
}

// Handle delete request
if (isset($_GET['delete'])) {
    $result_id = intval($_GET['delete']);
    
    // Simple delete - no cascade needed (this is the child table)
    $delete_query = "DELETE FROM Result WHERE result_id = $result_id";
    
    if ($conn->query($delete_query)) {
        $_SESSION['message'] = "Result deleted successfully!";
        $_SESSION['msg_type'] = "success";
    } else {
        $_SESSION['message'] = "Error: " . $conn->error;
        $_SESSION['msg_type'] = "error";
    }
    
    // Redirect back to results page with filters
    $redirect_url = "results.php";
    $params = [];
    if (isset($_GET['dept_id']) && $_GET['dept_id'] > 0) $params[] = "dept_id=" . $_GET['dept_id'];
    if (isset($_GET['course_id']) && $_GET['course_id'] > 0) $params[] = "course_id=" . $_GET['course_id'];
    if (isset($_GET['exam_id']) && $_GET['exam_id'] > 0) $params[] = "exam_id=" . $_GET['exam_id'];
    if (isset($_GET['semester']) && $_GET['semester'] > 0) $params[] = "semester=" . $_GET['semester'];
    if (isset($_GET['section']) && !empty($_GET['section'])) $params[] = "section=" . urlencode($_GET['section']);
    if (isset($_GET['search']) && !empty($_GET['search'])) $params[] = "search=" . urlencode($_GET['search']);
    if (isset($_GET['page']) && $_GET['page'] > 1) $params[] = "page=" . $_GET['page'];
    
    if (!empty($params)) {
        $redirect_url .= "?" . implode("&", $params);
    }
    
    header("Location: $redirect_url");
    exit();
}

// Handle filters
$dept_filter = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;
$course_filter = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$exam_filter = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;
$semester_filter = isset($_GET['semester']) ? intval($_GET['semester']) : 0;
$section_filter = isset($_GET['section']) ? $database->escapeString($_GET['section']) : '';
$search_query = isset($_GET['search']) ? $database->escapeString($_GET['search']) : '';

// Check if any filter is selected
$has_filters = ($dept_filter > 0 || $course_filter > 0 || 
                $exam_filter > 0 || $semester_filter > 0 || !empty($section_filter) || 
                !empty($search_query));

// Get all departments
$departments = $conn->query("SELECT * FROM Department ORDER BY dept_name");

// Get courses based on selected department
$filter_courses = null;
if ($dept_filter > 0) {
    $filter_courses = $conn->query("SELECT c.* FROM Course c WHERE c.dept_id = $dept_filter ORDER BY c.course_name");
}

// Get exams - FIXED: Using exam_id instead of id
$exams = $conn->query("SELECT exam_id, exam_name, exam_type FROM Exam ORDER BY exam_name");

// Get unique sections from students
$sections = $conn->query("SELECT DISTINCT section FROM Student WHERE section IS NOT NULL AND section != '' ORDER BY section");

// Get all subjects for the selected course and semester to use as columns
$all_subjects = [];
$subject_columns = [];

if ($has_filters && $course_filter > 0 && $semester_filter > 0) {
    // FIXED: Using subject_id instead of id
    $subject_query = "SELECT subject_id, subject_name, subject_code, credit_hours 
                      FROM Subject 
                      WHERE course_id = $course_filter 
                      AND semester_number = $semester_filter 
                      ORDER BY subject_name";
    $subject_result = $conn->query($subject_query);
    
    if ($subject_result) {
        while ($subject = $subject_result->fetch_assoc()) {
            $all_subjects[] = $subject;
            $subject_columns[$subject['subject_id']] = $subject;
        }
    }
}

// Initialize variables
$results = null;
$total_rows = 0;
$total_pages = 0;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;

// Only fetch results if filters are applied
if ($has_filters && $course_filter > 0 && $semester_filter > 0) {
    // Build base query to get all students for the selected course
    // FIXED: Using student_id instead of id
    $student_query = "
        SELECT 
            s.student_id,
            s.roll_number,
            s.first_name,
            s.middle_name,
            s.last_name,
            s.section,
            c.course_id,
            c.course_name,
            d.dept_id,
            d.dept_name
        FROM Student s
        INNER JOIN Course c ON s.course_id = c.course_id
        INNER JOIN Department d ON c.dept_id = d.dept_id
        WHERE 1=1
    ";

    // Apply student filters
    if ($dept_filter > 0) {
        // FIXED: Using dept_id instead of id
        $student_query .= " AND d.dept_id = $dept_filter";
    }

    if ($course_filter > 0) {
        // FIXED: Using course_id instead of id
        $student_query .= " AND c.course_id = $course_filter";
    }

    if (!empty($section_filter)) {
        $student_query .= " AND s.section = '$section_filter'";
    }

    if (!empty($search_query)) {
        $student_query .= " AND (
            s.roll_number LIKE '%$search_query%' OR
            s.first_name LIKE '%$search_query%' OR
            s.last_name LIKE '%$search_query%'
        )";
    }

    // Get total count for pagination
    $count_query = "SELECT COUNT(*) as total FROM ($student_query) as temp";
    $count_result = $conn->query($count_query);
    
    if ($count_result) {
        $count_row = $count_result->fetch_assoc();
        $total_rows = $count_row['total'];
        $total_pages = ceil($total_rows / 20);
    }

    // Ensure page is within valid range
    if ($page < 1) $page = 1;
    if ($page > $total_pages && $total_pages > 0) $page = $total_pages;

    $offset = ($page - 1) * 20;
    $limit = 20;

    // Get students for the current page
    $students_query = $student_query . " ORDER BY s.roll_number LIMIT $offset, $limit";
    $students_result = $conn->query($students_query);
    
    if ($students_result && $students_result->num_rows > 0) {
        $results = [];
        
        while ($student = $students_result->fetch_assoc()) {
            $student_id = $student['student_id'];
            
            // Build exam condition
            $exam_condition = "";
            if ($exam_filter > 0) {
                $exam_condition = " AND r.exam_id = $exam_filter";
            }
            
            // Get all results for this student
            // FIXED: Using correct column names
            $results_query = "
                SELECT 
                    r.result_id,
                    r.theory_marks,
                    r.practical_marks,
                    COALESCE(r.theory_marks, 0) + COALESCE(r.practical_marks, 0) as total_marks,
                    r.grade,
                    r.remarks,
                    r.exam_id,
                    sub.subject_id,
                    sub.subject_name,
                    sub.subject_code,
                    sub.credit_hours,
                    COALESCE(es.theory_full_marks, 60) as theory_full_marks,
                    COALESCE(es.practical_full_marks, 40) as practical_full_marks,
                    e.exam_name,
                    e.exam_type
                FROM Subject sub
                LEFT JOIN Result r ON r.subject_id = sub.subject_id 
                    AND r.student_id = $student_id 
                    $exam_condition
                LEFT JOIN Exam e ON r.exam_id = e.exam_id
                LEFT JOIN Exam_Subject es ON r.exam_id = es.exam_id AND r.subject_id = es.subject_id
                WHERE sub.course_id = $course_filter 
                    AND sub.semester_number = $semester_filter
                ORDER BY sub.subject_name
            ";
            
            $result_data = $conn->query($results_query);
            
            $student_results = $student;
            $student_results['subjects'] = [];
            $student_results['total_obtained'] = 0;
            $student_results['total_full'] = 0;
            $student_results['exam_name'] = '';
            $student_results['exam_type'] = '';
            $student_results['has_results'] = false;
            $student_results['result_ids'] = [];
            
            if ($result_data) {
                while ($row = $result_data->fetch_assoc()) {
                    $subject_id = $row['subject_id'];
                    $student_results['subjects'][$subject_id] = $row;
                    
                    // Calculate totals only if result exists
                    if ($row['theory_marks'] !== null || $row['practical_marks'] !== null) {
                        $student_results['has_results'] = true;
                        $student_results['total_obtained'] += ($row['theory_marks'] ?? 0) + ($row['practical_marks'] ?? 0);
                        $student_results['total_full'] += ($row['theory_full_marks'] ?? 60) + ($row['practical_full_marks'] ?? 40);
                        
                        // Store result IDs for printing
                        if ($row['result_id']) {
                            $student_results['result_ids'][] = $row['result_id'];
                        }
                        
                        // Store exam info (will be same for all results if exam filter is applied)
                        if (empty($student_results['exam_name']) && !empty($row['exam_name'])) {
                            $student_results['exam_name'] = $row['exam_name'];
                            $student_results['exam_type'] = $row['exam_type'];
                            $student_results['exam_id'] = $row['exam_id'];
                        }
                    }
                }
            }
            
            $results[] = $student_results;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Manage Results - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Results Page Specific Styles */
        .filters-section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .filter-item {
            display: flex;
            flex-direction: column;
        }
        
        .filter-item label {
            font-size: 13px;
            color: #666;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .filter-item select, .filter-item input {
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .filter-item select:focus, .filter-item input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .filter-item select:disabled {
            background: #f5f5f5;
            cursor: not-allowed;
        }
        
        .search-box {
            position: relative;
        }
        
        .search-box input {
            width: 100%;
            padding: 10px 35px 10px 15px;
        }
        
        .search-box button {
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            padding: 5px;
        }
        
        .search-box img {
            width: 18px;
            height: 18px;
            opacity: 0.5;
        }
        
        .filter-actions {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        
        .results-table-container {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow-x: auto;
        }
        
        .results-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            border: 1px solid #dee2e6;
        }
        
        .results-table th {
            background: #33564f;
            color: white;
            padding: 10px 5px;
            text-align: center;
            font-weight: 600;
            border: 1px solid #5a67d8;
            white-space: nowrap;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        
        .results-table td {
            padding: 8px 5px;
            border: 1px solid #dee2e6;
            vertical-align: middle;
            text-align: center;
        }
        
        .results-table tbody tr:hover {
            background: #f8f9fa;
        }
        
        .student-info {
            text-align: left;
        }
        
        .student-name {
            font-weight: 600;
            color: #333;
            font-size: 12px;
        }
        
        .student-roll {
            font-size: 11px;
            color: #666;
        }
        
        .subject-result {
            font-size: 12px;
        }
        
        .marks-display {
            font-weight: 600;
        }
        
        .marks-high {
            color: #28a745;
        }
        
        .marks-medium {
            color: #f0ad4e;
        }
        
        .marks-low {
            color: #dc3545;
        }
        
        .badge {
            display: inline-block;
            padding: 3px 6px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 700;
        }
        
        .grade-A-plus { background: #28a745; color: white; }
        .grade-A { background: #5cb85c; color: white; }
        .grade-B-plus { background: #5bc0de; color: white; }
        .grade-B { background: #f0ad4e; color: white; }
        .grade-C-plus { background: #d9534f; color: white; }
        .grade-C { background: #d9534f; color: white; }
        .grade-D { background: #d9534f; color: white; }
        .grade-F { background: #dc3545; color: white; }
        
        .action-buttons {
            display: flex;
            gap: 5px;
            justify-content: center;
            align-items: center;
        }
        
        .action-btn {
            padding: 4px 8px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 11px;
            font-weight: 600;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 3px;
            border: none;
            cursor: pointer;
        }
        
        .action-btn img {
            width: 12px;
            height: 12px;
        }
        
        .btn-print-action {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .btn-print-action:hover {
            background: #c8e6c9;
        }
        
        .btn-delete {
            background: #ffebee;
            color: #c62828;
        }
        
        .btn-delete:hover {
            background: #ffcdd2;
        }
        
        .btn-view {
            background: #e3f2fd;
            color: #1565c0;
        }
        
        .btn-view:hover {
            background: #bbdefb;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 30px;
            flex-wrap: wrap;
        }
        
        .pagination a, .pagination span {
            padding: 8px 14px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            text-decoration: none;
            color: #667eea;
            transition: all 0.3s;
            font-size: 14px;
        }
        
        .pagination a:hover {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        
        .pagination a.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        
        .pagination span.disabled {
            color: #999;
            background: #f5f5f5;
            cursor: not-allowed;
        }
        
        .print-button-container {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }
        
        .btn-print {
            background: #667eea;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-print:hover {
            background: #5a67d8;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(102, 126, 234, 0.3);
        }
        
        .btn-print img {
            width: 18px;
            height: 18px;
            filter: brightness(0) invert(1);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .empty-state img {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .empty-state h3 {
            color: #333;
            margin-bottom: 10px;
            font-size: 20px;
        }
        
        .empty-state p {
            color: #666;
            margin-bottom: 20px;
        }
        
        .select-filters-message {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .select-filters-message img {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .select-filters-message h3 {
            color: #333;
            margin-bottom: 10px;
            font-size: 20px;
        }
        
        .select-filters-message p {
            color: #666;
        }
        
        .stats-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .stats-info .total-count {
            font-size: 14px;
            color: #666;
        }
        
        .stats-info .total-count strong {
            color: #667eea;
            font-size: 18px;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .subject-header {
            font-size: 11px;
            line-height: 1.2;
        }
        
        .subject-code {
            font-size: 9px;
            opacity: 0.9;
        }
        
        .total-row {
            background: #e8f4f8;
            font-weight: 600;
        }
        
        .exam-info {
            font-size: 11px;
            color: #666;
            margin-top: 2px;
        }
        
        /* A4 Print Styles */
        @media print {
            @page {
                size: A4 landscape;
                margin: 0.5cm;
            }
            
            body {
                background: white;
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
            }
            
            .no-print {
                display: none !important;
            }
            
            .results-table-container {
                box-shadow: none;
                padding: 0;
                margin: 0;
                width: 100%;
            }
            
            .results-table {
                width: 100%;
                border-collapse: collapse;
                font-size: 8pt;
                table-layout: fixed;
            }
            
            .results-table th {
                background: #101c8c !important;
                color: white !important;
                padding: 4px 2px;
                font-size: 8pt;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .results-table td {
                padding: 3px 2px;
                font-size: 8pt;
            }
            
            .badge {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                padding: 1px 3px;
                font-size: 7pt;
            }
            
            .print-header {
                display: block !important;
                text-align: center;
                margin-bottom: 10px;
                border-bottom: 2px solid #333;
                padding-bottom: 5px;
            }
            
            .print-header h1 {
                font-size: 14pt;
                margin: 0;
            }
            
            .print-header p {
                font-size: 8pt;
                margin: 3px 0 0;
            }
            
            .print-footer {
                display: block !important;
                text-align: center;
                margin-top: 10px;
                padding-top: 5px;
                border-top: 1px solid #ccc;
                font-size: 7pt;
                color: #666;
            }
            
            .action-buttons {
                display: none !important;
            }
        }
        
        .print-header, .print-footer {
            display: none;
        }
        
        @media (max-width: 768px) {
            .filter-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-actions {
                flex-direction: column;
            }
            
            .results-table-container {
                overflow-x: scroll;
            }
        }
        
        /* Confirmation Dialog Styles */
        .delete-confirm-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            display: none;
        }
        
        .delete-confirm-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
            max-width: 400px;
            width: 90%;
            text-align: center;
        }
        
        .delete-confirm-box h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 20px;
        }
        
        .delete-confirm-box p {
            color: #666;
            margin-bottom: 25px;
            font-size: 14px;
        }
        
        .delete-confirm-actions {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        
        .btn-confirm-delete {
            background: #dc3545;
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn-confirm-delete:hover {
            background: #c82333;
        }
        
        .btn-cancel-delete {
            background: #6c757d;
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn-cancel-delete:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar no-print">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                <a href="adminDashboard.php"><img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5></a>
                <a href="departments.php"><img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5></a>
                <a href="courses.php"><img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5></a>
                <a href="subjects.php"><img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5></a>
                <a href="teachers.php"><img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5></a>
                <a href="students.php"><img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5></a>
                <a href="allocations.php"><img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5></a>
                <a href="exams.php"><img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5></a>
                <a href="results.php" class="active"><img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5></a>
                <a href="feedbacks.php"><img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5></a>
                <a href="settings.php"><img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5></a>
                <a href="../logout.php"><img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5></a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type'] == 'success' ? 'success' : 'error'; ?> no-print">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <h1 class="no-print"><img src="../icons/result.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Manage Results</h1>
            
            <!-- Filters Section -->
            <div class="filters-section no-print">
                <form method="GET" action="results.php" id="filterForm">
                    <div class="filter-grid">
                        <div class="filter-item">
                            <label>Department</label>
                            <select name="dept_id" id="dept_filter">
                                <option value="0">All Departments</option>
                                <?php 
                                if ($departments && $departments->num_rows > 0) {
                                    $departments->data_seek(0);
                                    while($dept = $departments->fetch_assoc()) { 
                                        $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                                        echo '<option value="' . $dept['dept_id'] . '" ' . $selected . '>' . htmlspecialchars($dept['dept_name']) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label>Course</label>
                            <select name="course_id" id="course_filter" <?php echo $dept_filter == 0 ? 'disabled' : ''; ?>>
                                <option value="0">Select Course</option>
                                <?php 
                                if ($filter_courses && $filter_courses->num_rows > 0) {
                                    $filter_courses->data_seek(0);
                                    while($course = $filter_courses->fetch_assoc()) { 
                                        $selected = ($course_filter == $course['course_id']) ? 'selected' : '';
                                        echo '<option value="' . $course['course_id'] . '" ' . $selected . '>' . htmlspecialchars($course['course_name']) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label>Exam</label>
                            <select name="exam_id" id="exam_filter">
                                <option value="0">All Exams</option>
                                <?php 
                                if ($exams && $exams->num_rows > 0) {
                                    $exams->data_seek(0);
                                    while($exam = $exams->fetch_assoc()) { 
                                        $selected = ($exam_filter == $exam['exam_id']) ? 'selected' : '';
                                        echo '<option value="' . $exam['exam_id'] . '" ' . $selected . '>' . htmlspecialchars($exam['exam_name']) . ' (' . $exam['exam_type'] . ')</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label>Semester</label>
                            <select name="semester" id="semester_filter">
                                <option value="0">Select Semester</option>
                                <?php for($i = 1; $i <= 8; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo ($semester_filter == $i) ? 'selected' : ''; ?>>
                                        Semester <?php echo $i; ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label>Section</label>
                            <select name="section" id="section_filter">
                                <option value="">All Sections</option>
                                <?php 
                                if ($sections && $sections->num_rows > 0) {
                                    $sections->data_seek(0);
                                    while($section = $sections->fetch_assoc()) { 
                                        $selected = ($section_filter == $section['section']) ? 'selected' : '';
                                        echo '<option value="' . htmlspecialchars($section['section']) . '" ' . $selected . '>Section ' . htmlspecialchars($section['section']) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item search-box">
                            <label>Search Student</label>
                            <input type="text" name="search" placeholder="Search by roll or name..." value="<?php echo htmlspecialchars($search_query); ?>">
                            <button type="submit"><img src="../icons/search.png" alt="Search"></button>
                        </div>
                        
                        <div class="filter-actions">
                            <?php if($has_filters): ?>
                            <a href="results.php" class="btn btn-secondary" style="padding: 10px 20px;">Clear Filters</a>
                            <?php endif; ?>
                            
                        </div>
                    </div>
                    <div class="filter-note" style="margin-top: 10px; color: #666; font-size: 13px; text-align: center;">
                        <strong></strong>
                    </div>
                </form>
            </div>
            
            <?php if($has_filters): ?>
                
                <?php if($course_filter > 0 && $semester_filter > 0): ?>
                
                    <?php if(!empty($results) && count($results) > 0): ?>
                    
                    <div class="stats-info no-print">
                        <div class="total-count">
                            Total Students: <strong><?php echo $total_rows; ?></strong>
                        </div>
                        <div>
                            Exam: <strong><?php echo $exam_filter > 0 ? 'Selected' : 'All Exams'; ?></strong> | 
                            Semester: <strong><?php echo $semester_filter; ?></strong> |
                            Page <strong><?php echo $page; ?></strong> of <strong><?php echo $total_pages; ?></strong>
                        </div>
                    </div>
                    
                    <div class="print-button-container no-print">
                        <button class="btn-print" onclick="window.print()">
                            <img src="../icons/print.png" alt="Print"> Print Results
                        </button>
                    </div>
                    
                    <!-- Print Header (only visible when printing) -->
                    <div class="print-header">
                        <h1>Student Results</h1>
                        <p>Generated on: <?php echo date('F j, Y'); ?> | 
                           Department: <?php echo $dept_filter > 0 ? 'Selected' : 'All'; ?> |
                           Course: <?php echo $course_filter > 0 ? 'Selected' : 'All'; ?> |
                           Semester: <?php echo $semester_filter; ?> |
                           Exam: <?php echo $exam_filter > 0 ? 'Selected' : 'All'; ?>
                        </p>
                    </div>
                    
                    <div class="results-table-container">
                        <table class="results-table">
                            <thead>
                                <tr>
                                    <th rowspan="2">S.No</th>
                                    <th rowspan="2">Roll No</th>
                                    <th rowspan="2">Student Name</th>
                                    <th rowspan="2">Section</th>
                                    <?php foreach($all_subjects as $subject): ?>
                                    <th colspan="2" class="subject-header">
                                        <?php echo htmlspecialchars($subject['subject_name']); ?>
                                        <div class="subject-code"><?php echo htmlspecialchars($subject['subject_code']); ?></div>
                                    </th>
                                    <?php endforeach; ?>
                                    <th rowspan="2">Total</th>
                                    <th rowspan="2">Grade</th>
                                    <th rowspan="2" class="no-print">Actions</th>
                                </tr>
                                <tr>
                                    <?php foreach($all_subjects as $subject): ?>
                                    <th>Marks</th>
                                    <th>Grade</th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $sno = ($page - 1) * 20 + 1;
                                foreach($results as $student): 
                                ?>
                                <tr>
                                    <td><?php echo $sno++; ?></td>
                                    <td><strong><?php echo htmlspecialchars($student['roll_number']); ?></strong></td>
                                    <td class="student-info">
                                        <div class="student-name">
                                            <?php 
                                            $full_name = $student['first_name'];
                                            if (!empty($student['middle_name'])) {
                                                $full_name .= ' ' . $student['middle_name'];
                                            }
                                            $full_name .= ' ' . $student['last_name'];
                                            echo htmlspecialchars($full_name);
                                            ?>
                                        </div>
                                        <?php if(!empty($student['exam_name'])): ?>
                                        <div class="exam-info"><?php echo htmlspecialchars($student['exam_name']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $student['section'] ? $student['section'] : '-'; ?></td>
                                    
                                    <?php 
                                    $student_total = 0;
                                    $student_full = 0;
                                    $has_any_result = false;
                                    
                                    foreach($all_subjects as $subject):
                                        $subject_id = $subject['subject_id'];
                                        $subject_data = isset($student['subjects'][$subject_id]) ? $student['subjects'][$subject_id] : null;
                                        
                                        if ($subject_data && ($subject_data['theory_marks'] !== null || $subject_data['practical_marks'] !== null)) {
                                            $has_any_result = true;
                                            $theory = $subject_data['theory_marks'] ?? 0;
                                            $practical = $subject_data['practical_marks'] ?? 0;
                                            $theory_full = $subject_data['theory_full_marks'] ?? 60;
                                            $practical_full = $subject_data['practical_full_marks'] ?? 40;
                                            $subject_total = $theory + $practical;
                                            $subject_full = $theory_full + $practical_full;
                                            
                                            $student_total += $subject_total;
                                            $student_full += $subject_full;
                                            
                                            $marks_class = '';
                                            if($subject_total >= ($subject_full * 0.75)) $marks_class = 'marks-high';
                                            elseif($subject_total >= ($subject_full * 0.5)) $marks_class = 'marks-medium';
                                            else $marks_class = 'marks-low';
                                    ?>
                                        <td class="subject-result">
                                            <div class="marks-display <?php echo $marks_class; ?>">
                                                <?php echo $subject_total . '/' . $subject_full; ?>
                                            </div>
                                            <div style="font-size: 9px; color: #666;">
                                                T:<?php echo $theory; ?> P:<?php echo $practical; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if($subject_data['grade']): ?>
                                            <span class="badge grade-<?php echo strtolower(str_replace('+', '-plus', $subject_data['grade'])); ?>">
                                                <?php echo $subject_data['grade']; ?>
                                            </span>
                                            <?php else: ?>
                                            -
                                            <?php endif; ?>
                                        </td>
                                    <?php 
                                        } else {
                                    ?>
                                        <td>-</td>
                                        <td>-</td>
                                    <?php 
                                        }
                                    endforeach; 
                                    ?>
                                    
                                    <td class="total-row">
                                        <?php if($has_any_result): ?>
                                        <strong><?php echo $student_total . '/' . $student_full; ?></strong>
                                        <?php else: ?>
                                        -
                                        <?php endif; ?>
                                    </td>
                                    <td class="total-row">
                                        <?php 
                                        if($has_any_result && $student_full > 0) {
                                            $percentage = ($student_total / $student_full) * 100;
                                            $overall_grade = '';
                                            
                                            if($percentage >= 90) $overall_grade = 'A+';
                                            elseif($percentage >= 80) $overall_grade = 'A';
                                            elseif($percentage >= 70) $overall_grade = 'B+';
                                            elseif($percentage >= 60) $overall_grade = 'B';
                                            elseif($percentage >= 50) $overall_grade = 'C+';
                                            elseif($percentage >= 40) $overall_grade = 'C';
                                            elseif($percentage >= 35) $overall_grade = 'D';
                                            else $overall_grade = 'F';
                                        ?>
                                            <span class="badge grade-<?php echo strtolower(str_replace('+', '-plus', $overall_grade)); ?>">
                                                <?php echo $overall_grade; ?>
                                            </span>
                                        <?php 
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </td>
                                    <td class="no-print">
                                        <div class="action-buttons">
                                            <?php if($has_any_result): ?>
                                            <button onclick="printStudentResults(<?php echo $student['student_id']; ?>, <?php echo $exam_filter; ?>)" 
                                                    class="action-btn btn-print-action" title="Print All Results">
                                                <img src="../icons/print.png" alt="Print"> Print
                                            </button>
                                            <?php if(!empty($student['result_ids'])): ?>
                                            <button onclick="confirmDelete(<?php echo $student['result_ids'][0]; ?>)" 
                                                    class="action-btn btn-delete" title="Delete Result">
                                                <img src="../icons/delete.png" alt="Delete"> Delete
                                            </button>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <?php if($total_pages > 1): ?>
                        <div class="pagination no-print">
                            <?php
                            // Build query string for pagination links
                            $query_params = [];
                            if ($dept_filter > 0) $query_params[] = "dept_id=$dept_filter";
                            if ($course_filter > 0) $query_params[] = "course_id=$course_filter";
                            if ($exam_filter > 0) $query_params[] = "exam_id=$exam_filter";
                            if ($semester_filter > 0) $query_params[] = "semester=$semester_filter";
                            if (!empty($section_filter)) $query_params[] = "section=" . urlencode($section_filter);
                            if (!empty($search_query)) $query_params[] = "search=" . urlencode($search_query);
                            
                            $query_string = !empty($query_params) ? '&' . implode('&', $query_params) : '';
                            ?>
                            
                            <?php if($page > 1): ?>
                                <a href="?page=<?php echo ($page - 1) . $query_string; ?>">« Previous</a>
                            <?php else: ?>
                                <span class="disabled">« Previous</span>
                            <?php endif; ?>
                            
                            <?php
                            $start_page = max(1, $page - 2);
                            $end_page = min($total_pages, $page + 2);
                            
                            if ($start_page > 1) {
                                echo '<a href="?page=1' . $query_string . '">1</a>';
                                if ($start_page > 2) {
                                    echo '<span>...</span>';
                                }
                            }
                            
                            for ($i = $start_page; $i <= $end_page; $i++) {
                                if ($i == $page) {
                                    echo '<a href="?page=' . $i . $query_string . '" class="active">' . $i . '</a>';
                                } else {
                                    echo '<a href="?page=' . $i . $query_string . '">' . $i . '</a>';
                                }
                            }
                            
                            if ($end_page < $total_pages) {
                                if ($end_page < $total_pages - 1) {
                                    echo '<span>...</span>';
                                }
                                echo '<a href="?page=' . $total_pages . $query_string . '">' . $total_pages . '</a>';
                            }
                            ?>
                            
                            <?php if($page < $total_pages): ?>
                                <a href="?page=<?php echo ($page + 1) . $query_string; ?>">Next »</a>
                            <?php else: ?>
                                <span class="disabled">Next »</span>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Print Footer (only visible when printing) -->
                    <div class="print-footer">
                        <p>This is demonstrated program for Student Result Management System - SRMS.</p>
                        <p>Prepared By Bimal Acharya & Albert Bantawa.</p>
                    </div>
                    
                    <?php else: ?>
                    <div class="empty-state no-print">
                        <img src="../icons/empty.png" alt="No Results">
                        <h3>No Students Found</h3>
                        <p>No students match your current filter criteria. Try adjusting your filters.</p>
                        <a href="results.php" class="btn btn-secondary">Clear All Filters</a>
                    </div>
                    <?php endif; ?>
                
                <?php else: ?>
                <div class="select-filters-message no-print">
                    <img src="../icons/empty.png" alt="Select Filters">
                    <h3>Select Course and Semester</h3>
                    <p>Please select both Course and Semester</p>
                </div>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="select-filters-message no-print">
                    <img src="../icons/empty.png" alt="Select Filters">
                    <h3>Select Filters to View Results</h3>
                    <p>Please select department, course, exam, semester, and other filters to view results</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteConfirmOverlay" class="delete-confirm-overlay">
        <div class="delete-confirm-box">
            <h3>Confirm Delete</h3>
            <p>Are you sure you want to delete this result? This action cannot be undone.</p>
            <div class="delete-confirm-actions">
                <button id="confirmDeleteBtn" class="btn-confirm-delete">Delete</button>
                <button id="cancelDeleteBtn" class="btn-cancel-delete">Cancel</button>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Handle filter changes
        document.getElementById('dept_filter').addEventListener('change', function() {
            document.getElementById('filterForm').submit();
        });
        
        document.getElementById('course_filter').addEventListener('change', function() {
            document.getElementById('filterForm').submit();
        });
        
        document.getElementById('exam_filter').addEventListener('change', function() {
            document.getElementById('filterForm').submit();
        });
        
        document.getElementById('semester_filter').addEventListener('change', function() {
            document.getElementById('filterForm').submit();
        });
        
        document.getElementById('section_filter').addEventListener('change', function() {
            document.getElementById('filterForm').submit();
        });
        
        // Search with debounce
        let searchTimeout;
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) {
            searchInput.addEventListener('keyup', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    document.getElementById('filterForm').submit();
                }, 500);
            });
        }
        
        // Delete confirmation variables
        let deleteResultId = null;
        const overlay = document.getElementById('deleteConfirmOverlay');
        const confirmBtn = document.getElementById('confirmDeleteBtn');
        const cancelBtn = document.getElementById('cancelDeleteBtn');
        
        // Show delete confirmation
        function confirmDelete(resultId) {
            deleteResultId = resultId;
            overlay.style.display = 'flex';
        }
        
        // Handle confirm delete
        confirmBtn.addEventListener('click', function() {
            if (deleteResultId) {
                const urlParams = new URLSearchParams(window.location.search);
                urlParams.set('delete', deleteResultId);
                window.location.href = 'results.php?' + urlParams.toString();
            }
        });
        
        // Handle cancel delete
        cancelBtn.addEventListener('click', function() {
            overlay.style.display = 'none';
            deleteResultId = null;
        });
        
        // Close overlay when clicking outside
        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                overlay.style.display = 'none';
                deleteResultId = null;
            }
        });
        
        // Print all results for a student
        function printStudentResults(studentId, examId) {
            const url = `results.php?ajax=get_result_details&student_id=${studentId}&exam_id=${examId}`;
            
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const student = data.student;
                        const subjects = data.subjects;
                        const examInfo = data.exam_info;
                        const totals = data.totals;
                        
                        const printWindow = window.open('', '_blank');
                        
                        // Format full name
                        const fullName = student.full_name;
                        
                        // Calculate overall percentage and grade
                        const percentage = (totals.obtained / totals.full) * 100;
                        let overallGrade = '';
                        
                        if (percentage >= 90) overallGrade = 'A+';
                        else if (percentage >= 80) overallGrade = 'A';
                        else if (percentage >= 70) overallGrade = 'B+';
                        else if (percentage >= 60) overallGrade = 'B';
                        else if (percentage >= 50) overallGrade = 'C+';
                        else if (percentage >= 40) overallGrade = 'C';
                        else if (percentage >= 35) overallGrade = 'D';
                        else overallGrade = 'F';
                        
                        printWindow.document.write(`
                            <!DOCTYPE html>
                            <html>
                            <head>
                                <title>Results - ${fullName}</title>
                                <style>
                                    @page {
                                        size: A4 landscape;
                                        margin: 1cm;
                                    }
                                    body {
                                        font-family: Arial, sans-serif;
                                        margin: 0;
                                        padding: 20px;
                                        line-height: 1.4;
                                    }
                                    .header {
                                        text-align: center;
                                        margin-bottom: 30px;
                                        border-bottom: 2px solid #333;
                                        padding-bottom: 10px;
                                    }
                                    .header h1 {
                                        margin: 0;
                                        color: #333;
                                        font-size: 18pt;
                                    }
                                    .header p {
                                        margin: 5px 0 0;
                                        color: #666;
                                        font-size: 10pt;
                                    }
                                    .student-info {
                                        background: #f8f9fa;
                                        padding: 15px;
                                        border-radius: 8px;
                                        margin-bottom: 20px;
                                    }
                                    .info-grid {
                                        display: grid;
                                        grid-template-columns: repeat(3, 1fr);
                                        gap: 15px;
                                    }
                                    .info-item {
                                        margin-bottom: 10px;
                                    }
                                    .info-label {
                                        font-size: 9pt;
                                        color: #666;
                                        margin-bottom: 3px;
                                    }
                                    .info-value {
                                        font-size: 11pt;
                                        font-weight: 600;
                                        color: #333;
                                    }
                                    .marks-table {
                                        width: 100%;
                                        border-collapse: collapse;
                                        margin-top: 20px;
                                        font-size: 10pt;
                                    }
                                    .marks-table th {
                                        background: #140cb8;
                                        color: white;
                                        padding: 10px;
                                        text-align: left;
                                        font-weight: 600;
                                        -webkit-print-color-adjust: exact;
                                        print-color-adjust: exact;
                                    }
                                    .marks-table td {
                                        padding: 8px 10px;
                                        border-bottom: 1px solid #ddd;
                                    }
                                    .marks-table .total-row {
                                        background: #f8f9fa;
                                        font-weight: 600;
                                    }
                                    .grade-badge {
                                        display: inline-block;
                                        padding: 4px 10px;
                                        border-radius: 20px;
                                        font-weight: 600;
                                        font-size: 10pt;
                                        -webkit-print-color-adjust: exact;
                                        print-color-adjust: exact;
                                    }
                                    .grade-A-plus, .grade-A { background: #28a745; color: white; }
                                    .grade-B-plus, .grade-B { background: #5bc0de; color: white; }
                                    .grade-C-plus, .grade-C, .grade-D { background: #d9534f; color: white; }
                                    .grade-F { background: #dc3545; color: white; }
                                    .remarks {
                                        margin-top: 20px;
                                        padding: 10px;
                                        background: #fff3cd;
                                        border-radius: 8px;
                                        font-size: 10pt;
                                    }
                                    .footer {
                                        margin-top: 30px;
                                        text-align: center;
                                        color: #666;
                                        font-size: 9pt;
                                        border-top: 1px solid #ccc;
                                        padding-top: 10px;
                                    }
                                    @media print {
                                        body {
                                            padding: 0;
                                        }
                                        .no-print {
                                            display: none;
                                        }
                                    }
                                </style>
                            </head>
                            <body>
                                <div class="header">
                                    <h1>Student Results</h1>
                                    <p>Generated on: ${new Date().toLocaleDateString()}</p>
                                </div>
                                
                                <div class="student-info">
                                    <div class="info-grid">
                                        <div class="info-item">
                                            <div class="info-label">Student Name</div>
                                            <div class="info-value">${fullName}</div>
                                        </div>
                                        <div class="info-item">
                                            <div class="info-label">Roll Number</div>
                                            <div class="info-value">${student.roll_number}</div>
                                        </div>
                                        <div class="info-item">
                                            <div class="info-label">Department</div>
                                            <div class="info-value">${student.dept_name}</div>
                                        </div>
                                        <div class="info-item">
                                            <div class="info-label">Course</div>
                                            <div class="info-value">${student.course_name}</div>
                                        </div>
                                        <div class="info-item">
                                            <div class="info-label">Section</div>
                                            <div class="info-value">${student.section ? 'Section ' + student.section : 'N/A'}</div>
                                        </div>
                                        <div class="info-item">
                                            <div class="info-label">Exam</div>
                                            <div class="info-value">${examInfo ? examInfo.exam_name + ' (' + examInfo.exam_type + ')' : 'All Exams'}</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <h3 style="font-size: 12pt; margin: 10px 0;">Subject-wise Marks</h3>
                                
                                <table class="marks-table">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Subject Code</th>
                                            <th>Subject Name</th>
                                            <th>Semester</th>
                                            <th>Theory</th>
                                            <th>Practical</th>
                                            <th>Total</th>
                                            <th>Grade</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                        `);
                        
                        let sno = 1;
                        subjects.forEach(subject => {
                            const theoryFull = subject.theory_full_marks || 60;
                            const practicalFull = subject.practical_full_marks || 40;
                            const theoryObtained = subject.theory_marks || 0;
                            const practicalObtained = subject.practical_marks || 0;
                            const theoryPass = subject.theory_pass_marks || 24;
                            const practicalPass = subject.practical_pass_marks || 18;
                            const totalObtained = theoryObtained + practicalObtained;
                            const totalFull = theoryFull + practicalFull;
                            
                            const theoryPassed = theoryObtained >= theoryPass;
                            const practicalPassed = practicalFull == 0 || practicalObtained >= practicalPass;
                            const overallPassed = theoryPassed && practicalPassed;
                            
                            printWindow.document.write(`
                                <tr>
                                    <td>${sno++}</td>
                                    <td><strong>${subject.subject_code}</strong></td>
                                    <td>${subject.subject_name}</td>
                                    <td>Semester ${subject.semester_number}</td>
                                    <td>${theoryObtained}/${theoryFull}</td>
                                    <td>${practicalFull > 0 ? practicalObtained + '/' + practicalFull : '-'}</td>
                                    <td><strong>${theoryObtained}/100</strong></td>
                                    <td>
                                        <span class="grade-badge grade-${subject.grade}">${subject.grade}</span>
                                    </td>
                                    <td>${overallPassed ? 'Pass' : 'Fail'}</td>
                                </tr>
                            `);
                        });
                        
                        printWindow.document.write(`
                                        <tr class="total-row">
                                            <td colspan="6" style="text-align: right;"><strong>Grand Total:</strong></td>
                                            <td><strong>${totals.obtained}/${totals.full}</strong></td>
                                            <td>
                                                <span class="grade-badge grade-${overallGrade}">${overallGrade}</span>
                                            </td>
                                            <td>${totals.obtained >= (totals.full * 0.4) ? 'Pass' : 'Fail'}</td>
                                        </tr>
                                    </tbody>
                                </table>
                        `);
                        
                        // Collect all remarks
                        const remarks = subjects.filter(s => s.remarks).map(s => s.remarks);
                        if (remarks.length > 0) {
                            printWindow.document.write(`
                                <div class="remarks">
                                    <strong>Remarks:</strong> ${remarks.join('; ')}
                                </div>
                            `);
                        }
                        
                        printWindow.document.write(`
                                <div class="footer">
                                    <p>This is demonstrated program for Student Result Management System - SRMS.</p>
                                    <p>Prepared By Bimal Acharya & Albert Bantawa.</p>
                                </div>
                            </body>
                            </html>
                        `);
                        
                        printWindow.document.close();
                        printWindow.focus();
                        
                        // Trigger print after content is loaded
                        setTimeout(() => {
                            printWindow.print();
                        }, 500);
                    } else {
                        alert('Error loading result details for printing: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error loading result details for printing.');
                });
        }
    </script>
</body>
</html>