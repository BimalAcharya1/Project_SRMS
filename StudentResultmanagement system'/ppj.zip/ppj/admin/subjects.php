<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Handle Add/Edit/Delete operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add') {
            $subject_name = $database->escapeString($_POST['subject_name']);
            $subject_code = $database->escapeString($_POST['subject_code']);
            $credit_hours = $_POST['credit_hours'];
            $semester_number = $_POST['semester_number'];
            $course_id = $_POST['course_id'];
            $subject_type = $_POST['subject_type'];
            
            // Check if subject name already exists in the same course
            $check_name = $conn->query("SELECT subject_id FROM Subject WHERE subject_name = '$subject_name' AND course_id = $course_id");
            if ($check_name->num_rows > 0) {
                $_SESSION['message'] = "Subject name already exists in this course! Please use a different name.";
                $_SESSION['msg_type'] = "error";
                header("Location: subjects.php");
                exit();
            }
            
            // Check if subject code already exists
            $check_code = $conn->query("SELECT subject_id FROM Subject WHERE subject_code = '$subject_code'");
            if ($check_code->num_rows > 0) {
                $_SESSION['message'] = "Subject code already exists! Please use a different code.";
                $_SESSION['msg_type'] = "error";
                header("Location: subjects.php");
                exit();
            }
            
            $sql = "INSERT INTO Subject (subject_name, subject_code, credit_hours, semester_number, course_id, subject_type) 
                    VALUES ('$subject_name', '$subject_code', $credit_hours, $semester_number, $course_id, '$subject_type')";
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Subject added successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
        }
        
        elseif ($action == 'edit') {
            $subject_id = $_POST['subject_id'];
            $subject_name = $database->escapeString($_POST['subject_name']);
            $subject_code = $database->escapeString($_POST['subject_code']);
            $credit_hours = $_POST['credit_hours'];
            $semester_number = $_POST['semester_number'];
            $course_id = $_POST['course_id'];
            $subject_type = $_POST['subject_type'];
            
            // Check if subject name already exists in the same course for another subject
            $check_name = $conn->query("SELECT subject_id FROM Subject WHERE subject_name = '$subject_name' AND course_id = $course_id AND subject_id != $subject_id");
            if ($check_name->num_rows > 0) {
                $_SESSION['message'] = "Subject name already exists in this course! Please use a different name.";
                $_SESSION['msg_type'] = "error";
                header("Location: subjects.php");
                exit();
            }
            
            // Check if subject code already exists for another subject
            $check_code = $conn->query("SELECT subject_id FROM Subject WHERE subject_code = '$subject_code' AND subject_id != $subject_id");
            if ($check_code->num_rows > 0) {
                $_SESSION['message'] = "Subject code already exists! Please use a different code.";
                $_SESSION['msg_type'] = "error";
                header("Location: subjects.php");
                exit();
            }
            
            $sql = "UPDATE Subject SET 
                    subject_name='$subject_name', 
                    subject_code='$subject_code', 
                    credit_hours=$credit_hours, 
                    semester_number=$semester_number, 
                    course_id=$course_id,
                    subject_type='$subject_type'
                    WHERE subject_id=$subject_id";
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Subject updated successfully!";
                $_SESSION['msg_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['msg_type'] = "error";
            }
        }
        
        elseif ($action == 'delete') {
    $subject_id = $_POST['subject_id'];
    
    // Optional: Show warning message about cascade delete
    $_SESSION['message'] = "Subject deleted successfully! All associated teacher allocations, exam subjects, results, and student subject registrations have been removed.";
    $_SESSION['msg_type'] = "success";
    
    // Simple delete - cascade will handle everything
    $sql = "DELETE FROM Subject WHERE subject_id=$subject_id";
    
    if ($conn->query($sql)) {
        $_SESSION['message'] = "Subject deleted successfully! All associated teacher allocations, exam subjects, results, and student subject registrations have been removed.";
        $_SESSION['msg_type'] = "success";
    } else {
        $_SESSION['message'] = "Error: " . $conn->error;
        $_SESSION['msg_type'] = "error";
    }
}
        
        header("Location: subjects.php");
        exit();
    }
}

// Handle AJAX validation requests
if (isset($_GET['ajax']) && $_GET['ajax'] == 'validate') {
    $field = $_GET['field'];
    $value = $database->escapeString($_GET['value']);
    $course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
    $current_id = isset($_GET['current_id']) ? intval($_GET['current_id']) : 0;
    
    $response = ['valid' => true, 'message' => ''];
    
    if ($field == 'subject_name') {
        if ($course_id > 0) {
            $query = "SELECT subject_id FROM Subject WHERE subject_name = '$value' AND course_id = $course_id";
            if ($current_id > 0) {
                $query .= " AND subject_id != $current_id";
            }
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                $response['valid'] = false;
                $response['message'] = 'Subject name already exists in this course';
            }
        } else {
            $response['valid'] = false;
            $response['message'] = 'Please select a course first';
        }
    }
    elseif ($field == 'subject_code') {
        $query = "SELECT subject_id FROM Subject WHERE subject_code = '$value'";
        if ($current_id > 0) {
            $query .= " AND subject_id != $current_id";
        }
        $result = $conn->query($query);
        if ($result->num_rows > 0) {
            $response['valid'] = false;
            $response['message'] = 'Subject code already exists';
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Handle filters
$dept_filter = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;
$course_filter = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

// Build query with filters
$subject_query = "
    SELECT s.*, c.course_name, d.dept_name, d.dept_id as filter_dept_id
    FROM Subject s
    LEFT JOIN Course c ON s.course_id = c.course_id
    LEFT JOIN Department d ON c.dept_id = d.dept_id
    WHERE 1=1
";

if ($dept_filter > 0) {
    $subject_query .= " AND c.dept_id = $dept_filter";
}

if ($course_filter > 0) {
    $subject_query .= " AND s.course_id = $course_filter";
}

$subject_query .= " ORDER BY d.dept_name, c.course_name, s.semester_number, s.subject_name";
$subjects = $conn->query($subject_query);

// Get departments for filter dropdown
$departments = $conn->query("SELECT * FROM Department ORDER BY dept_name");

// Get courses based on selected department for filter dropdown
$course_filter_query = "SELECT c.*, d.dept_name FROM Course c LEFT JOIN Department d ON c.dept_id = d.dept_id";
if ($dept_filter > 0) {
    $course_filter_query .= " WHERE c.dept_id = $dept_filter";
}
$course_filter_query .= " ORDER BY c.course_name";
$filter_courses = $conn->query($course_filter_query);

// Get all courses for forms
$all_courses = $conn->query("SELECT c.*, d.dept_name FROM Course c LEFT JOIN Department d ON c.dept_id = d.dept_id ORDER BY d.dept_name, c.course_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Manage Subjects - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Additional styles for validation */
        .validation-message {
            font-size: 12px;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .validation-success {
            color: #28a745;
        }
        .validation-error {
            color: #dc3545;
        }
        .validation-spinner {
            display: inline-block;
            width: 12px;
            height: 12px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 5px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .input-error {
            border-color: #dc3545 !important;
        }
        .input-success {
            border-color: #28a745 !important;
        }
        .form-group {
            position: relative;
            margin-bottom: 15px;
        }
        .required-field::after {
            content: " *";
            color: red;
        }
        .badge {
            display: inline-block;
            padding: 3px 7px;
            font-size: 12px;
            font-weight: bold;
            border-radius: 4px;
        }
        .badge-primary {
            background-color: #007bff;
            color: white;
        }
        .badge-success {
            background-color: #28a745;
            color: white;
        }
        .badge-warning {
            background-color: #ffc107;
            color: black;
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        @media (max-width: 768px) {
            .card-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .card-header > div {
                width: 100%;
            }
            #dept_filter, #course_filter {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                   <a href="adminDashboard.php">
            <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
            </a>
               <a href="departments.php">
            <img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5>
            </a>
                <a href="courses.php">
            <img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5>
            </a>
                  <a href="subjects.php" class="active">
            <img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5>
        </a>
          <a href="teachers.php">
            <img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5>
        </a>

         <a href="students.php">
            <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5>
        </a>

        <a href="allocations.php">
            <img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5>
        </a>
        <a href="exams.php">
            <img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5>
        </a>
        <a href="results.php">
            <img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5>
        </a>

        <a href="feedbacks.php">
            <img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5>
        </a>
        <a href="settings.php">
            <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5>
        </a>
        <a href="../logout.php">
            <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5>
        </a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2> <img src="../icons/subject.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Manage Subjects</h2>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <!-- Department Filter Dropdown -->
                        <select id="dept_filter" onchange="filterByDepartment()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 200px;">
                            <option value="0">All Departments</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                                $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $dept['dept_name']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        
                        <!-- Course Filter Dropdown -->
                        <select id="course_filter" onchange="filterByCourse()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 250px;" <?php echo $dept_filter == 0 ? 'disabled' : ''; ?>>
                            <option value="0">All Courses</option>
                            <?php 
                            if($dept_filter > 0):
                                $filter_courses->data_seek(0);
                                while($course = $filter_courses->fetch_assoc()): 
                                    $selected = ($course_filter == $course['course_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $course['course_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $course['course_name']; ?>
                            </option>
                            <?php 
                                endwhile;
                            endif; 
                            ?>
                        </select>
                        
                        <!-- Clear Filters Button -->
                        <?php if($dept_filter > 0 || $course_filter > 0): ?>
                        <button class="btn btn-secondary" onclick="clearFilters()">Clear Filters</button>
                        <?php endif; ?>
                        
                        <button class="btn" onclick="$('#addModal').show()">Add New Subject <img src="../icons/Add.png" style="height: 27px; vertical-align: middle; margin-right: 10px;"></button>
                    </div>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Subject Code</th>
                            <th>Subject Name</th>
                            <th>Type</th>
                            <th>Course</th>
                            <th>Department</th>
                            <th>Semester</th>
                            <th>Credit Hours</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($subjects->num_rows > 0): ?>
                            <?php while($row = $subjects->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['subject_id']; ?></td>
                                <td><strong><?php echo $row['subject_code']; ?></strong></td>
                                <td><?php echo $row['subject_name']; ?></td>
                                <td>
                                    <?php 
                                    $type_class = "";
                                    if($row['subject_type'] == 'Compulsory') {
                                        $type_class = "badge badge-primary";
                                    } elseif($row['subject_type'] == 'Optional') {
                                        $type_class = "badge badge-success";
                                    } elseif($row['subject_type'] == 'Elective') {
                                        $type_class = "badge badge-warning";
                                    }
                                    ?>
                                    <span class="<?php echo $type_class; ?>"><?php echo $row['subject_type']; ?></span>
                                </td>
                                <td>
                                    <a href="?dept_id=<?php echo $row['filter_dept_id']; ?>&course_id=<?php echo $row['course_id']; ?>" style="text-decoration: none; color: inherit;">
                                        <?php echo $row['course_name'] ?? 'N/A'; ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="?dept_id=<?php echo $row['filter_dept_id']; ?>" style="text-decoration: none; color: inherit;">
                                        <?php echo $row['dept_name'] ?? 'N/A'; ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="?<?php echo $dept_filter > 0 ? 'dept_id='.$dept_filter.'&' : ''; ?>semester=<?php echo $row['semester_number']; ?>" style="text-decoration: none; color: inherit;">
                                        Semester <?php echo $row['semester_number']; ?>
                                    </a>
                                </td>
                                <td><?php echo $row['credit_hours']; ?></td>
                                <td>
                                    <button class="action-btn edit-btn" onclick="editSubject(<?php echo htmlspecialchars(json_encode($row)); ?>)" title="Edit"><img src="../icons/Edit.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></button>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this subject? This will also remove it from teacher allocations and exam results.')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="subject_id" value="<?php echo $row['subject_id']; ?>">
                                        <button type="submit" class="action-btn delete-btn" title="Delete"><img src="../icons/Delete.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" style="text-align: center; padding: 20px;">
                                    No subjects found
                                    <?php if($dept_filter > 0 || $course_filter > 0): ?>
                                        with the selected filters. <a href="subjects.php">View all subjects</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Add New Subject</h2>
            <form method="POST" id="addForm" onsubmit="return validateAddForm()">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label class="required-field">Department</label>
                    <select id="add_dept_filter" onchange="filterCoursesByDepartment('add'); validateSubjectName('add'); validateSubjectCode('add');" required>
                        <option value="">--Select Department--</option>
                        <?php 
                        $departments->data_seek(0);
                        while($dept = $departments->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $dept['dept_id']; ?>"><?php echo $dept['dept_name']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Course</label>
                    <select name="course_id" id="add_course_id" required onchange="updateSemesterOptions('add'); validateSubjectName('add'); validateSubjectCode('add');" disabled>
                        <option value="">--Select Department First--</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Semester Number</label>
                    <select name="semester_number" id="add_semester_number" required onchange="validateSubjectName('add'); validateSubjectCode('add');" disabled>
                        <option value="">--Select Course First--</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Subject Type</label>
                    <select name="subject_type" required>
                        <option value="Compulsory">Compulsory</option>
                        <option value="Optional">Optional</option>
                        <option value="Elective">Elective</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Subject Name</label>
                    <input type="text" name="subject_name" id="add_subject_name" placeholder="e.g., Data Structures" required onkeyup="validateSubjectName('add')" onchange="validateSubjectName('add')">
                    <div id="add_subject_name_validation" class="validation-message"></div>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Subject Code</label>
                    <input type="text" name="subject_code" id="add_subject_code" placeholder="e.g., CS301" required onkeyup="validateSubjectCode('add')" onchange="validateSubjectCode('add')">
                    <div id="add_subject_code_validation" class="validation-message"></div>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Credit Hours</label>
                    <input type="number" name="credit_hours" id="add_credit_hours" min="1" max="6" value="3" required>
                </div>
                
                <button type="submit" class="btn" id="add_submit_btn">Add Subject</button>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Edit Subject</h2>
            <form method="POST" id="editForm" onsubmit="return validateEditForm()">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="subject_id" id="edit_subject_id">
                
                <div class="form-group">
                    <label class="required-field">Department</label>
                    <select id="edit_dept_filter" onchange="filterCoursesByDepartment('edit'); validateSubjectName('edit'); validateSubjectCode('edit');" required>
                        <option value="">--Select Department--</option>
                        <?php 
                        $departments->data_seek(0);
                        while($dept = $departments->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $dept['dept_id']; ?>"><?php echo $dept['dept_name']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Course</label>
                    <select name="course_id" id="edit_course_id" required onchange="updateSemesterOptions('edit'); validateSubjectName('edit'); validateSubjectCode('edit');" disabled>
                        <option value="">--Select Department First--</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Semester Number</label>
                    <select name="semester_number" id="edit_semester_number" required onchange="validateSubjectName('edit'); validateSubjectCode('edit');" disabled>
                        <option value="">--Select Course First--</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Subject Type</label>
                    <select name="subject_type" id="edit_subject_type" required>
                        <option value="Compulsory">Compulsory</option>
                        <option value="Optional">Optional</option>
                        <option value="Elective">Elective</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Subject Name</label>
                    <input type="text" name="subject_name" id="edit_subject_name" required onkeyup="validateSubjectName('edit')" onchange="validateSubjectName('edit')">
                    <div id="edit_subject_name_validation" class="validation-message"></div>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Subject Code</label>
                    <input type="text" name="subject_code" id="edit_subject_code" required onkeyup="validateSubjectCode('edit')" onchange="validateSubjectCode('edit')">
                    <div id="edit_subject_code_validation" class="validation-message"></div>
                </div>
                
                <div class="form-group">
                    <label class="required-field">Credit Hours</label>
                    <input type="number" name="credit_hours" id="edit_credit_hours" min="1" max="6" required>
                </div>
                
                <button type="submit" class="btn" id="edit_submit_btn">Update Subject</button>
            </form>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
    // Store courses data for filtering
    var allCourses = [];
    
    <?php 
    $all_courses->data_seek(0);
    while($course = $all_courses->fetch_assoc()): 
    ?>
    allCourses.push({
        id: <?php echo $course['course_id']; ?>,
        name: '<?php echo addslashes($course['course_name']); ?>',
        dept_id: <?php echo $course['dept_id'] ?? 'null'; ?>,
        total_semesters: <?php echo $course['total_semesters']; ?>
    });
    <?php endwhile; ?>
    
    let validationTimeouts = {};
    let validationState = {
        add: { subject_name: true, subject_code: true }, // Changed to true initially
        edit: { subject_name: true, subject_code: true } // Changed to true initially
    };
    
    function filterByDepartment() {
        var deptId = document.getElementById('dept_filter').value;
        var url = 'subjects.php';
        if (deptId > 0) {
            url += '?dept_id=' + deptId;
        }
        window.location.href = url;
    }
    
    function filterByCourse() {
        var deptId = document.getElementById('dept_filter').value;
        var courseId = document.getElementById('course_filter').value;
        var url = 'subjects.php';
        var params = [];
        
        if (deptId > 0) {
            params.push('dept_id=' + deptId);
        }
        if (courseId > 0) {
            params.push('course_id=' + courseId);
        }
        
        if (params.length > 0) {
            url += '?' + params.join('&');
        }
        
        window.location.href = url;
    }
    
    function clearFilters() {
        window.location.href = 'subjects.php';
    }
    
    function filterCoursesByDepartment(modal) {
        var deptSelect = document.getElementById(modal + '_dept_filter');
        var courseSelect = document.getElementById(modal + '_course_id');
        var semesterSelect = document.getElementById(modal + '_semester_number');
        var deptId = deptSelect.value;
        
        // Clear current options
        courseSelect.innerHTML = '<option value="">Select Course</option>';
        semesterSelect.innerHTML = '<option value="">Select Course First</option>';
        semesterSelect.disabled = true;
        
        if (deptId) {
            // Filter courses by department
            var filteredCourses = allCourses.filter(function(course) {
                return course.dept_id == deptId;
            });
            
            if (filteredCourses.length > 0) {
                filteredCourses.forEach(function(course) {
                    var option = document.createElement('option');
                    option.value = course.id;
                    option.text = course.name;
                    option.setAttribute('data-semesters', course.total_semesters);
                    courseSelect.appendChild(option);
                });
                courseSelect.disabled = false;
            } else {
                courseSelect.innerHTML = '<option value="">No courses in this department</option>';
                courseSelect.disabled = true;
            }
        } else {
            courseSelect.innerHTML = '<option value="">Select Department First</option>';
            courseSelect.disabled = true;
        }
    }
    
    function updateSemesterOptions(modal) {
        var courseSelect = document.getElementById(modal + '_course_id');
        var semesterSelect = document.getElementById(modal + '_semester_number');
        var selectedOption = courseSelect.options[courseSelect.selectedIndex];
        
        if (selectedOption && selectedOption.value) {
            var totalSemesters = selectedOption.getAttribute('data-semesters');
            semesterSelect.innerHTML = '<option value="">Select Semester</option>';
            
            for (var i = 1; i <= totalSemesters; i++) {
                var option = document.createElement('option');
                option.value = i;
                option.text = 'Semester ' + i;
                semesterSelect.appendChild(option);
            }
            semesterSelect.disabled = false;
        } else {
            semesterSelect.innerHTML = '<option value="">Select Course First</option>';
            semesterSelect.disabled = true;
        }
    }
    
    function validateSubjectName(modal) {
        const subjectName = document.getElementById(modal + '_subject_name').value.trim();
        const courseId = document.getElementById(modal + '_course_id').value;
        const currentId = modal === 'edit' ? document.getElementById('edit_subject_id').value : 0;
        const validationDiv = document.getElementById(modal + '_subject_name_validation');
        const inputField = document.getElementById(modal + '_subject_name');
        
        // Clear previous timeout
        if (validationTimeouts[modal + '_subject_name']) {
            clearTimeout(validationTimeouts[modal + '_subject_name']);
        }
        
        // If subject name is empty, mark as valid (since it's not required for blocking)
        if (subjectName.length === 0) {
            validationDiv.innerHTML = '';
            inputField.classList.remove('input-error', 'input-success');
            validationState[modal].subject_name = true; // Valid when empty
            updateSubmitButton(modal);
            return;
        }
        
        // Check if course is selected
        if (!courseId) {
            validationDiv.innerHTML = '<span class="validation-error"> Please select a course first</span>';
            inputField.classList.add('input-error');
            inputField.classList.remove('input-success');
            validationState[modal].subject_name = false;
            updateSubmitButton(modal);
            return;
        }
        
        // Show loading state
        validationDiv.innerHTML = '<span class="validation-spinner"></span> Checking availability...';
        inputField.classList.remove('input-error', 'input-success');
        
        // Set timeout to avoid too many requests
        validationTimeouts[modal + '_subject_name'] = setTimeout(() => {
            fetch(`subjects.php?ajax=validate&field=subject_name&value=${encodeURIComponent(subjectName)}&course_id=${courseId}&current_id=${currentId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.valid) {
                        validationDiv.innerHTML = '<span class="validation-success"> Subject name available</span>';
                        inputField.classList.add('input-success');
                        inputField.classList.remove('input-error');
                        validationState[modal].subject_name = true;
                    } else {
                        validationDiv.innerHTML = `<span class="validation-error"> ${data.message}</span>`;
                        inputField.classList.add('input-error');
                        inputField.classList.remove('input-success');
                        validationState[modal].subject_name = false;
                    }
                    updateSubmitButton(modal);
                })
                .catch(error => {
                    console.error('Validation error:', error);
                    validationDiv.innerHTML = '<span class="validation-error">⚠ Validation failed</span>';
                    validationState[modal].subject_name = true; // Allow submission on error
                    updateSubmitButton(modal);
                });
        }, 500);
    }
    
    function validateSubjectCode(modal) {
        const subjectCode = document.getElementById(modal + '_subject_code').value.trim();
        const currentId = modal === 'edit' ? document.getElementById('edit_subject_id').value : 0;
        const validationDiv = document.getElementById(modal + '_subject_code_validation');
        const inputField = document.getElementById(modal + '_subject_code');
        
        // Clear previous timeout
        if (validationTimeouts[modal + '_subject_code']) {
            clearTimeout(validationTimeouts[modal + '_subject_code']);
        }
        
        // If subject code is empty, mark as valid (since it's not required for blocking)
        if (subjectCode.length === 0) {
            validationDiv.innerHTML = '';
            inputField.classList.remove('input-error', 'input-success');
            validationState[modal].subject_code = true; // Valid when empty
            updateSubmitButton(modal);
            return;
        }
        
        // Show loading state
        validationDiv.innerHTML = '<span class="validation-spinner"></span> Checking availability...';
        inputField.classList.remove('input-error', 'input-success');
        
        // Set timeout to avoid too many requests
        validationTimeouts[modal + '_subject_code'] = setTimeout(() => {
            fetch(`subjects.php?ajax=validate&field=subject_code&value=${encodeURIComponent(subjectCode)}&current_id=${currentId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.valid) {
                        validationDiv.innerHTML = '<span class="validation-success">✓ Subject code available</span>';
                        inputField.classList.add('input-success');
                        inputField.classList.remove('input-error');
                        validationState[modal].subject_code = true;
                    } else {
                        validationDiv.innerHTML = `<span class="validation-error"> ${data.message}</span>`;
                        inputField.classList.add('input-error');
                        inputField.classList.remove('input-success');
                        validationState[modal].subject_code = false;
                    }
                    updateSubmitButton(modal);
                })
                .catch(error => {
                    console.error('Validation error:', error);
                    validationDiv.innerHTML = '<span class="validation-error">⚠ Validation failed</span>';
                    validationState[modal].subject_code = true; // Allow submission on error
                    updateSubmitButton(modal);
                });
        }, 500);
    }
    
    function updateSubmitButton(modal) {
        const submitBtn = document.getElementById(modal + '_submit_btn');
        const state = validationState[modal];
        
        // Check if both validations are true (including empty fields which are now valid)
        if (state.subject_name && state.subject_code) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
        } else {
            submitBtn.disabled = true;
            submitBtn.style.opacity = '0.5';
            submitBtn.style.cursor = 'not-allowed';
        }
    }
    
    function validateAddForm() {
        const state = validationState.add;
        const subjectName = document.getElementById('add_subject_name').value.trim();
        const subjectCode = document.getElementById('add_subject_code').value.trim();
        const courseId = document.getElementById('add_course_id').value;
        const semesterNumber = document.getElementById('add_semester_number').value;
        
        // Check if required fields are filled
        if (!courseId) {
            alert('Please select a course.');
            return false;
        }
        if (!semesterNumber) {
            alert('Please select a semester.');
            return false;
        }
        if (!subjectName) {
            alert('Please enter a subject name.');
            return false;
        }
        if (!subjectCode) {
            alert('Please enter a subject code.');
            return false;
        }
        
        // Check validation state
        if (!state.subject_name || !state.subject_code) {
            alert('Please fix validation errors before submitting.');
            return false;
        }
        return true;
    }
    
    function validateEditForm() {
        const state = validationState.edit;
        const subjectName = document.getElementById('edit_subject_name').value.trim();
        const subjectCode = document.getElementById('edit_subject_code').value.trim();
        const courseId = document.getElementById('edit_course_id').value;
        const semesterNumber = document.getElementById('edit_semester_number').value;
        
        // Check if required fields are filled
        if (!courseId) {
            alert('Please select a course.');
            return false;
        }
        if (!semesterNumber) {
            alert('Please select a semester.');
            return false;
        }
        if (!subjectName) {
            alert('Please enter a subject name.');
            return false;
        }
        if (!subjectCode) {
            alert('Please enter a subject code.');
            return false;
        }
        
        // Check validation state
        if (!state.subject_name || !state.subject_code) {
            alert('Please fix validation errors before submitting.');
            return false;
        }
        return true;
    }
    
    function editSubject(subject) {
        $('#edit_subject_id').val(subject.subject_id);
        $('#edit_subject_name').val(subject.subject_name);
        $('#edit_subject_code').val(subject.subject_code);
        $('#edit_subject_type').val(subject.subject_type);
        $('#edit_credit_hours').val(subject.credit_hours);
        
        // Get course details to set department
        var course = allCourses.find(c => c.id == subject.course_id);
        if (course) {
            // Set department filter
            $('#edit_dept_filter').val(course.dept_id);
            
            // Trigger course filter
            filterCoursesByDepartment('edit');
            
            // Small delay to ensure courses are loaded then set course
            setTimeout(function() {
                $('#edit_course_id').val(subject.course_id);
                updateSemesterOptions('edit');
                
                // Small delay to ensure semesters are loaded then set semester
                setTimeout(function() {
                    $('#edit_semester_number').val(subject.semester_number);
                    
                    // Validate fields after loading
                    validateSubjectName('edit');
                    validateSubjectCode('edit');
                }, 100);
            }, 200);
        }
        
        // Reset validation state for edit modal
        validationState.edit = { subject_name: true, subject_code: true };
        
        // Clear validation messages
        document.getElementById('edit_subject_name_validation').innerHTML = '';
        document.getElementById('edit_subject_code_validation').innerHTML = '';
        
        // Remove input classes
        document.getElementById('edit_subject_name').classList.remove('input-error', 'input-success');
        document.getElementById('edit_subject_code').classList.remove('input-error', 'input-success');
        
        // Enable submit button
        document.getElementById('edit_submit_btn').disabled = false;
        document.getElementById('edit_submit_btn').style.opacity = '1';
        
        $('#editModal').show();
    }
    
    // Initialize course filter based on URL parameters
    $(document).ready(function() {
        var deptFilter = <?php echo $dept_filter; ?>;
        var courseFilter = <?php echo $course_filter; ?>;
        
        if (deptFilter > 0 && courseFilter > 0) {
            $('#course_filter').val(courseFilter);
        }
        
        // Initialize add modal with submit button disabled
        document.getElementById('add_submit_btn').disabled = true;
        document.getElementById('add_submit_btn').style.opacity = '0.5';
    });
    
    // Reset validation when opening add modal
    $('#addModal').on('click', function() {
        setTimeout(() => {
            validationState.add = { subject_name: true, subject_code: true };
            document.getElementById('add_subject_name_validation').innerHTML = '';
            document.getElementById('add_subject_code_validation').innerHTML = '';
            document.getElementById('add_subject_name').classList.remove('input-error', 'input-success');
            document.getElementById('add_subject_code').classList.remove('input-error', 'input-success');
            document.getElementById('add_submit_btn').disabled = true;
            document.getElementById('add_submit_btn').style.opacity = '0.5';
        }, 100);
    });
    
    // Initialize validation for add modal fields when they get focus
    document.getElementById('add_subject_name').addEventListener('focus', function() {
        if (this.value.trim() !== '') {
            validateSubjectName('add');
        }
    });
    
    document.getElementById('add_subject_code').addEventListener('focus', function() {
        if (this.value.trim() !== '') {
            validateSubjectCode('add');
        }
    });
    
    document.getElementById('add_course_id').addEventListener('change', function() {
        if (document.getElementById('add_subject_name').value.trim() !== '') {
            validateSubjectName('add');
        }
        if (document.getElementById('add_subject_code').value.trim() !== '') {
            validateSubjectCode('add');
        }
    });
    
    // Add event listeners for edit modal
    document.getElementById('edit_subject_name').addEventListener('focus', function() {
        if (this.value.trim() !== '') {
            validateSubjectName('edit');
        }
    });
    
    document.getElementById('edit_subject_code').addEventListener('focus', function() {
        if (this.value.trim() !== '') {
            validateSubjectCode('edit');
        }
    });
    
    document.getElementById('edit_course_id').addEventListener('change', function() {
        if (document.getElementById('edit_subject_name').value.trim() !== '') {
            validateSubjectName('edit');
        }
        if (document.getElementById('edit_subject_code').value.trim() !== '') {
            validateSubjectCode('edit');
        }
    });
    
    // Add input event listeners for real-time validation
    document.getElementById('add_subject_name').addEventListener('input', function() {
        validateSubjectName('add');
    });
    
    document.getElementById('add_subject_code').addEventListener('input', function() {
        validateSubjectCode('add');
    });
    
    document.getElementById('edit_subject_name').addEventListener('input', function() {
        validateSubjectName('edit');
    });
    
    document.getElementById('edit_subject_code').addEventListener('input', function() {
        validateSubjectCode('edit');
    });
</script>
</body>
</html>