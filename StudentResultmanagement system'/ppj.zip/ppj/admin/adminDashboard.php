<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Get counts for dashboard
$departments_count = $conn->query("SELECT COUNT(*) as count FROM Department")->fetch_assoc()['count'];
$courses_count = $conn->query("SELECT COUNT(*) as count FROM Course")->fetch_assoc()['count'];
$teachers_count = $conn->query("SELECT COUNT(*) as count FROM Teacher")->fetch_assoc()['count'];
$students_count = $conn->query("SELECT COUNT(*) as count FROM Student")->fetch_assoc()['count'];
$subjects_count = $conn->query("SELECT COUNT(*) as count FROM subject")->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Admin Dashboard- SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                   <a href="adminDashboard.php">
            <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
            </a>
               <a href="departments.php">
            <img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5>
            </a>
                <a href="courses.php">
            <img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5>
            </a>
                  <a href="subjects.php">
            <img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5>
        </a>
           <a href="teachers.php">
            <img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5>
        </a>

         <a href="students.php">
            <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5>
        </a>
        

        <a href="allocations.php">
            <img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5>
        </a>
        <a href="exams.php">
            <img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5>
        </a>
        <a href="results.php">
            <img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5>
        </a>

        <a href="feedbacks.php">
            <img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5>
        </a>
        <a href="settings.php">
            <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5>
        </a>
        <a href="../logout.php">
            <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5>
        </a>
            </div>
        </nav>
        
        <div class="content">
            <h1><img src="../icons/Dashboard.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Dashboard</h1>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-top: 30px;">
            <div class="card" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white;">
                    <h3><img src="../icons/Department.png" style="height: 27px; vertical-align: middle; margin-right: 10px;">Total Departments</h3>
                    <p style="font-size: 36px; margin-top: 10px;"><?php echo $departments_count; ?></p>
                </div>  
                  
                <div class="card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white;">
                    <h3><img src="../icons/Course.png" style="height: 27px; vertical-align: middle; margin-right: 10px;">Total Courses</h3>
                    <p style="font-size: 36px; margin-top: 10px;"><?php echo $courses_count; ?></p>
                </div>  

                        <div class="card" style="background: linear-gradient(135deg, #8799f2 0%, #938e97 100%); color: white;">
                    <h3><img src="../icons/Subject.png" style="height: 27px; vertical-align: middle; margin-right: 10px;">Total Subjects</h3>
                    <p style="font-size: 36px; margin-top: 10px;"><?php echo $subjects_count; ?></p>
                </div>

                   <div class="card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white;">
                    <h3><img src="../icons/Teacher.png" style="height: 27px; vertical-align: middle; margin-right: 10px;">Total Teachers</h3>
                    <p style="font-size: 36px; margin-top: 10px;"><?php echo $teachers_count; ?></p>
                </div>
            <div class="card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                    <h3><img src="../icons/Student.png" style="height: 27px; vertical-align: middle; margin-right: 10px;">Total Students</h3>
                    <p style="font-size: 36px; margin-top: 10px;"><?php echo $students_count; ?></p>
                </div>
    
                
            </div>
            
            <div class="card" style="margin-top: 30px;">
                <div class="card-header">
                    <h2>Recent Feedback</h2>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Suggestion</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $recent = $conn->query("SELECT * FROM Contact ORDER BY contact_date DESC LIMIT 5");
                        if($recent && $recent->num_rows > 0) {
                            while($row = $recent->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row['contact_date']) . "</td>";
                                echo "<td>" . htmlspecialchars(substr($row['suggestion'], 0, 50)) . (strlen($row['suggestion']) > 50 ? '...' : '') . "</td>";
                                echo "<td><span class='" . ($row['admin_reply'] ? 'grade-A' : 'grade-C') . "'>" . ($row['admin_reply'] ? 'Replied' : 'Pending') . "</span></td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3' style='text-align: center;'>No feedback found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>