<?php
require_once '../includes/auth_check.php';
checkAdminLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Handle Add/Edit/Delete operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add') {
            $teacher_id = $_POST['teacher_id'];
            $subject_id = $_POST['subject_id'];
            $section = $database->escapeString($_POST['section']);
            
            // Check if allocation already exists for this teacher, subject, and section
            $check = $conn->query("SELECT * FROM Teacher_Allocation 
                                   WHERE teacher_id=$teacher_id AND subject_id=$subject_id 
                                   AND section='$section'");
            
            if ($check->num_rows == 0) {
                $sql = "INSERT INTO Teacher_Allocation (teacher_id, subject_id, section) 
                        VALUES ($teacher_id, $subject_id, '$section')";
                if ($conn->query($sql)) {
                    $_SESSION['message'] = "Teacher allocated successfully!";
                    $_SESSION['msg_type'] = "success";
                } else {
                    $_SESSION['message'] = "Error: " . $conn->error;
                    $_SESSION['msg_type'] = "error";
                }
            } else {
                $_SESSION['message'] = "This teacher is already allocated to this subject and section!";
                $_SESSION['msg_type'] = "error";
            }
        }
        
     elseif ($action == 'delete') {
    $allocation_id = $_POST['allocation_id'];
    
    // Simple delete - no cascade needed for this table
    $sql = "DELETE FROM Teacher_Allocation WHERE allocation_id=$allocation_id";
    if ($conn->query($sql)) {
        $_SESSION['message'] = "Allocation deleted successfully!";
        $_SESSION['msg_type'] = "success";
    } else {
        $_SESSION['message'] = "Error: " . $conn->error;
        $_SESSION['msg_type'] = "error";
    }
}
        
        header("Location: allocations.php");
        exit();
    }
}

// Handle filters
$dept_filter = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;
$course_filter = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$subject_filter = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
$semester_filter = isset($_GET['semester']) ? intval($_GET['semester']) : 0;
$section_filter = isset($_GET['section']) ? $database->escapeString($_GET['section']) : '';

// Get all allocations with related info
$allocation_query = "
    SELECT ta.*, 
           t.first_name as teacher_fname, t.last_name as teacher_lname, t.teacher_id,
           s.subject_name, s.subject_code, s.semester_number, s.subject_id,
           c.course_name, c.course_id,
           d.dept_name, d.dept_id
    FROM Teacher_Allocation ta
    JOIN Teacher t ON ta.teacher_id = t.teacher_id
    JOIN Subject s ON ta.subject_id = s.subject_id
    JOIN Course c ON s.course_id = c.course_id
    JOIN Department d ON c.dept_id = d.dept_id
    WHERE 1=1
";

if ($dept_filter > 0) {
    $allocation_query .= " AND d.dept_id = $dept_filter";
}

if ($course_filter > 0) {
    $allocation_query .= " AND c.course_id = $course_filter";
}

if ($subject_filter > 0) {
    $allocation_query .= " AND s.subject_id = $subject_filter";
}

if ($semester_filter > 0) {
    $allocation_query .= " AND s.semester_number = $semester_filter";
}

if (!empty($section_filter)) {
    $allocation_query .= " AND ta.section = '$section_filter'";
}

$allocation_query .= " ORDER BY ta.allocation_id DESC";
$allocations = $conn->query($allocation_query);

// Get departments for filter dropdown
$departments = $conn->query("SELECT * FROM Department ORDER BY dept_name");

// Get courses based on selected department
$course_filter_query = "SELECT c.*, d.dept_name FROM Course c LEFT JOIN Department d ON c.dept_id = d.dept_id";
if ($dept_filter > 0) {
    $course_filter_query .= " WHERE c.dept_id = $dept_filter";
}
$course_filter_query .= " ORDER BY c.course_name";
$filter_courses = $conn->query($course_filter_query);

// Get subjects based on selected course
$subject_filter_query = "SELECT s.*, c.course_name FROM Subject s LEFT JOIN Course c ON s.course_id = c.course_id";
if ($course_filter > 0) {
    $subject_filter_query .= " WHERE s.course_id = $course_filter";
}
if ($semester_filter > 0) {
    $subject_filter_query .= " AND s.semester_number = $semester_filter";
}
$subject_filter_query .= " ORDER BY s.semester_number, s.subject_name";
$filter_subjects = $conn->query($subject_filter_query);

// Get unique sections from allocations for filter
$sections = $conn->query("SELECT DISTINCT section FROM Teacher_Allocation WHERE section IS NOT NULL AND section != '' ORDER BY section");

// Get dropdown data for forms - MODIFIED: Teachers with department info
$teachers = $conn->query("
    SELECT t.teacher_id, t.first_name, t.last_name, d.dept_name 
    FROM Teacher t 
    LEFT JOIN Department d ON t.dept_id = d.dept_id 
    ORDER BY d.dept_name, t.first_name
");

// Get all courses for forms
$all_courses = $conn->query("SELECT c.*, d.dept_name FROM Course c LEFT JOIN Department d ON c.dept_id = d.dept_id ORDER BY d.dept_name, c.course_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Teacher Allocations - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Admin.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Admin
            </div>
            <div class="navbar-menu">
                   <a href="adminDashboard.php">
            <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
            </a>
               <a href="departments.php">
            <img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Department</h5>
            </a>
                <a href="courses.php">
            <img src="../icons/course.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Course</h5>
            </a>
                  <a href="subjects.php">
            <img src="../icons/subject.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Subject</h5>
        </a>
          <a href="teachers.php">
            <img src="../icons/Teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Teacher</h5>
        </a>

         <a href="students.php">
            <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Student</h5>
        </a>
         
        <a href="allocations.php">
            <img src="../icons/Addteacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Allocation</h5>
        </a>
        <a href="exams.php">
            <img src="../icons/exam.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Exam</h5>
        </a>
        <a href="results.php">
            <img src="../icons/result.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Result</h5>
        </a>

        <a href="feedbacks.php">
            <img src="../icons/Feedback.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Feedback</h5>
        </a>
        <a href="settings.php">
            <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Setting</h5>
        </a>
        <a href="../logout.php">
            <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>logout</h5>
        </a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2> <img src="../icons/Addteacher.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Teacher Allocations</h2>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <!-- Department Filter Dropdown -->
                        <select id="dept_filter" onchange="filterByDepartment()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 200px;">
                            <option value="0">All Departments</option>
                            <?php 
                            $departments->data_seek(0);
                            while($dept = $departments->fetch_assoc()): 
                                $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $dept['dept_name']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        
                        <!-- Course Filter Dropdown -->
                        <select id="course_filter" onchange="filterByCourse()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 250px;" <?php echo $dept_filter == 0 ? 'disabled' : ''; ?>>
                            <option value="0">All Courses</option>
                            <?php 
                            if($dept_filter > 0):
                                $filter_courses->data_seek(0);
                                while($course = $filter_courses->fetch_assoc()): 
                                    $selected = ($course_filter == $course['course_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $course['course_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $course['course_name']; ?>
                            </option>
                            <?php 
                                endwhile;
                            endif; 
                            ?>
                        </select>
                        
                        <!-- Subject Filter Dropdown -->
                        <select id="subject_filter" onchange="filterBySubject()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 250px;" <?php echo $course_filter == 0 ? 'disabled' : ''; ?>>
                            <option value="0">All Subjects</option>
                            <?php 
                            if($course_filter > 0):
                                $filter_subjects->data_seek(0);
                                while($subject = $filter_subjects->fetch_assoc()): 
                                    $selected = ($subject_filter == $subject['subject_id']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $subject['subject_id']; ?>" <?php echo $selected; ?>>
                                <?php echo $subject['subject_name']; ?> (Sem <?php echo $subject['semester_number']; ?>)
                            </option>
                            <?php 
                                endwhile;
                            endif; 
                            ?>
                        </select>
                        
                        <!-- Semester Filter Dropdown -->
                        <select id="semester_filter" onchange="filterBySemester()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 150px;">
                            <option value="0">All Semesters</option>
                            <?php for($i = 1; $i <= 8; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo ($semester_filter == $i) ? 'selected' : ''; ?>>
                                    Semester <?php echo $i; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                        
                        <!-- Section Filter Dropdown -->
                        <select id="section_filter" onchange="filterBySection()" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd; min-width: 150px;">
                            <option value="">All Sections</option>
                            <?php 
                            $sections->data_seek(0);
                            while($section = $sections->fetch_assoc()): 
                                $selected = ($section_filter == $section['section']) ? 'selected' : '';
                            ?>
                            <option value="<?php echo $section['section']; ?>" <?php echo $selected; ?>>
                                Section <?php echo $section['section']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        
                        <!-- Clear Filters Button -->
                        <?php if($dept_filter > 0 || $course_filter > 0 || $subject_filter > 0 || $semester_filter > 0 || !empty($section_filter)): ?>
                        <button class="btn btn-secondary" onclick="clearFilters()">Clear Filters</button>
                        <?php endif; ?>
                        
                        <button class="btn" onclick="$('#addModal').show()">New Allocation <img src="../icons/Add.png" style="height: 27px; vertical-align: middle; margin-right: 10px;"></button>
                    </div>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Teacher</th>
                            <th>Department</th>
                            <th>Course</th>
                            <th>Subject</th>
                            <th>Semester</th>
                            <th>Section</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($allocations->num_rows > 0): ?>
                            <?php while($row = $allocations->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['allocation_id']; ?></td>
                                <td><?php echo $row['teacher_fname'] . ' ' . $row['teacher_lname']; ?></td>
                                <td>
                                    <a href="?dept_id=<?php echo $row['dept_id']; ?>" style="text-decoration: none; color: inherit;">
                                        <?php echo $row['dept_name']; ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="?dept_id=<?php echo $row['dept_id']; ?>&course_id=<?php echo $row['course_id']; ?>" style="text-decoration: none; color: inherit;">
                                        <?php echo $row['course_name']; ?>
                                    </a>
                                </td>
                                <td><?php echo $row['subject_name'] . ' (' . $row['subject_code'] . ')'; ?></td>
                                <td>
                                    <a href="?<?php echo $dept_filter > 0 ? 'dept_id='.$dept_filter.'&' : ''; ?><?php echo $course_filter > 0 ? 'course_id='.$course_filter.'&' : ''; ?>semester=<?php echo $row['semester_number']; ?>" style="text-decoration: none; color: inherit;">
                                        Semester <?php echo $row['semester_number']; ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="?<?php echo $dept_filter > 0 ? 'dept_id='.$dept_filter.'&' : ''; ?><?php echo $course_filter > 0 ? 'course_id='.$course_filter.'&' : ''; ?><?php echo $subject_filter > 0 ? 'subject_id='.$subject_filter.'&' : ''; ?><?php echo $semester_filter > 0 ? 'semester='.$semester_filter.'&' : ''; ?>section=<?php echo $row['section']; ?>" style="text-decoration: none; color: inherit;">
                                        Section <?php echo $row['section']; ?>
                                    </a>
                                </td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="allocation_id" value="<?php echo $row['allocation_id']; ?>">
                                        <button type="submit" class="action-btn delete-btn" onclick="return confirm('Are you sure you want to delete this allocation?')" title="Delete"><img src="../icons/Delete.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 20px;">
                                    No allocations found
                                    <?php if($dept_filter > 0 || $course_filter > 0 || $subject_filter > 0 || $semester_filter > 0 || !empty($section_filter)): ?>
                                        with the selected filters. <a href="allocations.php">View all allocations</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content" style="max-width: 600px;">
            <span class="close">&times;</span>
            <h2>New Teacher Allocation</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label>Teacher <span style="color: red;">*</span></label>
                    <select name="teacher_id" required>
                        <option value="">Select Teacher</option>
                        <?php 
                        $current_dept = '';
                        $teachers->data_seek(0);
                        while($teacher = $teachers->fetch_assoc()): 
                            // Add department header if department changes
                            if ($current_dept != $teacher['dept_name']) {
                                if ($current_dept != '') {
                                    echo '</optgroup>';
                                }
                                $current_dept = $teacher['dept_name'];
                                echo '<optgroup label="' . htmlspecialchars($teacher['dept_name'] ?? 'No Department') . '">';
                            }
                        ?>
                        <option value="<?php echo $teacher['teacher_id']; ?>">
                            <?php echo $teacher['first_name'] . ' ' . $teacher['last_name']; ?>
                        </option>
                        <?php 
                        endwhile; 
                        if ($current_dept != '') {
                            echo '</optgroup>';
                        }
                        ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Department <span style="color: red;">*</span></label>
                    <select id="add_dept_filter" onchange="filterCoursesByDepartment('add')" required>
                        <option value="">Select Department First</option>
                        <?php 
                        $departments->data_seek(0);
                        while($dept = $departments->fetch_assoc()): 
                            $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                        ?>
                        <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                            <?php echo $dept['dept_name']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Course <span style="color: red;">*</span></label>
                    <select id="add_course_id" onchange="filterSubjectsByCourse('add')" required disabled>
                        <option value="">Select Department First</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Semester <span style="color: red;">*</span></label>
                    <select id="add_semester" onchange="filterSubjectsBySemester('add')" required disabled>
                        <option value="">Select Course First</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Subject <span style="color: red;">*</span></label>
                    <select name="subject_id" id="add_subject_id" required disabled>
                        <option value="">Select Semester First</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Section <span style="color: red;">*</span></label>
                    <select name="section" required>
                        <option value="">Select Section</option>
                        <option value="A">Section A</option>
                        <option value="B">Section B</option>
                        <option value="C">Section C</option>
                        <option value="D">Section D</option>
                    </select>
                </div>
                
                <button type="submit" class="btn">Allocate Teacher <img src="../icons/Add.png" style="height: 20px; vertical-align: middle; margin-left: 5px;"></button>
            </form>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        // Store courses and subjects data for filtering
        var allCourses = [];
        var allSubjects = [];
        
        <?php 
        $all_courses->data_seek(0);
        while($course = $all_courses->fetch_assoc()): 
        ?>
        allCourses.push({
            id: <?php echo $course['course_id']; ?>,
            name: '<?php echo addslashes($course['course_name']); ?>',
            dept_id: <?php echo $course['dept_id'] ?? 'null'; ?>,
            total_semesters: <?php echo $course['total_semesters']; ?>
        });
        <?php endwhile; ?>
        
        <?php 
        $all_subjects = $conn->query("SELECT s.*, c.course_id FROM Subject s JOIN Course c ON s.course_id = c.course_id");
        while($subject = $all_subjects->fetch_assoc()): 
        ?>
        allSubjects.push({
            id: <?php echo $subject['subject_id']; ?>,
            name: '<?php echo addslashes($subject['subject_name']); ?>',
            code: '<?php echo $subject['subject_code']; ?>',
            course_id: <?php echo $subject['course_id']; ?>,
            semester: <?php echo $subject['semester_number']; ?>
        });
        <?php endwhile; ?>
        
        function filterByDepartment() {
            var deptId = document.getElementById('dept_filter').value;
            var url = 'allocations.php';
            var params = [];
            
            if (deptId > 0) {
                params.push('dept_id=' + deptId);
            }
            
            <?php if($course_filter > 0): ?>
            params.push('course_id=<?php echo $course_filter; ?>');
            <?php endif; ?>
            
            <?php if($subject_filter > 0): ?>
            params.push('subject_id=<?php echo $subject_filter; ?>');
            <?php endif; ?>
            
            <?php if($semester_filter > 0): ?>
            params.push('semester=<?php echo $semester_filter; ?>');
            <?php endif; ?>
            
            <?php if(!empty($section_filter)): ?>
            params.push('section=<?php echo $section_filter; ?>');
            <?php endif; ?>
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }
        
        function filterByCourse() {
            var deptId = document.getElementById('dept_filter').value;
            var courseId = document.getElementById('course_filter').value;
            var url = 'allocations.php';
            var params = [];
            
            if (deptId > 0) {
                params.push('dept_id=' + deptId);
            }
            if (courseId > 0) {
                params.push('course_id=' + courseId);
            }
            
            <?php if($subject_filter > 0): ?>
            params.push('subject_id=<?php echo $subject_filter; ?>');
            <?php endif; ?>
            
            <?php if($semester_filter > 0): ?>
            params.push('semester=<?php echo $semester_filter; ?>');
            <?php endif; ?>
            
            <?php if(!empty($section_filter)): ?>
            params.push('section=<?php echo $section_filter; ?>');
            <?php endif; ?>
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }
        
        function filterBySubject() {
            var deptId = document.getElementById('dept_filter').value;
            var courseId = document.getElementById('course_filter').value;
            var subjectId = document.getElementById('subject_filter').value;
            var url = 'allocations.php';
            var params = [];
            
            if (deptId > 0) {
                params.push('dept_id=' + deptId);
            }
            if (courseId > 0) {
                params.push('course_id=' + courseId);
            }
            if (subjectId > 0) {
                params.push('subject_id=' + subjectId);
            }
            
            <?php if($semester_filter > 0): ?>
            params.push('semester=<?php echo $semester_filter; ?>');
            <?php endif; ?>
            
            <?php if(!empty($section_filter)): ?>
            params.push('section=<?php echo $section_filter; ?>');
            <?php endif; ?>
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }
        
        function filterBySemester() {
            var semester = document.getElementById('semester_filter').value;
            var url = 'allocations.php';
            var params = [];
            
            <?php if($dept_filter > 0): ?>
            params.push('dept_id=<?php echo $dept_filter; ?>');
            <?php endif; ?>
            
            <?php if($course_filter > 0): ?>
            params.push('course_id=<?php echo $course_filter; ?>');
            <?php endif; ?>
            
            <?php if($subject_filter > 0): ?>
            params.push('subject_id=<?php echo $subject_filter; ?>');
            <?php endif; ?>
            
            if (semester > 0) {
                params.push('semester=' + semester);
            }
            
            <?php if(!empty($section_filter)): ?>
            params.push('section=<?php echo $section_filter; ?>');
            <?php endif; ?>
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }
        
        function filterBySection() {
            var section = document.getElementById('section_filter').value;
            var url = 'allocations.php';
            var params = [];
            
            <?php if($dept_filter > 0): ?>
            params.push('dept_id=<?php echo $dept_filter; ?>');
            <?php endif; ?>
            
            <?php if($course_filter > 0): ?>
            params.push('course_id=<?php echo $course_filter; ?>');
            <?php endif; ?>
            
            <?php if($subject_filter > 0): ?>
            params.push('subject_id=<?php echo $subject_filter; ?>');
            <?php endif; ?>
            
            <?php if($semester_filter > 0): ?>
            params.push('semester=<?php echo $semester_filter; ?>');
            <?php endif; ?>
            
            if (section) {
                params.push('section=' + section);
            }
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }
        
        function clearFilters() {
            window.location.href = 'allocations.php';
        }
        
        function filterCoursesByDepartment(modal) {
            var deptSelect = document.getElementById(modal + '_dept_filter');
            var courseSelect = document.getElementById(modal + '_course_id');
            var semesterSelect = document.getElementById(modal + '_semester');
            var subjectSelect = document.getElementById(modal + '_subject_id');
            var deptId = deptSelect.value;
            
            // Clear current options
            courseSelect.innerHTML = '<option value="">Select Course</option>';
            semesterSelect.innerHTML = '<option value="">Select Course First</option>';
            semesterSelect.disabled = true;
            subjectSelect.innerHTML = '<option value="">Select Semester First</option>';
            subjectSelect.disabled = true;
            
            if (deptId) {
                // Filter courses by department
                var filteredCourses = allCourses.filter(function(course) {
                    return course.dept_id == deptId;
                });
                
                if (filteredCourses.length > 0) {
                    filteredCourses.forEach(function(course) {
                        var option = document.createElement('option');
                        option.value = course.id;
                        option.text = course.name;
                        option.setAttribute('data-semesters', course.total_semesters);
                        courseSelect.appendChild(option);
                    });
                    courseSelect.disabled = false;
                } else {
                    courseSelect.innerHTML = '<option value="">No courses in this department</option>';
                    courseSelect.disabled = true;
                }
            } else {
                courseSelect.innerHTML = '<option value="">Select Department First</option>';
                courseSelect.disabled = true;
            }
        }
        
        function filterSubjectsByCourse(modal) {
            var courseSelect = document.getElementById(modal + '_course_id');
            var semesterSelect = document.getElementById(modal + '_semester');
            var subjectSelect = document.getElementById(modal + '_subject_id');
            var courseId = courseSelect.value;
            var selectedOption = courseSelect.options[courseSelect.selectedIndex];
            
            // Clear current options
            semesterSelect.innerHTML = '<option value="">Select Semester</option>';
            subjectSelect.innerHTML = '<option value="">Select Semester First</option>';
            subjectSelect.disabled = true;
            
            if (courseId && selectedOption) {
                var totalSemesters = selectedOption.getAttribute('data-semesters');
                
                for (var i = 1; i <= totalSemesters; i++) {
                    var option = document.createElement('option');
                    option.value = i;
                    option.text = 'Semester ' + i;
                    semesterSelect.appendChild(option);
                }
                semesterSelect.disabled = false;
            } else {
                semesterSelect.innerHTML = '<option value="">Select Course First</option>';
                semesterSelect.disabled = true;
            }
        }
        
        function filterSubjectsBySemester(modal) {
            var courseSelect = document.getElementById(modal + '_course_id');
            var semesterSelect = document.getElementById(modal + '_semester');
            var subjectSelect = document.getElementById(modal + '_subject_id');
            var courseId = courseSelect.value;
            var semester = semesterSelect.value;
            
            subjectSelect.innerHTML = '<option value="">Select Subject</option>';
            
            if (courseId && semester) {
                // Filter subjects by course and semester
                var filteredSubjects = allSubjects.filter(function(subject) {
                    return subject.course_id == courseId && subject.semester == semester;
                });
                
                if (filteredSubjects.length > 0) {
                    filteredSubjects.forEach(function(subject) {
                        var option = document.createElement('option');
                        option.value = subject.id;
                        option.text = subject.name + ' (' + subject.code + ')';
                        subjectSelect.appendChild(option);
                    });
                    subjectSelect.disabled = false;
                } else {
                    subjectSelect.innerHTML = '<option value="">No subjects in this semester</option>';
                    subjectSelect.disabled = true;
                }
            } else {
                subjectSelect.innerHTML = '<option value="">Select Semester First</option>';
                subjectSelect.disabled = true;
            }
        }
    </script>
    
    <style>
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .form-group label {
            font-weight: 600;
            margin-bottom: 5px;
            display: block;
        }
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        @media (max-width: 768px) {
            .card-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .card-header > div {
                width: 100%;
            }
            #dept_filter, #course_filter, #subject_filter, #semester_filter, #section_filter {
                width: 100%;
            }
        }
    </style>
</body>
</html>