<?php
session_start();
require_once 'config/database.php';

$database = new Database();
$conn = $database->getConnection();
$error = '';
$userType = isset($_GET['type']) ? $_GET['type'] : 'admin';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $database->escapeString($_POST['username']);
    $password = $_POST['password'];
    $userType = $_POST['user_type'];
    
    if ($userType == 'admin') {
        $sql = "SELECT * FROM Admin WHERE username = '$username'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            $admin = $result->fetch_assoc();
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['admin_id'];
                $_SESSION['admin_username'] = $admin['username'];
                header("Location: admin/dashboard.php");
                exit();
            } else {
                $error = "Invalid password!";
            }
        } else {
            $error = "Admin not found!";
        }
    } elseif ($userType == 'teacher') {
        $sql = "SELECT * FROM Teacher WHERE username = '$username'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            $teacher = $result->fetch_assoc();
            if (password_verify($password, $teacher['password'])) {
                $_SESSION['teacher_id'] = $teacher['teacher_id'];
                $_SESSION['teacher_name'] = $teacher['first_name'] . ' ' . $teacher['last_name'];
                header("Location: teacher/dashboard.php");
                exit();
            } else {
                $error = "Invalid password!";
            }
        } else {
            $error = "Teacher not found!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SRMS</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2>Student Result Management System</h2>
            
            <?php if($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label>Login As</label>
                    <select name="user_type" id="user_type" required>
                        <option value="admin" <?php echo $userType == 'admin' ? 'selected' : ''; ?>>Admin</option>
                        <option value="teacher" <?php echo $userType == 'teacher' ? 'selected' : ''; ?>>Teacher</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" required>
                </div>
                
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" required>
                </div>
                
                <button type="submit" class="btn">Login</button>
            </form>
            
            <div style="margin-top: 20px; text-align: center;">
                <a href="student/view_result.php">Student? Click here to view result</a>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>