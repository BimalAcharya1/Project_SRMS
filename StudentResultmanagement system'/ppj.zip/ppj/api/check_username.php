<?php
require_once '../config/database.php';
require_once '../includes/Validation.php';

$database = new Database();
$conn = $database->getConnection();
$response = ['available' => true, 'message' => ''];

if (isset($_POST['username'])) {
    $username = Validation::sanitize($_POST['username']);
    
    // Check in teachers table
    $teacher_check = $conn->query("SELECT teacher_id FROM Teacher WHERE username = '$username'");
    
    // Check in admin table
    $admin_check = $conn->query("SELECT admin_id FROM Admin WHERE username = '$username'");
    
    if ($teacher_check->num_rows > 0 || $admin_check->num_rows > 0) {
        $response['available'] = false;
        $response['message'] = 'Username already taken';
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>