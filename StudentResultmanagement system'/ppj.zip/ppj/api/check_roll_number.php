<?php
require_once '../config/database.php';
require_once '../includes/Validation.php';

$database = new Database();
$conn = $database->getConnection();
$response = ['available' => true, 'message' => ''];

if (isset($_POST['roll_number'])) {
    $roll_number = Validation::sanitize($_POST['roll_number']);
    
    $check = $conn->query("SELECT student_id FROM Student WHERE roll_number = '$roll_number'");
    
    if ($check->num_rows > 0) {
        $response['available'] = false;
        $response['message'] = 'Roll number already exists';
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>