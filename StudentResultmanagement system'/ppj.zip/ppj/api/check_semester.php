<?php
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

if (isset($_POST['course_id'])) {
    $course_id = $_POST['course_id'];
    $course = $conn->query("SELECT total_semesters FROM Course WHERE course_id = $course_id")->fetch_assoc();
    
    $response = [
        'total_semesters' => $course['total_semesters'] ?? 8
    ];
    
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>