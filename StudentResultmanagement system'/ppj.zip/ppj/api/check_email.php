<?php
require_once '../config/database.php';
require_once '../includes/Validation.php';

$database = new Database();
$conn = $database->getConnection();
$response = ['available' => true, 'message' => ''];

if (isset($_POST['email'])) {
    $email = Validation::sanitize($_POST['email']);
    
    // Check in teachers table
    $teacher_check = $conn->query("SELECT teacher_id FROM Teacher WHERE email = '$email'");
    
    // Check in students table
    $student_check = $conn->query("SELECT student_id FROM Student WHERE email = '$email'");
    
    if ($teacher_check->num_rows > 0 || $student_check->num_rows > 0) {
        $response['available'] = false;
        $response['message'] = 'Email already registered';
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>