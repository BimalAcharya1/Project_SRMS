<?php
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

if (isset($_POST['batch_id']) && isset($_POST['semester'])) {
    $batch_id = $_POST['batch_id'];
    $semester = $_POST['semester'];
    
    $students = $conn->query("
        SELECT student_id, roll_number, first_name, last_name 
        FROM Student 
        WHERE batch_id = $batch_id AND current_semester = $semester
        ORDER BY roll_number
    ");
    
    $response = [];
    while($student = $students->fetch_assoc()) {
        $response[] = $student;
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>