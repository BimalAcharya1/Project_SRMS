<?php
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

if (isset($_POST['dept_id'])) {
    $dept_id = $_POST['dept_id'];
    $courses = $conn->query("SELECT * FROM Course WHERE dept_id = $dept_id ORDER BY course_name");
    
    $options = '<option value="">Select Course</option>';
    while($course = $courses->fetch_assoc()) {
        $options .= '<option value="' . $course['course_id'] . '">' . $course['course_name'] . '</option>';
    }
    
    echo $options;
}
?>