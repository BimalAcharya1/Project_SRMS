<?php
session_start();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['teacher_id'])) {
    $exam_id = $_POST['exam_id'];
    $subject_id = $_POST['subject_id'];
    $marks = $_POST['marks'];
    
    $conn->begin_transaction();
    
    try {
        foreach ($marks as $student_id => $marks_obtained) {
            if ($marks_obtained !== '') {
                // Check if result exists
                $check = $conn->query("
                    SELECT result_id FROM Result 
                    WHERE student_id = $student_id 
                    AND subject_id = $subject_id 
                    AND exam_id = $exam_id
                ");
                
                if ($check->num_rows > 0) {
                    $sql = "UPDATE Result SET marks_obtained = $marks_obtained 
                            WHERE student_id = $student_id 
                            AND subject_id = $subject_id 
                            AND exam_id = $exam_id";
                } else {
                    $sql = "INSERT INTO Result (student_id, subject_id, exam_id, marks_obtained) 
                            VALUES ($student_id, $subject_id, $exam_id, $marks_obtained)";
                }
                
                if (!$conn->query($sql)) {
                    throw new Exception($conn->error);
                }
            }
        }
        
        $conn->commit();
        $response['success'] = true;
        $response['message'] = 'Marks saved successfully!';
        
    } catch (Exception $e) {
        $conn->rollback();
        $response['message'] = 'Error: ' . $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>