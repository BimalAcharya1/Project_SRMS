<?php
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

if (isset($_POST['course_id'])) {
    $course_id = $_POST['course_id'];
    $subjects = $conn->query("SELECT * FROM Subject WHERE course_id = $course_id ORDER BY semester_number, subject_name");
    
    $options = '<option value="">Select Subject</option>';
    while($subject = $subjects->fetch_assoc()) {
        $options .= '<option value="' . $subject['subject_id'] . '">' . $subject['subject_name'] . ' (Sem ' . $subject['semester_number'] . ')</option>';
    }
    
    echo $options;
}
?>