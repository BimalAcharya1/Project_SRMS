<?php
require_once '../includes/auth_check.php';
checkTeacherLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

$teacher_id = $_SESSION['teacher_id'];

// Get filter parameters
$dept_filter = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;
$course_filter = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$subject_filter = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
$section_filter = isset($_GET['section']) ? $database->escapeString($_GET['section']) : '';
$semester_filter = isset($_GET['semester']) ? intval($_GET['semester']) : 0;
$search_query = isset($_GET['search']) ? $database->escapeString($_GET['search']) : '';

// Get departments for filter (only those where teacher has allocations)
$departments = $conn->query("
    SELECT DISTINCT d.dept_id, d.dept_name
    FROM Teacher_Allocation ta
    JOIN Subject s ON ta.subject_id = s.subject_id
    JOIN Course c ON s.course_id = c.course_id
    JOIN Department d ON c.dept_id = d.dept_id
    WHERE ta.teacher_id = $teacher_id
    ORDER BY d.dept_name
");

// Get courses based on selected department
$filter_courses = null;
if ($dept_filter > 0) {
    $filter_courses = $conn->query("
        SELECT DISTINCT c.course_id, c.course_name
        FROM Teacher_Allocation ta
        JOIN Subject s ON ta.subject_id = s.subject_id
        JOIN Course c ON s.course_id = c.course_id
        WHERE ta.teacher_id = $teacher_id AND c.dept_id = $dept_filter
        ORDER BY c.course_name
    ");
}

// Get subjects based on selected course
$filter_subjects = null;
if ($course_filter > 0) {
    $filter_subjects = $conn->query("
        SELECT DISTINCT s.subject_id, s.subject_name, s.semester_number
        FROM Teacher_Allocation ta
        JOIN Subject s ON ta.subject_id = s.subject_id
        WHERE ta.teacher_id = $teacher_id AND s.course_id = $course_filter
        ORDER BY s.semester_number, s.subject_name
    ");
}

// Get sections based on selected subject
$filter_sections = null;
if ($subject_filter > 0) {
    $filter_sections = $conn->query("
        SELECT DISTINCT ta.section
        FROM Teacher_Allocation ta
        WHERE ta.teacher_id = $teacher_id AND ta.subject_id = $subject_filter AND ta.section IS NOT NULL
        ORDER BY ta.section
    ");
}

// Build student query based on filters
$student_query = "
    SELECT DISTINCT s.*, c.course_name, d.dept_name
    FROM Student s
    JOIN Course c ON s.course_id = c.course_id
    JOIN Department d ON c.dept_id = d.dept_id
    WHERE 1=1
";

// Apply department filter
if ($dept_filter > 0) {
    $student_query .= " AND c.dept_id = $dept_filter";
}

// Apply course filter
if ($course_filter > 0) {
    $student_query .= " AND s.course_id = $course_filter";
}

// Apply semester filter
if ($semester_filter > 0) {
    $student_query .= " AND s.current_semester = $semester_filter";
}

// Apply section filter - this requires joining with allocations
if (!empty($section_filter) && $subject_filter > 0) {
    $student_query .= " AND s.student_id IN (
        SELECT DISTINCT st.student_id
        FROM Student st
        JOIN Teacher_Allocation ta ON st.course_id = (SELECT course_id FROM Subject WHERE subject_id = $subject_filter)
        WHERE ta.subject_id = $subject_filter AND ta.section = '$section_filter'
    )";
}

// Apply search query
if (!empty($search_query)) {
    $student_query .= " AND (
        s.roll_number LIKE '%$search_query%' OR
        s.first_name LIKE '%$search_query%' OR
        s.last_name LIKE '%$search_query%' OR
        s.email LIKE '%$search_query%' OR
        s.phone LIKE '%$search_query%'
    )";
}

$student_query .= " ORDER BY s.roll_number";

// Get students
$students = null;
if ($dept_filter > 0 || $course_filter > 0 || !empty($section_filter) || !empty($search_query)) {
    $students = $conn->query($student_query);
}

// Get statistics
$total_students = $students ? $students->num_rows : 0;

// Get gender distribution
$gender_stats = null;
if ($students && $students->num_rows > 0) {
    $students->data_seek(0);
    $male_count = 0;
    $female_count = 0;
    $other_count = 0;
    
    while ($student = $students->fetch_assoc()) {
        if ($student['gender'] == 'Male') $male_count++;
        elseif ($student['gender'] == 'Female') $female_count++;
        else $other_count++;
    }
    
    // Reset pointer
    $students->data_seek(0);
}

// Handle AJAX request for student details
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_student_details') {
    $student_id = intval($_GET['student_id']);
    
    // Get student details
    $query = "
        SELECT s.*, c.course_name, d.dept_name, b.batch_name
        FROM Student s
        LEFT JOIN Course c ON s.course_id = c.course_id
        LEFT JOIN Department d ON c.dept_id = d.dept_id
        LEFT JOIN Batch b ON s.batch_id = b.batch_id
        WHERE s.student_id = $student_id
    ";
    
    $result = $conn->query($query);
    
    if ($result && $result->num_rows > 0) {
        $student = $result->fetch_assoc();
        
        // Get student's subjects
        $subjects_query = "
            SELECT ss.*, sub.subject_name, sub.subject_code, sub.credit_hours
            FROM student_subjects ss
            JOIN Subject sub ON ss.subject_id = sub.subject_id
            WHERE ss.student_id = $student_id
            ORDER BY ss.semester, sub.subject_name
        ";
        $subjects_result = $conn->query($subjects_query);
        
        $subjects = [];
        while ($row = $subjects_result->fetch_assoc()) {
            $subjects[] = $row;
        }
        
        // Get recent results
        $results_query = "
            SELECT r.*, e.exam_name, e.exam_type, e.exam_date, sub.subject_name
            FROM Result r
            JOIN Exam e ON r.exam_id = e.exam_id
            JOIN Subject sub ON r.subject_id = sub.subject_id
            WHERE r.student_id = $student_id
            ORDER BY e.exam_date DESC
            LIMIT 5
        ";
        $results_result = $conn->query($results_query);
        
        $results = [];
        while ($row = $results_result->fetch_assoc()) {
            $results[] = $row;
        }
        
        echo json_encode([
            'success' => true,
            'student' => $student,
            'subjects' => $subjects,
            'results' => $results
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Student not found']);
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>View Students - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* View Students Specific Styles */
        .filters-section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .filter-item {
            display: flex;
            flex-direction: column;
        }
        
        .filter-item label {
            font-size: 13px;
            color: #666;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .filter-item select, .filter-item input {
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .filter-item select:focus, .filter-item input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .filter-item select:disabled {
            background: #f5f5f5;
            cursor: not-allowed;
        }
        
        .search-box {
            position: relative;
            flex: 1;
        }
        
        .search-box input {
            width: 100%;
            padding: 12px 40px 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .search-box button {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            padding: 5px;
        }
        
        .search-box img {
            width: 20px;
            height: 20px;
            opacity: 0.5;
        }
        
        .filter-actions {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        
        .stats-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .stat-icon img {
            width: 30px;
            height: 30px;
            filter: brightness(0) invert(1);
        }
        
        .stat-content h3 {
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }
        
        .stat-number {
            font-size: 28px;
            font-weight: bold;
            color: #333;
        }
        
        .gender-distribution {
            display: flex;
            gap: 15px;
            margin-top: 10px;
            flex-wrap: wrap;
        }
        
        .gender-item {
            display: flex;
            align-items: center;
            gap: 5px;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 13px;
        }
        
        .gender-male {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .gender-female {
            background: #fce4ec;
            color: #c2185b;
        }
        
        .gender-other {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .students-table-container {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow-x: auto;
        }
        
        .students-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .students-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #dee2e6;
            white-space: nowrap;
        }
        
        .students-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .students-table tr:hover {
            background: #f8f9fa;
        }
        
        .student-avatar {
            width: 35px;
            height: 35px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 14px;
        }
        
        .student-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .student-name {
            font-weight: 500;
            color: #333;
        }
        
        .student-email {
            font-size: 12px;
            color: #666;
        }
        
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-primary {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .badge-success {
            background: #d4edda;
            color: #155724;
        }
        
        .badge-info {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
        }
        
        .action-btn {
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            border: none;
            cursor: pointer;
        }
        
        .action-btn img {
            width: 14px;
            height: 14px;
        }
        
        .btn-view {
            background: #e3f2fd;
            color: #1976d2;
            cursor: pointer;
        }
        
        .btn-view:hover {
            background: #bbdefb;
        }
        
        .btn-marks {
            background: #d4edda;
            color: #155724;
        }
        
        .btn-marks:hover {
            background: #c3e6cb;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        
        .empty-state img {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .empty-state h3 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 50px auto;
            padding: 30px;
            border-radius: 12px;
            width: 90%;
            max-width: 800px;
            max-height: 80vh;
            overflow-y: auto;
            position: relative;
            animation: modalSlideDown 0.3s ease-out;
        }
        
        @keyframes modalSlideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            position: sticky;
            top: 0;
        }
        
        .close:hover {
            color: #333;
        }
        
        .detail-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
        }
        
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 15px;
        }
        
        .detail-item {
            display: flex;
            flex-direction: column;
        }
        
        .detail-label {
            font-size: 12px;
            opacity: 0.9;
            margin-bottom: 3px;
        }
        
        .detail-value {
            font-size: 16px;
            font-weight: 600;
        }
        
        .subjects-table, .results-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .subjects-table th, .results-table th {
            background: #f8f9fa;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #dee2e6;
        }
        
        .subjects-table td, .results-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .subjects-table tr:hover, .results-table tr:hover {
            background: #f8f9fa;
        }
        
        .subject-type {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 600;
        }
        
        .type-compulsory {
            background: #007bff;
            color: white;
        }
        
        .type-optional {
            background: #28a745;
            color: white;
        }
        
        .type-elective {
            background: #ffc107;
            color: black;
        }
        
        .loading-spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        @media (max-width: 768px) {
            .filter-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-actions {
                flex-direction: column;
            }
            
            .stats-section {
                grid-template-columns: 1fr;
            }
            
            .students-table td {
                min-width: 120px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .detail-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Teacher.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Teacher
            </div>
            <div class="navbar-menu">
                <a href="teacher_dashboard.php">
                    <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
                </a>
                <a href="marks_entry.php">
                    <img src="../icons/Addmarks.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Marks Entry</h5>
                </a>
                <a href="view_students.php" class="active">
                    <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>View Students</h5>
                </a>
                <a href="teacher_settings.php">
                    <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Settings</h5>
                </a>
                <a href="../logout.php">
                    <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Logout</h5>
                </a>
            </div>
        </nav>
        
        <div class="content">
            <h1><img src="../icons/student.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">View Students</h1>
            
            <!-- Filters Section -->
            <div class="filters-section">
                <form method="GET" action="view_students.php" id="filterForm">
                    <div class="filter-grid">
                        <div class="filter-item">
                            <label>Department</label>
                            <select name="dept_id" id="dept_filter" onchange="this.form.submit()">
                                <option value="0">All Departments</option>
                                <?php 
                                if($departments) {
                                    $departments->data_seek(0);
                                    while($dept = $departments->fetch_assoc()): 
                                        $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                                ?>
                                <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                                    <?php echo $dept['dept_name']; ?>
                                </option>
                                <?php 
                                    endwhile;
                                } 
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label>Course</label>
                            <select name="course_id" id="course_filter" onchange="this.form.submit()" <?php echo $dept_filter == 0 ? 'disabled' : ''; ?>>
                                <option value="0">All Courses</option>
                                <?php 
                                if($filter_courses) {
                                    $filter_courses->data_seek(0);
                                    while($course = $filter_courses->fetch_assoc()): 
                                        $selected = ($course_filter == $course['course_id']) ? 'selected' : '';
                                ?>
                                <option value="<?php echo $course['course_id']; ?>" <?php echo $selected; ?>>
                                    <?php echo $course['course_name']; ?>
                                </option>
                                <?php 
                                    endwhile;
                                } 
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label>Subject</label>
                            <select name="subject_id" id="subject_filter" onchange="this.form.submit()" <?php echo $course_filter == 0 ? 'disabled' : ''; ?>>
                                <option value="0">All Subjects</option>
                                <?php 
                                if($filter_subjects) {
                                    $filter_subjects->data_seek(0);
                                    while($subject = $filter_subjects->fetch_assoc()): 
                                        $selected = ($subject_filter == $subject['subject_id']) ? 'selected' : '';
                                ?>
                                <option value="<?php echo $subject['subject_id']; ?>" <?php echo $selected; ?>>
                                    <?php echo $subject['subject_name']; ?> (Sem <?php echo $subject['semester_number']; ?>)
                                </option>
                                <?php 
                                    endwhile;
                                } 
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label>Section</label>
                            <select name="section" id="section_filter" onchange="this.form.submit()" <?php echo $subject_filter == 0 ? 'disabled' : ''; ?>>
                                <option value="">All Sections</option>
                                <?php 
                                if($filter_sections) {
                                    $filter_sections->data_seek(0);
                                    while($section = $filter_sections->fetch_assoc()): 
                                        $selected = ($section_filter == $section['section']) ? 'selected' : '';
                                ?>
                                <option value="<?php echo $section['section']; ?>" <?php echo $selected; ?>>
                                    Section <?php echo $section['section']; ?>
                                </option>
                                <?php 
                                    endwhile;
                                } 
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label>Semester</label>
                            <select name="semester" id="semester_filter" onchange="this.form.submit()">
                                <option value="0">All Semesters</option>
                                <?php for($i = 1; $i <= 8; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo ($semester_filter == $i) ? 'selected' : ''; ?>>
                                        Semester <?php echo $i; ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        
                        <div class="filter-item search-box">
                            <label>Search</label>
                            <input type="text" name="search" placeholder="Search by name, roll, email..." value="<?php echo htmlspecialchars($search_query); ?>">
                            <button type="submit">
                                <img src="../icons/search.png" alt="Search">
                            </button>
                        </div>
                        
                        <div class="filter-actions">
                            <?php if($dept_filter > 0 || $course_filter > 0 || $subject_filter > 0 || $section_filter || $semester_filter > 0 || $search_query): ?>
                            <a href="view_students.php" class="btn btn-secondary" style="padding: 10px 20px;">Clear Filters</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Statistics Section -->
            <?php if($students && $students->num_rows > 0): ?>
            <div class="stats-section">
                <div class="stat-card">
                    <div class="stat-icon">
                        <img src="../icons/student.png" alt="Total">
                    </div>
                    <div class="stat-content">
                        <h3>Total Students</h3>
                        <div class="stat-number"><?php echo $total_students; ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <img src="../icons/gender.png" alt="Gender">
                    </div>
                    <div class="stat-content">
                        <h3>Gender Distribution</h3>
                        <div class="gender-distribution">
                            <span class="gender-item gender-male">Male: <?php echo $male_count ?? 0; ?></span>
                            <span class="gender-item gender-female">Female: <?php echo $female_count ?? 0; ?></span>
                            <?php if($other_count > 0): ?>
                            <span class="gender-item gender-other">Other: <?php echo $other_count; ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Students Table -->
            <div class="students-table-container">
                <?php if($students && $students->num_rows > 0): ?>
                    <table class="students-table">
                        <thead>
                            <tr>
                                <th>Roll No</th>
                                <th>Student</th>
                                <th>Course</th>
                                <th>Department</th>
                                <th>Semester</th>
                                <th>Section</th>
                                <th>Contact</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $students->data_seek(0);
                            while($student = $students->fetch_assoc()): 
                            ?>
                            <tr>
                                <td><strong><?php echo $student['roll_number']; ?></strong></td>
                                <td>
                                    <div class="student-info">
                                        <div class="student-avatar">
                                            <?php echo strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)); ?>
                                        </div>
                                        <div>
                                            <div class="student-name"><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></div>
                                            <div class="student-email"><?php echo $student['email']; ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $student['course_name']; ?></td>
                                <td><?php echo $student['dept_name']; ?></td>
                                <td>
                                    <span class="badge badge-primary">Sem <?php echo $student['current_semester']; ?></span>
                                </td>
                                <td>
                                    <span class="badge badge-success">Sec <?php echo $student['section']; ?></span>
                                </td>
                                <td>
                                    <div><?php echo $student['phone']; ?></div>
                                    <small><?php echo $student['email']; ?></small>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="action-btn btn-view" onclick="viewStudentDetails(<?php echo $student['student_id']; ?>)" title="View Details">
                                            <img src="../icons/Detail.png" alt="View"> View
                                        </button>
                                        <a href="marks_entry.php?subject_id=<?php echo $subject_filter; ?>&section=<?php echo $section_filter; ?>" class="action-btn btn-marks" title="Enter Marks">
                                            <img src="../icons/result.png" alt="Marks"> Marks
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    
                <?php elseif($dept_filter > 0 || $course_filter > 0 || $subject_filter > 0 || $section_filter || $semester_filter > 0 || $search_query): ?>
                    <div class="empty-state">
                        <img src="../icons/empty.png" alt="No Results">
                        <h3>No Students Found</h3>
                        <p>No students match your current filter criteria. Try adjusting your filters.</p>
                        <a href="view_students.php" class="btn btn-primary" style="margin-top: 15px;">Clear Filters</a>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <img src="../icons/empty.png" alt="Select Filters">
                        <h3>Select Filters to View Students</h3>
                        <p>Please select department, course, subject, or section to view students.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Student Details Modal -->
    <div id="studentModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="document.getElementById('studentModal').style.display='none'">&times;</span>
            <h2 style="margin-bottom: 20px;">Student Details</h2>
            <div id="modalContent">
                <div style="text-align: center; padding: 30px;">
                    <div class="loading-spinner"></div>
                    <p>Loading student details...</p>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        function viewStudentDetails(studentId) {
            document.getElementById('studentModal').style.display = 'block';
            document.getElementById('modalContent').innerHTML = '<div style="text-align: center; padding: 30px;"><div class="loading-spinner"></div><p>Loading student details...</p></div>';
            
            fetch('view_students.php?ajax=get_student_details&student_id=' + studentId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayStudentDetails(data);
                    } else {
                        document.getElementById('modalContent').innerHTML = '<p style="color: red; text-align: center;">Error loading student details.</p>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('modalContent').innerHTML = '<p style="color: red; text-align: center;">Error loading student details.</p>';
                });
        }
        
        function displayStudentDetails(data) {
            const student = data.student;
            const subjects = data.subjects;
            const results = data.results;
            
            let subjectsHtml = '';
            if (subjects.length > 0) {
                subjectsHtml = '<h3 style="margin: 20px 0 10px;">Enrolled Subjects</h3>';
                subjectsHtml += '<table class="subjects-table">';
                subjectsHtml += '<thead><tr><th>Subject</th><th>Code</th><th>Type</th><th>Semester</th><th>Credit Hours</th></tr></thead>';
                subjectsHtml += '<tbody>';
                
                subjects.forEach(subject => {
                    let typeClass = 'type-' + subject.subject_type;
                    subjectsHtml += '<tr>';
                    subjectsHtml += '<td>' + subject.subject_name + '</td>';
                    subjectsHtml += '<td>' + subject.subject_code + '</td>';
                    subjectsHtml += '<td><span class="subject-type ' + typeClass + '">' + subject.subject_type.charAt(0).toUpperCase() + subject.subject_type.slice(1) + '</span></td>';
                    subjectsHtml += '<td>Semester ' + subject.semester + '</td>';
                    subjectsHtml += '<td>' + subject.credit_hours + '</td>';
                    subjectsHtml += '</tr>';
                });
                
                subjectsHtml += '</tbody></table>';
            } else {
                subjectsHtml = '<p style="color: #666; margin: 20px 0;">No subjects enrolled.</p>';
            }
            
            let resultsHtml = '';
            if (results.length > 0) {
                resultsHtml = '<h3 style="margin: 20px 0 10px;">Recent Results</h3>';
                resultsHtml += '<table class="results-table">';
                resultsHtml += '<thead><tr><th>Exam</th><th>Subject</th><th>Marks</th><th>Grade</th><th>Date</th></tr></thead>';
                resultsHtml += '<tbody>';
                
                results.forEach(result => {
                    resultsHtml += '<tr>';
                    resultsHtml += '<td>' + result.exam_name + '</td>';
                    resultsHtml += '<td>' + result.subject_name + '</td>';
                    resultsHtml += '<td><strong>' + result.marks_obtained + '</strong></td>';
                    resultsHtml += '<td><span class="badge badge-info">' + result.grade + '</span></td>';
                    resultsHtml += '<td>' + new Date(result.exam_date).toLocaleDateString() + '</td>';
                    resultsHtml += '</tr>';
                });
                
                resultsHtml += '</tbody></table>';
            }
            
            const html = `
                <div class="detail-card">
                    <h3 style="margin-top: 0; color: white;">${student.first_name} ${student.middle_name} ${student.last_name}</h3>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Roll Number</span>
                            <span class="detail-value">${student.roll_number}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Course</span>
                            <span class="detail-value">${student.course_name}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Department</span>
                            <span class="detail-value">${student.dept_name}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Batch</span>
                            <span class="detail-value">${student.batch_name || 'N/A'}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Current Semester</span>
                            <span class="detail-value">${student.current_semester}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Section</span>
                            <span class="detail-value">${student.section}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Date of Birth</span>
                            <span class="detail-value">${new Date(student.dob).toLocaleDateString()}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Gender</span>
                            <span class="detail-value">${student.gender}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Email</span>
                            <span class="detail-value">${student.email}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Phone</span>
                            <span class="detail-value">${student.phone}</span>
                        </div>
                        <div class="detail-item" style="grid-column: span 2;">
                            <span class="detail-label">Address</span>
                            <span class="detail-value">${student.address || 'N/A'}</span>
                        </div>
                    </div>
                </div>
                
                ${subjectsHtml}
                ${resultsHtml}
                
                <div style="margin-top: 20px; text-align: right;">
                    <button class="btn btn-primary" onclick="document.getElementById('studentModal').style.display='none'">Close</button>
                </div>
            `;
            
            document.getElementById('modalContent').innerHTML = html;
        }
        
        // Auto-submit form when filters change
        document.querySelectorAll('#filterForm select').forEach(select => {
            select.addEventListener('change', function() {
                document.getElementById('filterForm').submit();
            });
        });
        
        // Debounce search input
        let searchTimeout;
        document.querySelector('input[name="search"]').addEventListener('keyup', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                document.getElementById('filterForm').submit();
            }, 500);
        });
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('studentModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>
</body>
</html>