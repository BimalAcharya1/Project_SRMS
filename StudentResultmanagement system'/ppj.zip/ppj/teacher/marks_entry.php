<?php
require_once '../includes/auth_check.php';
checkTeacherLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

$teacher_id = $_SESSION['teacher_id'];

// Handle AJAX validation for marks
if (isset($_GET['ajax']) && $_GET['ajax'] == 'validate_marks') {
    $subject_id = intval($_GET['subject_id']);
    $exam_id = intval($_GET['exam_id']);
    $theory_marks = isset($_GET['theory_marks']) ? floatval($_GET['theory_marks']) : 0;
    $practical_marks = isset($_GET['practical_marks']) ? floatval($_GET['practical_marks']) : 0;
    $student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
    
    // Get exam subject details
    $query = "SELECT * FROM Exam_Subject WHERE exam_id = $exam_id AND subject_id = $subject_id";
    $result = $conn->query($query);
    
    $response = ['valid' => true, 'message' => '', 'total' => 0, 'grade' => ''];
    
    if ($result && $result->num_rows > 0) {
        $exam_subject = $result->fetch_assoc();
        $errors = [];
        
        // Validate theory marks (max 60)
        if ($theory_marks > 60) {
            $errors[] = 'Theory marks cannot exceed 60';
        } elseif ($theory_marks < 0) {
            $errors[] = 'Theory marks cannot be negative';
        }
        
        // Validate practical marks (max 40)
        if ($practical_marks > 40) {
            $errors[] = 'Practical marks cannot exceed 40';
        } elseif ($practical_marks < 0) {
            $errors[] = 'Practical marks cannot be negative';
        }
        
        // Validate total marks (theory + practical) does not exceed 100
        $total_marks = $theory_marks + $practical_marks;
        if ($total_marks > 100) {
            $errors[] = 'Total marks (Theory + Practical) cannot exceed 100';
        }
        
        if (!empty($errors)) {
            $response['valid'] = false;
            $response['message'] = implode('. ', $errors);
        } else {
            $response['total'] = $total_marks;
            // Calculate grade with fail condition for theory < 24 or practical < 18
            $response['grade'] = calculateGrade($theory_marks, $practical_marks);
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Get filter parameters
$dept_filter = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;
$course_filter = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$subject_filter = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
$section_filter = isset($_GET['section']) ? $database->escapeString($_GET['section']) : '';
$exam_filter = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;

// Get teacher's allocations for selection
$allocations = $conn->query("
    SELECT ta.*, 
           s.subject_name, s.subject_code, s.semester_number,
           c.course_name, c.course_id,
           d.dept_name, d.dept_id
    FROM Teacher_Allocation ta
    JOIN Subject s ON ta.subject_id = s.subject_id
    JOIN Course c ON s.course_id = c.course_id
    JOIN Department d ON c.dept_id = d.dept_id
    WHERE ta.teacher_id = $teacher_id
    ORDER BY d.dept_name, c.course_name, s.semester_number, s.subject_name
");

// Get departments for filter (only those where teacher has allocations)
$departments = $conn->query("
    SELECT DISTINCT d.dept_id, d.dept_name
    FROM Teacher_Allocation ta
    JOIN Subject s ON ta.subject_id = s.subject_id
    JOIN Course c ON s.course_id = c.course_id
    JOIN Department d ON c.dept_id = d.dept_id
    WHERE ta.teacher_id = $teacher_id
    ORDER BY d.dept_name
");

// Get courses based on selected department
$filter_courses = null;
if ($dept_filter > 0) {
    $filter_courses = $conn->query("
        SELECT DISTINCT c.course_id, c.course_name
        FROM Teacher_Allocation ta
        JOIN Subject s ON ta.subject_id = s.subject_id
        JOIN Course c ON s.course_id = c.course_id
        WHERE ta.teacher_id = $teacher_id AND c.dept_id = $dept_filter
        ORDER BY c.course_name
    ");
}

// Get subjects based on selected course
$filter_subjects = null;
if ($course_filter > 0) {
    $filter_subjects = $conn->query("
        SELECT DISTINCT s.subject_id, s.subject_name, s.subject_code, s.semester_number
        FROM Teacher_Allocation ta
        JOIN Subject s ON ta.subject_id = s.subject_id
        WHERE ta.teacher_id = $teacher_id AND s.course_id = $course_filter
        ORDER BY s.semester_number, s.subject_name
    ");
}

// Get sections based on selected subject
$filter_sections = null;
if ($subject_filter > 0) {
    $filter_sections = $conn->query("
        SELECT DISTINCT ta.section
        FROM Teacher_Allocation ta
        WHERE ta.teacher_id = $teacher_id AND ta.subject_id = $subject_filter AND ta.section IS NOT NULL
        ORDER BY ta.section
    ");
}

// Get exams
$exams = $conn->query("
    SELECT e.* 
    FROM Exam e
    WHERE e.is_active = 1
    ORDER BY e.exam_date DESC
");

// Get selected allocation details if filters are applied
$selected_subject = null;
$selected_section = null;
$students = null;
$existing_results = [];
$exam_subject_details = null;

if ($subject_filter > 0 && !empty($section_filter)) {
    // Get subject details
    $subject_result = $conn->query("
        SELECT s.*, c.course_name, d.dept_name
        FROM Subject s
        JOIN Course c ON s.course_id = c.course_id
        JOIN Department d ON c.dept_id = d.dept_id
        WHERE s.subject_id = $subject_filter
    ");
    $selected_subject = $subject_result->fetch_assoc();
    
    // Get section
    $selected_section = $section_filter;
    
    // Get exam subject details if exam is selected
    if ($exam_filter > 0) {
        $exam_subject_result = $conn->query("
            SELECT * FROM Exam_Subject 
            WHERE exam_id = $exam_filter AND subject_id = $subject_filter
        ");
        $exam_subject_details = $exam_subject_result->fetch_assoc();
    }
    
    // Get students in this subject and section
    $students = $conn->query("
        SELECT DISTINCT s.*
        FROM Student s
        INNER JOIN Teacher_Allocation ta ON s.course_id = (
            SELECT course_id FROM Subject WHERE subject_id = $subject_filter
        )
        WHERE ta.subject_id = $subject_filter 
        AND ta.section = '$section_filter'
        ORDER BY s.roll_number
    ");
    
    // Get existing results if exam is selected
    if ($exam_filter > 0) {
        $results_query = $conn->query("
            SELECT r.* 
            FROM Result r
            WHERE r.subject_id = $subject_filter 
            AND r.exam_id = $exam_filter
        ");
        
        while ($result = $results_query->fetch_assoc()) {
            $existing_results[$result['student_id']] = $result;
        }
    }
}

// Handle marks submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_marks'])) {
    $subject_id = intval($_POST['subject_id']);
    $section = $database->escapeString($_POST['section']);
    $exam_id = intval($_POST['exam_id']);
    
    // Get exam subject details for validation
    $exam_subject_query = $conn->query("SELECT * FROM Exam_Subject WHERE exam_id = $exam_id AND subject_id = $subject_id");
    $exam_subject = $exam_subject_query->fetch_assoc();
    
    $conn->begin_transaction();
    
    try {
        $saved_count = 0;
        
        // Check if theory_marks exists and is an array
        if (isset($_POST['theory_marks']) && is_array($_POST['theory_marks'])) {
            foreach ($_POST['theory_marks'] as $student_id => $theory_mark) {
                $student_id = intval($student_id);
                
                // Skip if theory mark is empty or not set
                if ($theory_mark === '' || $theory_mark === null) {
                    continue;
                }
                
                $theory_mark = floatval($theory_mark);
                
                // Get practical mark for this student
                $practical_mark = 0;
                if (isset($_POST['practical_marks']) && is_array($_POST['practical_marks']) && isset($_POST['practical_marks'][$student_id])) {
                    $practical_mark = $_POST['practical_marks'][$student_id] !== '' ? floatval($_POST['practical_marks'][$student_id]) : 0;
                }
                
                // Validate marks
                if ($theory_mark > 60) {
                    throw new Exception("Theory marks cannot exceed 60 for student ID: $student_id");
                }
                
                if ($practical_mark > 40) {
                    throw new Exception("Practical marks cannot exceed 40 for student ID: $student_id");
                }
                
                if ($theory_mark < 0) {
                    throw new Exception("Theory marks cannot be negative for student ID: $student_id");
                }
                
                if ($practical_mark < 0) {
                    throw new Exception("Practical marks cannot be negative for student ID: $student_id");
                }
                
                // Validate total marks (theory + practical) does not exceed 100
                $total_marks = $theory_mark + $practical_mark;
                if ($total_marks > 100) {
                    throw new Exception("Total marks (Theory + Practical) cannot exceed 100 for student ID: $student_id");
                }
                
                // Calculate grade with fail condition
                $grade = calculateGrade($theory_mark, $practical_mark);
                
                // Check if result already exists
                $check_query = "SELECT result_id FROM Result 
                               WHERE student_id = $student_id 
                               AND subject_id = $subject_id
                               AND exam_id = $exam_id";
                $check_result = $conn->query($check_query);
                
                if ($check_result && $check_result->num_rows > 0) {
                    // Update
                    $sql = "UPDATE Result SET 
                            theory_marks = $theory_mark,
                            practical_marks = $practical_mark,
                            grade = '$grade'
                            WHERE student_id = $student_id 
                            AND subject_id = $subject_id
                            AND exam_id = $exam_id";
                } else {
                    // Insert
                    $sql = "INSERT INTO Result (student_id, subject_id, exam_id, theory_marks, practical_marks, grade) 
                            VALUES ($student_id, $subject_id, $exam_id, $theory_mark, $practical_mark, '$grade')";
                }
                
                if (!$conn->query($sql)) {
                    throw new Exception("Error saving marks for student ID: $student_id - " . $conn->error);
                }
                
                $saved_count++;
            }
        }
        
        $conn->commit();
        
        // Set success message
        $_SESSION['message'] = "$saved_count student records saved successfully!";
        $_SESSION['msg_type'] = "success";
        
        // Redirect to refresh the page with the same filters
        $redirect_url = "marks_entry.php?subject_id=$subject_id&section=" . urlencode($section) . "&exam_id=$exam_id";
        header("Location: $redirect_url");
        exit();
        
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['message'] = "Error: " . $e->getMessage();
        $_SESSION['msg_type'] = "error";
        
        // Redirect back to the form
        $redirect_url = "marks_entry.php?subject_id=$subject_id&section=" . urlencode($section) . "&exam_id=$exam_id";
        header("Location: $redirect_url");
        exit();
    }
}

// Helper function to calculate grade with fail condition
function calculateGrade($theory_marks, $practical_marks) {
    $total = $theory_marks + $practical_marks;
    
    // Fail if theory marks < 24 or practical marks < 18
    if ($theory_marks < 24 || $practical_marks < 18) {
        return 'F';
    }
    
    if ($total >= 90) return 'A+';
    if ($total >= 80) return 'A';
    if ($total >= 70) return 'B+';
    if ($total >= 60) return 'B';
    if ($total >= 50) return 'C+';
    if ($total >= 40) return 'C';
    if ($total >= 33) return 'D';
    return 'F';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Marks Entry - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Marks Entry Specific Styles */
        .filters-section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .filter-item {
            display: flex;
            flex-direction: column;
        }
        
        .filter-item label {
            font-size: 13px;
            color: #666;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .filter-item select, .filter-item input {
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .filter-item select:focus, .filter-item input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .filter-item select:disabled {
            background: #f5f5f5;
            cursor: not-allowed;
        }
        
        .marks-section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .subject-info {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .subject-info h3 {
            margin: 0;
            font-size: 20px;
            font-weight: 700;
        }
        
        .subject-info p {
            margin: 5px 0 0;
            opacity: 0.9;
            font-weight: 500;
        }
        
        .info-badge {
            background: rgba(255, 255, 255, 0.2);
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            margin-right: 10px;
        }
        
        .marks-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }
        
        .marks-info-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .marks-info-label {
            font-weight: 700;
            color: #333;
        }
        
        .marks-info-value {
            padding: 5px 12px;
            background: white;
            border-radius: 20px;
            color: #667eea;
            font-weight: 700;
            border: 1px solid #667eea;
        }
        
        .marks-info-value.warning {
            color: #856404;
            border-color: #856404;
        }
        
        .marks-table-container {
            overflow-x: auto;
            margin-top: 20px;
            max-height: 500px;
            overflow-y: auto;
        }
        
        .marks-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .marks-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 700;
            color: #333;
            border-bottom: 2px solid #dee2e6;
            font-size: 14px;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .marks-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
            vertical-align: middle;
        }
        
        .marks-table tr:hover {
            background: #f8f9fa;
        }
        
        .marks-table tr.failed-row {
            background-color: #fff3f3;
        }
        
        .roll-number {
            font-weight: 700;
            color: #333;
        }
        
        .marks-input {
            width: 80px;
            padding: 8px 8px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
            text-align: center;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .marks-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .marks-input.valid {
            border-color: #28a745;
            background: #f0fff4;
        }
        
        .marks-input.invalid {
            border-color: #dc3545;
            background: #fff5f5;
        }
        
        .validation-message {
            font-size: 11px;
            margin-top: 3px;
            color: #dc3545;
            min-height: 16px;
            font-weight: 500;
        }
        
        .grade-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }
        
        .grade-a-plus { background: #28a745; color: white; }
        .grade-a { background: #5cb85c; color: white; }
        .grade-b-plus { background: #5bc0de; color: white; }
        .grade-b { background: #f0ad4e; color: white; }
        .grade-c-plus { background: #d9534f; color: white; }
        .grade-c { background: #d9534f; color: white; }
        .grade-d { background: #d9534f; color: white; }
        .grade-f { background: #dc3545; color: white; }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 25px;
            justify-content: flex-end;
        }
        
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-primary:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        
        .empty-state img {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .empty-state h3 {
            color: #333;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .total-value {
            font-weight: 700;
            color: #333;
        }
        
        .total-value.warning {
            color: #856404;
        }
        
        .total-value.error {
            color: #dc3545;
        }
        
        .loading-spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 5px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .pass-mark-info {
            font-size: 12px;
            color: #666;
            margin-top: 2px;
        }
        
        @media (max-width: 768px) {
            .filter-grid {
                grid-template-columns: 1fr;
            }
            
            .subject-info {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .marks-table td {
                min-width: 100px;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Teacher.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Teacher
            </div>
            <div class="navbar-menu">
                <a href="teacher_dashboard.php">
                    <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
                </a>
                <a href="marks_entry.php" class="active">
                    <img src="../icons/Addmarks.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Marks Entry</h5>
                </a>
                <a href="view_students.php">
                    <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>View Students</h5>
                </a>
                <a href="teacher_settings.php">
                    <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Settings</h5>
                </a>
                <a href="../logout.php">
                    <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Logout</h5>
                </a>
            </div>
        </nav>
        
        <div class="content">
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type'] == 'success' ? 'success' : 'error'; ?>">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <h1><img src="../icons/Addmarks.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Marks Entry</h1>
            
            <!-- Filters Section -->
            <div class="filters-section">
                <h3 style="margin-bottom: 15px; font-weight: 700;">Select Subject and Section</h3>
                <form method="GET" action="marks_entry.php" id="filterForm">
                    <div class="filter-grid">
                        <div class="filter-item">
                            <label style="font-weight: 600;">Department</label>
                            <select name="dept_id" id="dept_filter" onchange="this.form.submit()">
                                <option value="0">All Departments</option>
                                <?php 
                                if($departments) {
                                    $departments->data_seek(0);
                                    while($dept = $departments->fetch_assoc()): 
                                        $selected = ($dept_filter == $dept['dept_id']) ? 'selected' : '';
                                ?>
                                <option value="<?php echo $dept['dept_id']; ?>" <?php echo $selected; ?>>
                                    <?php echo htmlspecialchars($dept['dept_name']); ?>
                                </option>
                                <?php 
                                    endwhile;
                                } 
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label style="font-weight: 600;">Course</label>
                            <select name="course_id" id="course_filter" onchange="this.form.submit()" <?php echo $dept_filter == 0 ? 'disabled' : ''; ?>>
                                <option value="0">All Courses</option>
                                <?php 
                                if($filter_courses) {
                                    $filter_courses->data_seek(0);
                                    while($course = $filter_courses->fetch_assoc()): 
                                        $selected = ($course_filter == $course['course_id']) ? 'selected' : '';
                                ?>
                                <option value="<?php echo $course['course_id']; ?>" <?php echo $selected; ?>>
                                    <?php echo htmlspecialchars($course['course_name']); ?>
                                </option>
                                <?php 
                                    endwhile;
                                } 
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label style="font-weight: 600;">Subject</label>
                            <select name="subject_id" id="subject_filter" onchange="this.form.submit()" <?php echo $course_filter == 0 ? 'disabled' : ''; ?>>
                                <option value="0">Select Subject</option>
                                <?php 
                                if($filter_subjects) {
                                    $filter_subjects->data_seek(0);
                                    while($subject = $filter_subjects->fetch_assoc()): 
                                        $selected = ($subject_filter == $subject['subject_id']) ? 'selected' : '';
                                ?>
                                <option value="<?php echo $subject['subject_id']; ?>" <?php echo $selected; ?>>
                                    <?php echo htmlspecialchars($subject['subject_name']); ?> (Sem <?php echo $subject['semester_number']; ?>)
                                </option>
                                <?php 
                                    endwhile;
                                } 
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label style="font-weight: 600;">Section</label>
                            <select name="section" id="section_filter" onchange="this.form.submit()" <?php echo $subject_filter == 0 ? 'disabled' : ''; ?>>
                                <option value="">Select Section</option>
                                <?php 
                                if($filter_sections) {
                                    $filter_sections->data_seek(0);
                                    while($section = $filter_sections->fetch_assoc()): 
                                        $selected = ($section_filter == $section['section']) ? 'selected' : '';
                                ?>
                                <option value="<?php echo htmlspecialchars($section['section']); ?>" <?php echo $selected; ?>>
                                    Section <?php echo htmlspecialchars($section['section']); ?>
                                </option>
                                <?php 
                                    endwhile;
                                } 
                                ?>
                            </select>
                        </div>
                        
                        <div class="filter-item">
                            <label style="font-weight: 600;">Exam</label>
                            <select name="exam_id" id="exam_filter" onchange="this.form.submit()">
                                <option value="0">Select Exam</option>
                                <?php 
                                $exams->data_seek(0);
                                while($exam = $exams->fetch_assoc()): 
                                    $selected = ($exam_filter == $exam['exam_id']) ? 'selected' : '';
                                ?>
                                <option value="<?php echo $exam['exam_id']; ?>" <?php echo $selected; ?>>
                                    <?php echo htmlspecialchars($exam['exam_name']); ?> (<?php echo htmlspecialchars($exam['exam_type']); ?>)
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <?php if($subject_filter > 0 || $exam_filter > 0 || $section_filter): ?>
                        <div class="filter-item" style="display: flex; align-items: flex-end;">
                            <a href="marks_entry.php" class="btn btn-secondary" style="padding: 10px 20px;">Clear Filters</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            
            <!-- Marks Entry Section -->
            <?php if($selected_subject && $selected_section && $exam_filter > 0): ?>
                <div class="marks-section">
                    <div class="subject-info">
                        <div>
                            <h3><?php echo htmlspecialchars($selected_subject['subject_name']); ?> (<?php echo htmlspecialchars($selected_subject['subject_code']); ?>)</h3>
                            <p><?php echo htmlspecialchars($selected_subject['course_name']); ?> | <?php echo htmlspecialchars($selected_subject['dept_name']); ?></p>
                        </div>
                        <div>
                            <span class="info-badge">Semester <?php echo $selected_subject['semester_number']; ?></span>
                            <span class="info-badge">Section <?php echo htmlspecialchars($selected_section); ?></span>
                        </div>
                    </div>
                    
                    <?php if($students && $students->num_rows > 0): ?>
                        <form method="POST" action="marks_entry.php" id="marksForm" onsubmit="return validateForm()">
                            <input type="hidden" name="save_marks" value="1">
                            <input type="hidden" name="subject_id" value="<?php echo $subject_filter; ?>">
                            <input type="hidden" name="section" value="<?php echo htmlspecialchars($section_filter); ?>">
                            <input type="hidden" name="exam_id" value="<?php echo $exam_filter; ?>">
                            
                            <!-- Marks Table -->
                            <div class="marks-table-container">
                                <table class="marks-table">
                                    <thead>
                                        <tr>
                                            <th>Roll No</th>
                                            <th>Student Name</th>
                                            <th class="theory-header">Theory (Max:60)</th>
                                            <th class="practical-header">Practical (Max:40)</th>
                                            <th class="total-header">Total</th>
                                            <th>Grade</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $students->data_seek(0);
                                        while($student = $students->fetch_assoc()): 
                                            $student_id = $student['student_id'];
                                            $existing = isset($existing_results[$student_id]) ? $existing_results[$student_id] : null;
                                            
                                            // Get theory and practical marks from existing results
                                            $theory_marks = $existing ? $existing['theory_marks'] : '';
                                            $practical_marks = $existing ? $existing['practical_marks'] : '';
                                            $total = $existing ? $existing['total_marks'] : '';
                                            $grade = $existing ? $existing['grade'] : '';
                                            
                                            // Check if student has failed based on pass marks
                                            $is_failed = ($theory_marks !== '' && $theory_marks < 24) || ($practical_marks !== '' && $practical_marks < 18);
                                        ?>
                                        <tr data-student-id="<?php echo $student_id; ?>" class="<?php echo $is_failed ? 'failed-row' : ''; ?>">
                                            <td><span class="roll-number"><?php echo htmlspecialchars($student['roll_number']); ?></span></td>
                                            <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                            <td>
                                                <input type="number" 
                                                       name="theory_marks[<?php echo $student_id; ?>]" 
                                                       id="theory_<?php echo $student_id; ?>"
                                                       value="<?php echo $theory_marks; ?>"
                                                       step="0.01" 
                                                       min="0" 
                                                       max="60" 
                                                       class="marks-input theory-input"
                                                       data-student-id="<?php echo $student_id; ?>"
                                                       data-type="theory"
                                                       data-max="60"
                                                       oninput="validateMarks(this)"
                                                       onchange="validateMarks(this)"
                                                       required>
                                                <div class="validation-message" id="theory_error_<?php echo $student_id; ?>"></div>
                                            </td>
                                            <td>
                                                <input type="number" 
                                                       name="practical_marks[<?php echo $student_id; ?>]" 
                                                       id="practical_<?php echo $student_id; ?>"
                                                       value="<?php echo $practical_marks; ?>"
                                                       step="0.01" 
                                                       min="0" 
                                                       max="40" 
                                                       class="marks-input practical-input"
                                                       data-student-id="<?php echo $student_id; ?>"
                                                       data-type="practical"
                                                       data-max="40"
                                                       oninput="validateMarks(this)"
                                                       onchange="validateMarks(this)">
                                                <div class="validation-message" id="practical_error_<?php echo $student_id; ?>"></div>
                                            </td>
                                            <td>
                                                <span id="total_<?php echo $student_id; ?>" class="total-value <?php echo ($total && $total > 100) ? 'error' : (($total && $total > 90) ? 'warning' : ''); ?>">
                                                    <?php echo $total !== '' ? number_format($total, 2) : '-'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span id="grade_<?php echo $student_id; ?>" class="grade-badge <?php echo $grade ? 'grade-' . strtolower(str_replace('+', '-plus', $grade)) : ''; ?>">
                                                    <?php echo $grade ?: '-'; ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Action Buttons -->
                            <div class="action-buttons">
                                <button type="submit" name="save_marks" class="btn btn-primary" id="saveButton">
                                    <img src="../icons/save.png" style="height: 18px; vertical-align: middle;"> Save Marks
                                </button>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="empty-state">
                            <img src="../icons/empty.png" alt="No Students">
                            <h3>No Students Found</h3>
                            <p>There are no students allocated to this subject and section.</p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php elseif($subject_filter > 0 && empty($section_filter)): ?>
                <div class="empty-state">
                    <img src="../icons/empty.png" alt="Select Section">
                    <h3>Select a Section</h3>
                    <p>Please select a section to view students and enter marks.</p>
                </div>
            <?php elseif($exam_filter == 0): ?>
                <div class="empty-state">
                    <img src="../icons/empty.png" alt="Select Exam">
                    <h3>Select an Exam</h3>
                    <p>Please select an exam to enter marks.</p>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <img src="../icons/empty.png" alt="Select Subject">
                    <h3>Select a Subject</h3>
                    <p>Please select a subject, section, and exam to start entering marks.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let validationTimeouts = {};
        let activeRequests = {};
        
        function validateMarks(input) {
            const studentId = input.dataset.studentId;
            const type = input.dataset.type;
            const value = input.value;
            const maxMarks = parseFloat(input.dataset.max);
            
            // Get all inputs for this student
            const theoryInput = document.getElementById('theory_' + studentId);
            const practicalInput = document.getElementById('practical_' + studentId);
            const theoryError = document.getElementById('theory_error_' + studentId);
            const practicalError = document.getElementById('practical_error_' + studentId);
            
            // Clear previous timeout for this student/type combination
            const timeoutKey = studentId + '_' + type;
            if (validationTimeouts[timeoutKey]) {
                clearTimeout(validationTimeouts[timeoutKey]);
            }
            
            // Basic client-side validation
            if (value === '') {
                input.classList.remove('valid', 'invalid');
                if (type === 'theory' && theoryError) theoryError.innerHTML = '';
                if (type === 'practical' && practicalError) practicalError.innerHTML = '';
                
                // Update total and grade with current values
                const theoryVal = theoryInput ? theoryInput.value : 0;
                const practicalVal = practicalInput ? practicalInput.value : 0;
                updateTotalAndGrade(studentId, theoryVal, practicalVal);
                return;
            }
            
            const numValue = parseFloat(value);
            
            // Check against max marks
            if (numValue > maxMarks) {
                input.classList.add('invalid');
                input.classList.remove('valid');
                if (type === 'theory' && theoryError) {
                    theoryError.innerHTML = 'Cannot exceed ' + maxMarks;
                }
                if (type === 'practical' && practicalError) {
                    practicalError.innerHTML = 'Cannot exceed ' + maxMarks;
                }
                
                // Update total and grade with current values
                const theoryVal = theoryInput ? theoryInput.value : 0;
                const practicalVal = practicalInput ? practicalInput.value : 0;
                updateTotalAndGrade(studentId, theoryVal, practicalVal);
                return;
            }
            
            // Check for negative values
            if (numValue < 0) {
                input.classList.add('invalid');
                input.classList.remove('valid');
                if (type === 'theory' && theoryError) {
                    theoryError.innerHTML = 'Cannot be negative';
                }
                if (type === 'practical' && practicalError) {
                    practicalError.innerHTML = 'Cannot be negative';
                }
                
                // Update total and grade with current values
                const theoryVal = theoryInput ? theoryInput.value : 0;
                const practicalVal = practicalInput ? practicalInput.value : 0;
                updateTotalAndGrade(studentId, theoryVal, practicalVal);
                return;
            }
            
            // Clear error messages for this input
            if (type === 'theory' && theoryError) theoryError.innerHTML = '';
            if (type === 'practical' && practicalError) practicalError.innerHTML = '';
            
            // Show pending state
            input.classList.remove('valid', 'invalid');
            
            // Set timeout to validate with server
            validationTimeouts[timeoutKey] = setTimeout(function() {
                validateWithServer(studentId, theoryInput ? theoryInput.value : 0, practicalInput ? practicalInput.value : 0);
            }, 500);
            
            // Update total and grade immediately
            const theoryVal = theoryInput ? theoryInput.value : 0;
            const practicalVal = practicalInput ? practicalInput.value : 0;
            updateTotalAndGrade(studentId, theoryVal, practicalVal);
        }
        
        function validateWithServer(studentId, theoryMarks, practicalMarks) {
            // Cancel any ongoing request for this student
            if (activeRequests[studentId]) {
                activeRequests[studentId].abort();
            }
            
            const subjectId = <?php echo $subject_filter ?: 0; ?>;
            const examId = <?php echo $exam_filter ?: 0; ?>;
            
            if (subjectId === 0 || examId === 0) return;
            
            // Create abort controller for this request
            const controller = new AbortController();
            activeRequests[studentId] = controller;
            
            const url = 'marks_entry.php?ajax=validate_marks' +
                       '&subject_id=' + subjectId +
                       '&exam_id=' + examId +
                       '&theory_marks=' + (theoryMarks || 0) +
                       '&practical_marks=' + (practicalMarks || 0) +
                       '&student_id=' + studentId;
            
            fetch(url, {
                signal: controller.signal
            })
            .then(response => response.json())
            .then(data => {
                if (activeRequests[studentId] === controller) {
                    delete activeRequests[studentId];
                }
                
                const theoryInput = document.getElementById('theory_' + studentId);
                const practicalInput = document.getElementById('practical_' + studentId);
                const theoryError = document.getElementById('theory_error_' + studentId);
                const practicalError = document.getElementById('practical_error_' + studentId);
                const row = document.querySelector(`tr[data-student-id="${studentId}"]`);
                
                if (data.valid) {
                    // Mark inputs as valid
                    if (theoryInput && theoryInput.value) {
                        theoryInput.classList.add('valid');
                        theoryInput.classList.remove('invalid');
                    }
                    if (practicalInput && practicalInput.value) {
                        practicalInput.classList.add('valid');
                        practicalInput.classList.remove('invalid');
                    }
                    
                    // Clear error messages
                    if (theoryError) theoryError.innerHTML = '';
                    if (practicalError) practicalError.innerHTML = '';
                    
                    // Update total and grade from server response
                    if (data.total !== undefined) {
                        const totalSpan = document.getElementById('total_' + studentId);
                        const gradeSpan = document.getElementById('grade_' + studentId);
                        
                        if (data.total > 0) {
                            totalSpan.textContent = data.total.toFixed(2);
                            totalSpan.className = 'total-value ' + (data.total > 90 ? 'warning' : '');
                            
                            gradeSpan.textContent = data.grade;
                            gradeSpan.className = 'grade-badge grade-' + data.grade.toLowerCase().replace('+', '-plus');
                            
                            // Check if student has failed based on pass marks
                            if (data.grade === 'F') {
                                row.classList.add('failed-row');
                            } else {
                                row.classList.remove('failed-row');
                            }
                        }
                    }
                } else {
                    // Mark inputs as invalid and show error message
                    if (theoryInput && theoryInput.value) {
                        theoryInput.classList.add('invalid');
                        theoryInput.classList.remove('valid');
                    }
                    if (practicalInput && practicalInput.value) {
                        practicalInput.classList.add('invalid');
                        practicalInput.classList.remove('valid');
                    }
                    
                    // Display error message in the appropriate field
                    if (data.message) {
                        if (data.message.toLowerCase().includes('theory') && theoryError) {
                            theoryError.innerHTML = data.message;
                        } else if (data.message.toLowerCase().includes('practical') && practicalError) {
                            practicalError.innerHTML = data.message;
                        } else if (theoryError) {
                            theoryError.innerHTML = data.message;
                        }
                    }
                }
            })
            .catch(error => {
                if (error.name !== 'AbortError') {
                    console.error('Validation error:', error);
                }
                if (activeRequests[studentId] === controller) {
                    delete activeRequests[studentId];
                }
            });
        }
        
        function updateTotalAndGrade(studentId, theoryMarks, practicalMarks) {
            const totalSpan = document.getElementById('total_' + studentId);
            const gradeSpan = document.getElementById('grade_' + studentId);
            const theoryInput = document.getElementById('theory_' + studentId);
            const practicalInput = document.getElementById('practical_' + studentId);
            const row = document.querySelector(`tr[data-student-id="${studentId}"]`);
            
            // Parse marks, default to 0 if empty
            const theory = theoryMarks === '' ? 0 : parseFloat(theoryMarks) || 0;
            const practical = practicalMarks === '' ? 0 : parseFloat(practicalMarks) || 0;
            const total = theory + practical;
            
            if (total > 0) {
                totalSpan.textContent = total.toFixed(2);
                
                // Check if student has failed based on pass marks
                const isFailed = (theory < 24) || (practical < 18);
                let grade = '';
                
                if (isFailed) {
                    grade = 'F';
                } else if (total >= 90) grade = 'A+';
                else if (total >= 80) grade = 'A';
                else if (total >= 70) grade = 'B+';
                else if (total >= 60) grade = 'B';
                else if (total >= 50) grade = 'C+';
                else if (total >= 40) grade = 'C';
                else if (total >= 33) grade = 'D';
                else grade = 'F';
                
                gradeSpan.textContent = grade;
                
                // Apply appropriate styling based on total and grade
                if (total > 100) {
                    totalSpan.className = 'total-value error';
                    gradeSpan.textContent = '-';
                    
                    if (theoryInput) {
                        theoryInput.classList.add('invalid');
                        theoryInput.classList.remove('valid');
                    }
                    if (practicalInput) {
                        practicalInput.classList.add('invalid');
                        practicalInput.classList.remove('valid');
                    }
                } else if (grade === 'F') {
                    totalSpan.className = 'total-value';
                    gradeSpan.className = 'grade-badge grade-f';
                    row.classList.add('failed-row');
                } else {
                    totalSpan.className = 'total-value' + (total > 90 ? ' warning' : '');
                    gradeSpan.className = 'grade-badge grade-' + grade.toLowerCase().replace('+', '-plus');
                    row.classList.remove('failed-row');
                }
            } else {
                totalSpan.textContent = '-';
                totalSpan.className = 'total-value';
                gradeSpan.textContent = '-';
                gradeSpan.className = 'grade-badge';
                row.classList.remove('failed-row');
            }
        }
        
        function validateForm() {
            const invalidInputs = document.querySelectorAll('.marks-input.invalid');
            
            // Check for any totals exceeding 100
            let hasTotalError = false;
            document.querySelectorAll('[id^="total_"]').forEach(span => {
                if (span.classList.contains('error')) {
                    hasTotalError = true;
                }
            });
            
            if (invalidInputs.length > 0 || hasTotalError) {
                alert('Please fix validation errors before saving. Theory marks cannot exceed 60, practical marks cannot exceed 40, and total cannot exceed 100.');
                return false;
            }
            
            // Check if at least one student has marks entered
            const theoryInputs = document.querySelectorAll('input[name^="theory_marks"]');
            let hasMarks = false;
            theoryInputs.forEach(input => {
                if (input.value !== '') {
                    hasMarks = true;
                }
            });
            
            if (!hasMarks) {
                alert('Please enter marks for at least one student.');
                return false;
            }
            
            // Show loading state on button
            const saveButton = document.getElementById('saveButton');
            saveButton.disabled = true;
            saveButton.innerHTML = '<span class="loading-spinner"></span> Saving...';
            
            return true;
        }
        
        // Initialize validation for all inputs on page load
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.marks-input').forEach(input => {
                if (input.value) {
                    validateMarks(input);
                }
            });
        });
    </script>
</body>
</html>