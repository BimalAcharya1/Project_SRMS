<?php
session_start();
include "../../Database/dbc.php";

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM Teacher WHERE username=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $teacher = $result->fetch_assoc();

        if (password_verify($password, $teacher['password'])) {
            $_SESSION['teacher_id'] = $teacher['teacher_id'];
            $_SESSION['teacher_name'] = $teacher['first_name'];
            header("Location: ../teacher_dashboard.php");
            exit();
        }
    }

    echo "<script>alert('Invalid login');</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Teacher Login</title>
      <link rel="icon" type="image/png" href="../../icons/SRMS.png">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../CSS/dashboard.css">
    <link rel="stylesheet" href="../CSS/icons.css">
    <link rel="stylesheet" href="../../CSS/form.css">
     <style>
        body{
        background: url("../../images/Admin.jpg") no-repeat center center/cover;
         height: 100vh;
        }
    </style>
</head>
<body>

<form method="post" class="form-box">
       <h2 style="text-align: center;"> 
    <img src="../../icons/Teacher.png"><br></h2>

     <div class="input-box">
        <img src="../../icons/id.gif" class="left-icon">
        <input type="text" name="username" placeholder="Username" required>
    </div>
    <br>
    <div class="input-box">
        <img src="../../icons/password.gif" class="left-icon">

        <input type="password" name="password" id="loginPassword" placeholder="Password" required>

        <img src="../../icons/eyeclosed.png"
             class="right-icon"
             id="loginEye"
             onclick="togglePassword('loginPassword','loginEye')">
    </div>
    <br>
    <button type="submit" name="login">Login</button>
</form>
<script>
function togglePassword(inputId, eyeId) {
    const input = document.getElementById(inputId);
    const eye = document.getElementById(eyeId);

    if (input.type === "password") {
        input.type = "text";
        eye.src = "../../icons/eyeOpened.png";
    } else {
        input.type = "password";
        eye.src = "../../icons/eyeClosed.png";
    }
}
</script>
</body>
</html>
