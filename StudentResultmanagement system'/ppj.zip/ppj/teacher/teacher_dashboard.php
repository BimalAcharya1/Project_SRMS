<?php
require_once '../includes/auth_check.php';
checkTeacherLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Get teacher information
$teacher_id = $_SESSION['teacher_id'];
$teacher_info = $conn->query("
    SELECT t.*, d.dept_name 
    FROM Teacher t 
    LEFT JOIN Department d ON t.dept_id = d.dept_id 
    WHERE t.teacher_id = $teacher_id
")->fetch_assoc();

// Get teacher's allocations count
$allocations_count = $conn->query("
    SELECT COUNT(*) as count 
    FROM Teacher_Allocation 
    WHERE teacher_id = $teacher_id
")->fetch_assoc()['count'];

// Get unique courses count
$courses_count = $conn->query("
    SELECT COUNT(DISTINCT c.course_id) as count 
    FROM Teacher_Allocation ta
    JOIN Subject s ON ta.subject_id = s.subject_id
    JOIN Course c ON s.course_id = c.course_id
    WHERE ta.teacher_id = $teacher_id
")->fetch_assoc()['count'];

// Get unique subjects count
$subjects_count = $conn->query("
    SELECT COUNT(DISTINCT ta.subject_id) as count 
    FROM Teacher_Allocation ta
    WHERE ta.teacher_id = $teacher_id
")->fetch_assoc()['count'];

// Get unique sections count
$sections_count = $conn->query("
    SELECT COUNT(DISTINCT section) as count 
    FROM Teacher_Allocation 
    WHERE teacher_id = $teacher_id AND section IS NOT NULL AND section != ''
")->fetch_assoc()['count'];

// Get teacher's allocations with details - FIXED: Removed session_name
$allocations = $conn->query("
    SELECT ta.*, 
           s.subject_name, s.subject_code, s.semester_number,
           c.course_name, c.course_id,
           d.dept_name, d.dept_id
    FROM Teacher_Allocation ta
    JOIN Subject s ON ta.subject_id = s.subject_id
    JOIN Course c ON s.course_id = c.course_id
    JOIN Department d ON c.dept_id = d.dept_id
    WHERE ta.teacher_id = $teacher_id
    ORDER BY d.dept_name, c.course_name, s.semester_number, s.subject_name
");

// Get recent results entered - FIXED QUERY
$recent_results = $conn->query("
    SELECT r.*, 
           st.first_name, st.last_name, st.roll_number,
           s.subject_name, e.exam_name,
           COALESCE(r.theory_marks, 0) as theory_marks,
           COALESCE(r.practical_marks, 0) as practical_marks,
           COALESCE(r.theory_marks, 0) + COALESCE(r.practical_marks, 0) as total_obtained
    FROM Result r
    INNER JOIN Student st ON r.student_id = st.student_id
    INNER JOIN Subject s ON r.subject_id = s.subject_id
    INNER JOIN Exam e ON r.exam_id = e.exam_id
    INNER JOIN Teacher_Allocation ta ON s.subject_id = ta.subject_id AND ta.teacher_id = $teacher_id
    WHERE ta.teacher_id = $teacher_id
    GROUP BY r.result_id
    ORDER BY r.result_id DESC
    LIMIT 10
");

// Get exam subject details separately for full marks
$exam_subjects = [];
if ($recent_results && $recent_results->num_rows > 0) {
    $recent_results->data_seek(0);
    while ($result = $recent_results->fetch_assoc()) {
        $exam_id = $result['exam_id'];
        $subject_id = $result['subject_id'];
        $key = $exam_id . '_' . $subject_id;
        
        if (!isset($exam_subjects[$key])) {
            $es_query = $conn->query("
                SELECT theory_full_marks, practical_full_marks 
                FROM Exam_Subject 
                WHERE exam_id = $exam_id AND subject_id = $subject_id
            ");
            $exam_subjects[$key] = $es_query->fetch_assoc();
        }
    }
    // Reset pointer for later use
    $recent_results->data_seek(0);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Teacher Dashboard - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Teacher Dashboard Specific Styles */
        .welcome-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .welcome-text h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .welcome-text p {
            opacity: 0.9;
            font-size: 16px;
            margin: 5px 0;
        }
        
        .teacher-badge {
            background: rgba(255, 255, 255, 0.2);
            padding: 15px 25px;
            border-radius: 10px;
            text-align: center;
            backdrop-filter: blur(10px);
        }
        
        .teacher-badge .badge-label {
            font-size: 14px;
            opacity: 0.9;
            margin-bottom: 5px;
        }
        
        .teacher-badge .badge-value {
            font-size: 24px;
            font-weight: bold;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .stat-icon img {
            width: 35px;
            height: 35px;
            filter: brightness(0) invert(1);
        }
        
        .stat-content {
            flex: 1;
        }
        
        .stat-content h3 {
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #333;
        }
        
        .stat-label {
            font-size: 12px;
            color: #999;
            margin-top: 5px;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-top: 20px;
        }
        
        @media (max-width: 768px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }
        
        .allocation-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 4px solid #667eea;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }
        
        .allocation-card:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .allocation-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .course-name {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }
        
        .dept-badge {
            background: #e3f2fd;
            color: #1976d2;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        
        .subject-details {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 10px;
        }
        
        .subject-item {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #666;
            font-size: 14px;
        }
        
        .subject-item img {
            width: 16px;
            height: 16px;
            opacity: 0.5;
        }
        
        .section-badge {
            background: #f0f4ff;
            color: #667eea;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            padding: 8px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s;
        }
        
        .action-btn img {
            width: 16px;
            height: 16px;
        }
        
        .btn-primary {
            background: #667eea;
            color: white;
        }
        
        .btn-primary:hover {
            background: #5a67d8;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(102, 126, 234, 0.3);
        }
        
        .btn-outline {
            border: 1px solid #667eea;
            color: #667eea;
        }
        
        .btn-outline:hover {
            background: #667eea;
            color: white;
        }
        
        .results-list {
            max-height: 500px;
            overflow-y: auto;
        }
        
        .result-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            transition: background-color 0.3s;
        }
        
        .result-item:hover {
            background-color: #f8f9fa;
        }
        
        .result-item:last-child {
            border-bottom: none;
        }
        
        .student-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 16px;
            margin-right: 15px;
            flex-shrink: 0;
        }
        
        .result-info {
            flex: 1;
            min-width: 0;
        }
        
        .student-name {
            font-weight: 600;
            color: #333;
            font-size: 14px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .roll-number {
            font-size: 11px;
            color: #999;
            margin-left: 5px;
            font-weight: normal;
        }
        
        .result-details {
            font-size: 12px;
            color: #666;
            margin-top: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .marks-breakdown {
            display: flex;
            gap: 12px;
            margin-top: 5px;
            font-size: 11px;
        }
        
        .theory-mark {
            color: #28a745;
            background: #e8f5e9;
            padding: 2px 8px;
            border-radius: 12px;
        }
        
        .practical-mark {
            color: #17a2b8;
            background: #e3f2fd;
            padding: 2px 8px;
            border-radius: 12px;
        }
        
        .marks-badge {
            background: #28a745;
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            min-width: 60px;
            text-align: center;
            margin-left: 10px;
            flex-shrink: 0;
        }
        
        .marks-badge.fail {
            background: #dc3545;
        }
        
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #999;
        }
        
        .empty-state img {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .empty-state h3 {
            color: #333;
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .card-header h2 {
            font-size: 18px;
            color: #333;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .badge-primary {
            background: #667eea;
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .view-all-link {
            color: #667eea;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
        }
        
        .view-all-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Teacher.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Teacher
            </div>
            <div class="navbar-menu">
                <a href="teacher_dashboard.php" class="active">
                    <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
                </a>
                <a href="marks_entry.php">
                    <img src="../icons/Addmarks.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Marks Entry</h5>
                </a>
                <a href="view_students.php">
                    <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>View Students</h5>
                </a>
                <a href="teacher_settings.php">
                    <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Settings</h5>
                </a>
                <a href="../logout.php">
                    <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Logout</h5>
                </a>
            </div>
        </nav>
        
        <div class="content">
            <!-- Welcome Section -->
            <div class="welcome-section">
                <div class="welcome-text">
                    <h1>Welcome back, <?php echo htmlspecialchars($teacher_info['first_name'] . ' ' . $teacher_info['last_name']); ?>!</h1>
                    <p><img src="../icons/Department.png" style="height: 18px; vertical-align: middle; margin-right: 5px;"> Department: <?php echo htmlspecialchars($teacher_info['dept_name'] ?? 'Not Assigned'); ?></p>
                    <p><img src="../icons/email.png" style="height: 18px; vertical-align: middle; margin-right: 5px;"> <?php echo htmlspecialchars($teacher_info['email']); ?></p>
                </div>
                <div class="teacher-badge">
                    <div class="badge-label">Teacher ID</div>
                    <div class="badge-value">TCH-<?php echo str_pad($teacher_id, 4, '0', STR_PAD_LEFT); ?></div>
                </div>
            </div>
            
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <img src="../icons/course.png" alt="Courses">
                    </div>
                    <div class="stat-content">
                        <h3>Total Courses</h3>
                        <div class="stat-number"><?php echo $courses_count; ?></div>
                        <div class="stat-label">Assigned to you</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <img src="../icons/subject.png" alt="Subjects">
                    </div>
                    <div class="stat-content">
                        <h3>Total Subjects</h3>
                        <div class="stat-number"><?php echo $subjects_count; ?></div>
                        <div class="stat-label">You're teaching</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <img src="../icons/section.png" alt="Sections">
                    </div>
                    <div class="stat-content">
                        <h3>Sections</h3>
                        <div class="stat-number"><?php echo $sections_count; ?></div>
                        <div class="stat-label">Different sections</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <img src="../icons/allocation.png" alt="Allocations">
                    </div>
                    <div class="stat-content">
                        <h3>Total Allocations</h3>
                        <div class="stat-number"><?php echo $allocations_count; ?></div>
                        <div class="stat-label">Teaching assignments</div>
                    </div>
                </div>
            </div>
            
            <!-- Main Dashboard Grid -->
            <div class="dashboard-grid">
                <!-- Left Column - Allocations -->
                <div class="card">
                    <div class="card-header">
                        <h2><img src="../icons/Teacher.png" style="height: 24px;">My Teaching Assignments</h2>
                        <span class="badge-primary"><?php echo $allocations_count; ?> Total</span>
                    </div>
                    
                    <div style="max-height: 500px; overflow-y: auto;">
                        <?php if($allocations && $allocations->num_rows > 0): ?>
                            <?php while($row = $allocations->fetch_assoc()): ?>
                                <div class="allocation-card">
                                    <div class="allocation-header">
                                        <span class="course-name"><?php echo htmlspecialchars($row['course_name']); ?></span>
                                        <div>
                                            <span class="dept-badge"><?php echo htmlspecialchars($row['dept_name']); ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="subject-details">
                                        <span class="subject-item">
                                            <img src="../icons/subject.png" alt="Subject">
                                            <?php echo htmlspecialchars($row['subject_name']); ?> (<?php echo $row['subject_code']; ?>)
                                        </span>
                                        <span class="subject-item">
                                            <img src="../icons/semester.png" alt="Semester">
                                            Sem <?php echo $row['semester_number']; ?>
                                        </span>
                                        <?php if(!empty($row['section'])): ?>
                                            <span class="section-badge">
                                                Section <?php echo $row['section']; ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="action-buttons">
                                        <a href="marks_entry.php?subject_id=<?php echo $row['subject_id']; ?>&section=<?php echo urlencode($row['section'] ?? ''); ?>" class="action-btn btn-primary">
                                            <img src="../icons/Add.png" alt="Enter Marks"> Enter Marks
                                        </a>
                                        <a href="view_students.php?subject_id=<?php echo $row['subject_id']; ?>&section=<?php echo urlencode($row['section'] ?? ''); ?>" class="action-btn btn-outline">
                                            <img src="../icons/Student.png" alt="View Students"> View Students
                                        </a>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <img src="../icons/empty.png" alt="No allocations">
                                <h3>No Teaching Assignments</h3>
                                <p>You haven't been assigned any subjects yet.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Right Column - Recent Results -->
                <div>
                    <!-- Recent Results -->
                    <div class="card">
                        <div class="card-header">
                            <h2><img src="../icons/result.png" style="height: 24px;">Recent Results Entered</h2>
                            <?php if($recent_results && $recent_results->num_rows > 0): ?>
                                <span class="badge-primary">Last 10</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="results-list">
                            <?php if($recent_results && $recent_results->num_rows > 0): ?>
                                <?php while($result = $recent_results->fetch_assoc()): 
                                    $exam_id = $result['exam_id'];
                                    $subject_id = $result['subject_id'];
                                    $key = $exam_id . '_' . $subject_id;
                                    $exam_subject = $exam_subjects[$key] ?? ['theory_full_marks' => 60, 'practical_full_marks' => 40];
                                    
                                    $theory_marks = floatval($result['theory_marks'] ?? 0);
                                    $practical_marks = floatval($result['practical_marks'] ?? 0);
                                    $total_obtained = $theory_marks + $practical_marks;
                                    $total_full = ($exam_subject['theory_full_marks'] ?? 60) + ($exam_subject['practical_full_marks'] ?? 40);
                                    
                                    // Check if student failed
                                    $is_failed = ($theory_marks < 24) || ($practical_marks < 18);
                                ?>
                                    <div class="result-item">
                                        <div class="student-avatar">
                                            <?php 
                                            $initial1 = !empty($result['first_name']) ? strtoupper(substr($result['first_name'], 0, 1)) : '';
                                            $initial2 = !empty($result['last_name']) ? strtoupper(substr($result['last_name'], 0, 1)) : '';
                                            echo $initial1 . $initial2;
                                            ?>
                                        </div>
                                        <div class="result-info">
                                            <div class="student-name">
                                                <?php echo htmlspecialchars($result['first_name'] . ' ' . $result['last_name']); ?>
                                                <span class="roll-number">(<?php echo htmlspecialchars($result['roll_number']); ?>)</span>
                                            </div>
                                            <div class="result-details">
                                                <?php echo htmlspecialchars($result['subject_name']); ?> - <?php echo htmlspecialchars($result['exam_name']); ?>
                                            </div>
                                            <div class="marks-breakdown">
                                                <span class="theory-mark">Theory: <?php echo number_format($theory_marks, 1); ?>/<?php echo $exam_subject['theory_full_marks'] ?? 60; ?></span>
                                                <span class="practical-mark">Practical: <?php echo number_format($practical_marks, 1); ?>/<?php echo $exam_subject['practical_full_marks'] ?? 40; ?></span>
                                            </div>
                                        </div>
                                        <div class="marks-badge <?php echo $is_failed ? 'fail' : ''; ?>">
                                            <?php echo number_format($total_obtained, 1); ?>/<?php echo $total_full; ?>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="empty-state">
                                    <img src="../icons/empty.png" alt="No results">
                                    <h3>No Results Yet</h3>
                                    <p>Start entering marks to see them here.</p>
                                    <a href="marks_entry.php" class="action-btn btn-primary" style="margin-top: 15px; display: inline-flex;">
                                        <img src="../icons/Add.png" alt="Add"> Enter First Marks
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <?php if($recent_results && $recent_results->num_rows > 0): ?>
                            <div style="margin-top: 15px; text-align: right;">
                                <a href="view_results.php" class="view-all-link">View All Results →</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>