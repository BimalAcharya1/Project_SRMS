<?php
require_once '../includes/auth_check.php';
checkTeacherLogin();
require_once '../config/database.php';

$database = new Database();
$conn = $database->getConnection();

$teacher_id = $_SESSION['teacher_id'];

// Fetch teacher data
$teacher_result = $conn->query("SELECT * FROM Teacher WHERE teacher_id = $teacher_id");
$teacher = $teacher_result->fetch_assoc();

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'update_profile') {
        // Verify old password
        if (!password_verify($_POST['old_password'], $teacher['password'])) {
            $_SESSION['message'] = "Old password is incorrect!";
            $_SESSION['msg_type'] = "error";
            header("Location: teacher_settings.php");
            exit();
        }
        
        $username = $database->escapeString($_POST['username']);
        
        $sql = "UPDATE Teacher SET username = '$username'";
        
        // Handle password change
        if (!empty($_POST['new_password'])) {
            if ($_POST['new_password'] !== $_POST['confirm_password']) {
                $_SESSION['message'] = "New passwords do not match!";
                $_SESSION['msg_type'] = "error";
                header("Location: teacher_settings.php");
                exit();
            }
            
            $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $sql .= ", password = '$new_password'";
        }
        
        $sql .= " WHERE teacher_id = $teacher_id";
        
        if ($conn->query($sql)) {
            $_SESSION['message'] = "Profile updated successfully!";
            $_SESSION['msg_type'] = "success";
            
            // Update session username if changed
            $_SESSION['teacher_name'] = $username;
        } else {
            $_SESSION['message'] = "Error: " . $conn->error;
            $_SESSION['msg_type'] = "error";
        }
        
        header("Location: teacher_settings.php");
        exit();
    }
}

// Get teacher's statistics
$allocations_count = $conn->query("
    SELECT COUNT(*) as count 
    FROM Teacher_Allocation 
    WHERE teacher_id = $teacher_id
")->fetch_assoc()['count'];

$subjects_count = $conn->query("
    SELECT COUNT(DISTINCT subject_id) as count 
    FROM Teacher_Allocation 
    WHERE teacher_id = $teacher_id
")->fetch_assoc()['count'];

$sections_count = $conn->query("
    SELECT COUNT(DISTINCT section) as count 
    FROM Teacher_Allocation 
    WHERE teacher_id = $teacher_id AND section IS NOT NULL
")->fetch_assoc()['count'];

$students_count = $conn->query("
    SELECT COUNT(DISTINCT s.student_id) as count
    FROM Teacher_Allocation ta
    JOIN Subject sub ON ta.subject_id = sub.subject_id
    JOIN Student s ON s.course_id = sub.course_id
    WHERE ta.teacher_id = $teacher_id
")->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../icons/SRMS.png">
    <title>Teacher Settings - SRMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Teacher Settings Specific Styles */
        .settings-container {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 30px;
            margin-top: 20px;
        }
        
        .profile-sidebar {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .profile-image {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            margin: 0 auto 20px;
            overflow: hidden;
            border: 3px solid #667eea;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .profile-image span {
            font-size: 48px;
            color: white;
            font-weight: bold;
        }
        
        .profile-name {
            font-size: 22px;
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }
        
        .profile-username {
            color: #667eea;
            font-size: 14px;
            margin-bottom: 15px;
        }
        
        .profile-detail {
            text-align: left;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
        }
        
        .detail-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            color: #666;
        }
        
        .detail-icon {
            width: 35px;
            height: 35px;
            background: #f0f4ff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            color: #667eea;
            font-size: 18px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 20px;
        }
        
        .stat-card-small {
            background: rgba(12, 30, 166, 0.94);
            padding: 12px 8px;
            border-radius: 16px;
            text-align: center;
            transition: all 0.3s;
            color: white;
            box-shadow: 0 8px 20px rgba(79, 70, 229, 0.2);
        }
        
        .stat-card-small:hover {
           transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(79, 70, 229, 0.3);
        }
        
        .stat-number-small {
             font-size: 22px;
            font-weight: bold;
            margin-bottom: 2px;
        }
        
        .stat-label-small {
            font-size: 10px;
            color: #ffffff;
            margin-top: 5px;
            text-transform: uppercase;
        }
        
        .settings-main {
            flex: 1;
        }
        
        .settings-card {
          background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(79, 70, 229, 0.1);
            border: 1px solid rgba(79, 70, 229, 0.1);
        }
        
        .settings-header {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .settings-header h3 {
            margin: 0;
            color: #333;
            font-size: 20px;
        }
        
        .settings-header .header-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
        }
        
        .form-row {
            margin-bottom: 25px;
        }
        
        .form-row label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            width: 20px;
            height: 20px;
            opacity: 0.5;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .password-strength {
            margin-top: 10px;
            height: 5px;
            background: #e0e0e0;
            border-radius: 3px;
            overflow: hidden;
        }
        
        .strength-bar {
            height: 100%;
            width: 0;
            transition: width 0.3s, background 0.3s;
        }
        
        .strength-bar.weak {
            background: #dc3545;
            width: 33.33%;
        }
        
        .strength-bar.medium {
            background: #ffc107;
            width: 66.66%;
        }
        
        .strength-bar.strong {
            background: #28a745;
            width: 100%;
        }
        
        .password-match {
            font-size: 13px;
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .match-success {
            color: #28a745;
        }
        
        .match-error {
            color: #dc3545;
        }
        
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.3s ease-out;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        
        .alert img {
            width: 20px;
            height: 20px;
        }
        
        .info-text {
            background: #e7f3ff;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            color: #004085;
            font-size: 14px;
            border-left: 4px solid #007bff;
        }
        
        @media (max-width: 768px) {
            .settings-container {
                grid-template-columns: 1fr;
            }
            
            .profile-sidebar {
                margin-bottom: 20px;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="navbar">
            <div class="navbar-brand">
                <img src="../icons/Teacher.png" style="height: 50px; vertical-align: middle; margin-right: 10px;">
                SRMS Teacher
            </div>
            <div class="navbar-menu">
                <a href="teacher_dashboard.php">
                    <img src="../icons/Dashboard.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Dashboard</h5>
                </a>
                <a href="marks_entry.php">
                    <img src="../icons/Addmarks.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Marks Entry</h5>
                </a>
                <a href="view_students.php">
                    <img src="../icons/student.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>View Students</h5>
                </a>
                <a href="teacher_settings.php" class="active">
                    <img src="../icons/setting.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Settings</h5>
                </a>
                <a href="../logout.php">
                    <img src="../icons/logout.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"><h5>Logout</h5>
                </a>
            </div>
        </nav>
        
        <div class="content">
            <h1><img src="../icons/setting.png" style="height: 36px; vertical-align: middle; margin-right: 10px;">Teacher Settings</h1>
            
            <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['msg_type']; ?>">
                    <img src="../icons/<?php echo $_SESSION['msg_type'] == 'success' ? 'success' : 'error'; ?>.png" alt="">
                    <?php 
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_GET['updated'])): ?>
                <div class="alert alert-success">
                    <img src="../icons/success.png" alt="Success">
                    Profile updated successfully!
                </div>
            <?php endif; ?>
            
            <div class="settings-container">
                <!-- Profile Sidebar -->
                <div class="profile-sidebar">
                    <div class="profile-image">
                        <span><?php echo strtoupper(substr($teacher['first_name'], 0, 1) . substr($teacher['last_name'], 0, 1)); ?></span>
                    </div>
                    
                    <div class="profile-name">
                        <?php echo $teacher['first_name'] . ' ' . $teacher['last_name']; ?>
                    </div>
                    <div class="profile-username">
                        @<?php echo $teacher['username']; ?>
                    </div>
                    
                    <div class="profile-detail">
                        <div class="detail-item">
                            <span class="detail-icon"><img src="../icons/teacher.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></span>
                            <span><?php echo $teacher['email']; ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-icon"><img src="../icons/Contact.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></span>
                            <span><?php echo $teacher['phone']; ?></span>
                        </div>
                        <?php if(!empty($teacher['dept_id'])): ?>
                        <?php 
                            $dept_result = $conn->query("SELECT dept_name FROM Department WHERE dept_id = " . $teacher['dept_id']);
                            $dept = $dept_result->fetch_assoc();
                        ?>
                        <div class="detail-item">
                            <span class="detail-icon"><img src="../icons/Department.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></span>
                            <span><?php echo $dept['dept_name']; ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="stats-grid">
                        <div class="stat-card-small">
                            <div class="stat-number-small"><?php echo $allocations_count; ?></div>
                            <div class="stat-label-small">Allocations</div>
                        </div>
                        <div class="stat-card-small">
                            <div class="stat-number-small"><?php echo $subjects_count; ?></div>
                            <div class="stat-label-small">Subjects</div>
                        </div>
                        <div class="stat-card-small">
                            <div class="stat-number-small"><?php echo $sections_count; ?></div>
                            <div class="stat-label-small">Sections</div>
                        </div>
                        <div class="stat-card-small">
                            <div class="stat-number-small"><?php echo $students_count; ?></div>
                            <div class="stat-label-small">Students</div>
                        </div>
                    </div>
                </div>
                
                <!-- Settings Main -->
                <div class="settings-main">
                    <!-- Profile Settings Card -->
                    <div class="settings-card">
                        <div class="settings-header">
                            <span class="header-icon"><img src="../icons/users.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></span>
                            <h3>Profile Settings</h3>
                        </div>
                        
                        <div class="info-text">
                            <strong>Note:</strong> You can update your username and password here. 
                            Your name, email, and phone are managed by the administrator.
                        </div>
                        
                        <form method="POST" action="teacher_settings.php">
                            <input type="hidden" name="action" value="update_profile">
                            
                            <div class="form-row">
                                <label>Username</label>
                                <div class="input-group">
                                    <img src="../icons/id.gif" class="input-icon" alt="Username">
                                    <input type="text" name="username" class="form-control" value="<?php echo $teacher['username']; ?>" required>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <label>Old Password</label>
                                <div class="input-group">
                                    <img src="../icons/password.gif" class="input-icon" alt="Password">
                                    <input type="password" name="old_password" class="form-control" placeholder="Enter your current password" required>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <label>New Password (leave blank to keep current)</label>
                                <div class="input-group">
                                    <img src="../icons/password.gif" class="input-icon" alt="New Password">
                                    <input type="password" name="new_password" id="new_password" class="form-control" placeholder="Enter new password" onkeyup="checkPasswordStrength()">
                                </div>
                                <div class="password-strength">
                                    <div class="strength-bar" id="strengthBar"></div>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <label>Confirm New Password</label>
                                <div class="input-group">
                                    <img src="../icons/password.gif" class="input-icon" alt="Confirm Password">
                                    <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Confirm new password" onkeyup="checkPasswordMatch()">
                                </div>
                                <div class="password-match" id="passwordMatchMsg"></div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Update Profile</button>
                            <a href="teacher_dashboard.php" class="btn btn-secondary" style="margin-left: 10px;">Cancel</a>
                        </form>
                    </div>
                    
                    <!-- Account Info Card -->
                    <div class="settings-card">
                        <div class="settings-header">
                            <span class="header-icon"><img src="../icons/info.png" style="height: 22px; vertical-align: middle; margin-right: 10px;"></span>
                            <h3>Account Information</h3>
                        </div>
                        
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr>
                                <td style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; color: #666;">Teacher ID</td>
                                <td style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; font-weight: 600;"><?php echo $teacher['teacher_id']; ?></td>
                            </tr>
                            <tr>
                                <td style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; color: #666;">Full Name</td>
                                <td style="padding: 12px 0; border-bottom: 1px solid #e0e0e0;"><?php echo $teacher['first_name'] . ' ' . $teacher['middle_name'] . ' ' . $teacher['last_name']; ?></td>
                            </tr>
                            <tr>
                                <td style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; color: #666;">Email</td>
                                <td style="padding: 12px 0; border-bottom: 1px solid #e0e0e0;"><?php echo $teacher['email']; ?></td>
                            </tr>
                            <tr>
                                <td style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; color: #666;">Phone</td>
                                <td style="padding: 12px 0; border-bottom: 1px solid #e0e0e0;"><?php echo $teacher['phone']; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        function checkPasswordStrength() {
            const password = document.getElementById('new_password').value;
            const strengthBar = document.getElementById('strengthBar');
            
            // Remove all classes
            strengthBar.className = 'strength-bar';
            
            if (password.length === 0) {
                strengthBar.style.width = '0';
                return;
            }
            
            let strength = 0;
            
            // Check length
            if (password.length >= 8) strength++;
            if (password.length >= 12) strength++;
            
            // Check for numbers
            if (/\d/.test(password)) strength++;
            
            // Check for special characters
            if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength++;
            
            // Check for uppercase letters
            if (/[A-Z]/.test(password)) strength++;
            
            // Apply class based on strength
            if (strength <= 2) {
                strengthBar.classList.add('weak');
            } else if (strength <= 4) {
                strengthBar.classList.add('medium');
            } else {
                strengthBar.classList.add('strong');
            }
        }
        
        function checkPasswordMatch() {
            const password = document.getElementById('new_password').value;
            const confirm = document.getElementById('confirm_password').value;
            const msg = document.getElementById('passwordMatchMsg');
            
            if (confirm.length === 0) {
                msg.innerHTML = '';
                return;
            }
            
            if (password === confirm) {
                msg.innerHTML = '✓ Passwords match';
                msg.className = 'password-match match-success';
            } else {
                msg.innerHTML = '✗ Passwords do not match';
                msg.className = 'password-match match-error';
            }
        }
        
        // Auto-hide alerts after 5 seconds
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                alert.style.transition = 'opacity 0.5s';
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 500);
            });
        }, 5000);
    </script>
</body>
</html>