<?php

class Validator {

    private $errors = [];

    /**
     * Validate a Name (First, Middle, Last, or Full Name)
     * Rule: Must not contain numbers or special characters (except spaces/hyphens).
     */
    public function validateName($field_name, $value) {
        $value = trim($value);
        if (empty($value)) {
            $this->errors[$field_name] = "$field_name is required.";
            return false;
        }
        // Check if string contains any digit
        if (preg_match('/\d/', $value)) {
            $this->errors[$field_name] = "$field_name cannot contain numbers.";
            return false;
        }
        // Allow letters, spaces, and hyphens only
        if (!preg_match("/^[a-zA-Z\s'-]+$/", $value)) {
            $this->errors[$field_name] = "$field_name contains invalid characters.";
            return false;
        }
        return true;
    }

    /**
     * Validate Phone Number (Nepal Specific)
     * Rule: Must start with 97 or 98 and be exactly 10 digits.
     */
    public function validatePhone($field_name, $value) {
        $value = trim($value);
        if (empty($value)) {
            $this->errors[$field_name] = "$field_name is required.";
            return false;
        }
        // Check if exactly 10 digits
        if (!ctype_digit($value) || strlen($value) !== 10) {
            $this->errors[$field_name] = "$field_name must be exactly 10 digits.";
            return false;
        }
        // Check if starts with 97 or 98
        $prefix = substr($value, 0, 2);
        if ($prefix !== '97' && $prefix !== '98') {
            $this->errors[$field_name] = "$field_name must start with 97 or 98.";
            return false;
        }
        return true;
    }

    /**
     * Validate Email
     * Rule: Standard email format.
     */
    public function validateEmail($field_name, $value) {
        $value = trim($value);
        if (empty($value)) {
            $this->errors[$field_name] = "$field_name is required.";
            return false;
        }
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field_name] = "Invalid email format.";
            return false;
        }
        return true;
    }

    /**
     * Validate Username
     * Rule: Characters first, followed by numbers at the end (e.g., "john123").
     */
    public function validateUsername($field_name, $value) {
        $value = trim($value);
        if (empty($value)) {
            $this->errors[$field_name] = "$field_name is required.";
            return false;
        }
        // Regex: Starts with letters ([a-zA-Z]+), ends with numbers (\d+)$
        if (!preg_match('/^[a-zA-Z]+[0-9]+$/', $value)) {
            $this->errors[$field_name] = "$field_name must be letters followed by numbers (e.g., ram123).";
            return false;
        }
        return true;
    }

    /**
     * Validate Password
     * Rule: At least 10 chars, 1 Uppercase, 1 Lowercase, 1 Number/Symbol.
     * (Note: Your prompt asked for "upper lower and symbol", I included numbers for security standard).
     */
    public function validatePassword($field_name, $value) {
        if (empty($value)) {
            $this->errors[$field_name] = "$field_name is required.";
            return false;
        }
        if (strlen($value) < 10) {
            $this->errors[$field_name] = "$field_name must be at least 10 characters long.";
            return false;
        }
        if (!preg_match('/[A-Z]/', $value)) {
            $this->errors[$field_name] = "$field_name must contain at least one uppercase letter.";
            return false;
        }
        if (!preg_match('/[a-z]/', $value)) {
            $this->errors[$field_name] = "$field_name must contain at least one lowercase letter.";
            return false;
        }
        if (!preg_match('/[\W_]/', $value)) { // \W matches any non-word character (symbol)
            $this->errors[$field_name] = "$field_name must contain at least one symbol (e.g., @, #, $).";
            return false;
        }
        return true;
    }

    /**
     * Validate Date
     * Rule: Date cannot be in the future.
     */
    public function validateDate($field_name, $value) {
        if (empty($value)) {
            $this->errors[$field_name] = "$field_name is required.";
            return false;
        }
        
        $inputDate = new DateTime($value);
        $currentDate = new DateTime(); // Today's date

        // Set time to 00:00:00 for accurate date-only comparison
        $currentDate->setTime(0, 0, 0); 
        $inputDate->setTime(0, 0, 0);

        if ($inputDate > $currentDate) {
            $this->errors[$field_name] = "Date cannot be in the future.";
            return false;
        }
        return true;
    }

    /**
     * Check if there are any errors
     */
    public function passed() {
        return empty($this->errors);
    }

    /**
     * Get all errors
     */
    public function getErrors() {
        return $this->errors;
    }
}
?>